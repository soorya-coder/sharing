"""Build the project report as a Word document (report/Student_Performance_Decision_System_Report.docx).

Same content as build_report_pdf.py; numbers, code and demo output are produced
live from the project. Requires: pip install python-docx reportlab pypdfium2
Usage: python build_report_docx.py
"""
import html
import io
import math
import re
import statistics
from collections import Counter

import pypdfium2
from docx import Document
from docx.enum.table import WD_ROW_HEIGHT_RULE, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from reportlab.graphics import renderPDF

from build_report_pdf import (MEMBERS, SUBMISSION_DATE, bar_chart, bn_diagram, demo_output, run_experiments, run_tests,
                              source_of)
from spds import bayes_net, decision, naive_bayes
from spds.data import FEATURES, PROJECT_ROOT, STATES, TARGET, UNITS

OUT_PATH = PROJECT_ROOT / "report" / "Student_Performance_Decision_System_Report.docx"

NAVY = RGBColor(0x1F, 0x3A, 0x5F)
ACCENT = RGBColor(0x2E, 0x75, 0xB6)
GREY = RGBColor(0x55, 0x55, 0x55)
NAVY_HEX, LIGHT_HEX, GRID_HEX, CODE_HEX = "1F3A5F", "EAF1F8", "B7C9DB", "F5F7FA"
BODY_FONT, MONO_FONT = "Arial", "Consolas"
TEXT_WIDTH_CM = 17.0  # A4 with 2 cm margins

doc = Document()


# ------------------------------------------------------------------ low-level helpers
def insert_ordered(parent, element, successors):
    """Insert element before the first existing successor tag (OOXML child order is schema-enforced)."""
    for child in parent:
        if child.tag in {qn(t) for t in successors}:
            child.addprevious(element)
            return
    parent.append(element)


def set_cell_shading(cell, hex_fill):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    cell._tc.get_or_add_tcPr().append(shd)


def set_table_borders(tbl, hex_color=GRID_HEX):
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:color"), hex_color)
        borders.append(el)
    insert_ordered(tbl._tbl.tblPr, borders, ("w:shd", "w:tblLayout", "w:tblCellMar", "w:tblLook"))


def set_paragraph_shading(p, hex_fill):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    insert_ordered(p._p.get_or_add_pPr(), shd,
                   ("w:tabs", "w:suppressAutoHyphens", "w:kinsoku", "w:wordWrap", "w:overflowPunct",
                    "w:topLinePunct", "w:autoSpaceDE", "w:autoSpaceDN", "w:bidi", "w:adjustRightInd",
                    "w:snapToGrid", "w:spacing", "w:ind", "w:contextualSpacing", "w:mirrorIndents",
                    "w:suppressOverlap", "w:jc", "w:textDirection", "w:textAlignment",
                    "w:textboxTightWrap", "w:outlineLvl", "w:divId", "w:cnfStyle", "w:rPr",
                    "w:sectPr", "w:pPrChange"))


def add_field(paragraph, instruction):
    """Insert a Word field (e.g. PAGE, TOC) that Word fills in when the document opens."""
    run = paragraph.add_run()
    for tag, attr in (("w:fldChar", "begin"), ("w:instrText", None), ("w:fldChar", "separate")):
        el = OxmlElement(tag)
        if attr:
            el.set(qn("w:fldCharType"), attr)
        else:
            el.set(qn("xml:space"), "preserve")
            el.text = instruction
        run._r.append(el)
    placeholder = paragraph.add_run("Right-click and choose Update Field to build the table of contents."
                                    if instruction.startswith("TOC") else "1")
    placeholder.font.color.rgb = GREY
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    paragraph.add_run()._r.append(end)


TOKEN = re.compile(r"(</?(?:b|i|sub|super|code)>)")


def add_rich(paragraph, text, size=None, color=None, bold=False):
    """Add text with a tiny markup: <b>, <i>, <sub>, <super>, <code>."""
    state = {"b": bold, "i": False, "sub": False, "super": False, "code": False}
    for part in TOKEN.split(text):
        m = re.fullmatch(r"<(/?)(b|i|sub|super|code)>", part)
        if m:
            state[m.group(2)] = not m.group(1)
            continue
        if not part:
            continue
        run = paragraph.add_run(html.unescape(part))
        run.bold = state["b"]
        run.italic = state["i"]
        run.font.subscript = state["sub"]
        run.font.superscript = state["super"]
        if state["code"]:
            run.font.name = MONO_FONT
        if size:
            run.font.size = Pt(size)
        if color:
            run.font.color.rgb = color
    return paragraph


def para(text, align=WD_ALIGN_PARAGRAPH.JUSTIFY, size=None, color=None, bold=False, space_after=5):
    p = doc.add_paragraph()
    p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    return add_rich(p, text, size=size, color=color, bold=bold)


def eq(text):
    p = para(text, align=WD_ALIGN_PARAGRAPH.CENTER, size=11, space_after=7)
    p.paragraph_format.space_before = Pt(3)
    return p


def h1(text):
    return doc.add_heading(text, level=1)


def h2(text):
    return doc.add_heading(text, level=2)


def bullets(items):
    for t in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.space_after = Pt(2)
        add_rich(p, t)


def caption(text):
    p = para(text, align=WD_ALIGN_PARAGRAPH.CENTER, size=9, color=GREY, space_after=10)
    for r in p.runs:
        r.italic = True


def code(text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.line_spacing = 1.0
    set_paragraph_shading(p, CODE_HEX)
    lines = text.rstrip().splitlines()
    for i, line in enumerate(lines):
        run = p.add_run(line)
        run.font.name = MONO_FONT
        run.font.size = Pt(7.5)
        if i < len(lines) - 1:
            run.add_break()


def table(rows, widths_cm, header=True, font_size=8.5, row_height_cm=None):
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    set_table_borders(t)
    for i, row in enumerate(rows):
        r = t.rows[i]
        if row_height_cm:
            r.height = Cm(row_height_cm)
            r.height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST
        for j, value in enumerate(row):
            cell = r.cells[j]
            cell.width = Cm(widths_cm[j])
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            is_head = header and i == 0
            add_rich(p, str(value), size=font_size, color=RGBColor(0xFF, 0xFF, 0xFF) if is_head else None,
                     bold=is_head)
            if is_head:
                set_cell_shading(cell, NAVY_HEX)
            elif i % 2 == 0:
                set_cell_shading(cell, LIGHT_HEX)
    if header:  # repeat header row on each page
        tr_pr = t.rows[0]._tr.get_or_add_trPr()
        el = OxmlElement("w:tblHeader")
        el.set(qn("w:val"), "true")
        tr_pr.append(el)
    return t


def figure(drawing, width_cm):
    """Rasterise a reportlab Drawing (via a one-page PDF) and insert it as a PNG."""
    pdf = pypdfium2.PdfDocument(renderPDF.drawToString(drawing))
    image = pdf[0].render(scale=4).to_pil()
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    buf.seek(0)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(buf, width=Cm(width_cm))


def page_break():
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


# ------------------------------------------------------------------ document setup
def setup():
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, side, Cm(2.0))
    sec.different_first_page_header_footer = True

    normal = doc.styles["Normal"]
    normal.font.name = BODY_FONT
    normal.font.size = Pt(10.5)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
    normal.paragraph_format.line_spacing = 1.15
    for name, size, color in (("Heading 1", 16, NAVY), ("Heading 2", 12.5, ACCENT)):
        st = doc.styles[name]
        st.font.name, st.font.size, st.font.color.rgb, st.font.bold = BODY_FONT, Pt(size), color, True
        rfonts = st.element.rPr.rFonts
        for attr in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
            rfonts.attrib.pop(qn(attr), None)
        rfonts.set(qn("w:ascii"), BODY_FONT)
        rfonts.set(qn("w:hAnsi"), BODY_FONT)
        st.paragraph_format.space_before = Pt(14 if name == "Heading 1" else 9)
        st.paragraph_format.space_after = Pt(6 if name == "Heading 1" else 4)

    footer = sec.footer.paragraphs[0]
    footer.text = "Student Performance Decision System — Bayesian Reasoning\tPage "
    for r in footer.runs:
        r.font.size, r.font.color.rgb = Pt(8), GREY
    add_field(footer, "PAGE")
    for r in footer.runs:
        r.font.size = Pt(8)
    footer.paragraph_format.tab_stops.add_tab_stop(Cm(TEXT_WIDTH_CM), alignment=2)  # right tab

    # Ask Word to refresh fields (table of contents, page numbers) when the file opens.
    settings = doc.settings.element
    upd = OxmlElement("w:updateFields")
    upd.set(qn("w:val"), "true")
    insert_ordered(settings, upd,
                   ("w:hdrShapeDefaults", "w:footnotePr", "w:endnotePr", "w:compat", "w:docVars", "w:rsids",
                    "m:mathPr", "w:attachedSchema", "w:themeFontLang", "w:clrSchemeMapping",
                    "w:doNotIncludeSubdocsInStats", "w:doNotAutoCompressPictures", "w:forceUpgrade",
                    "w:captions", "w:readModeInkLockDown", "w:smartTagType", "w:shapeDefaults",
                    "w:doNotEmbedSmartTags", "w:decimalSymbol", "w:listSeparator"))
    zoom = settings.find(qn("w:zoom"))
    if zoom is not None and zoom.get(qn("w:percent")) is None:
        zoom.set(qn("w:percent"), "100")

    doc.core_properties.title = "Student Performance Decision System — Bayesian Reasoning"
    doc.core_properties.subject = "M.Tech FAI Mini-Project #7"


# ------------------------------------------------------------------ content
def build():
    setup()
    records, train, test, models, holdout, cv = run_experiments()
    nb, bn = models["Naive Bayes"], models["Bayesian Network"]
    test_result, test_lines = run_tests()
    names = list(models)
    f3 = lambda x: f"{x:.3f}"
    W = TEXT_WIDTH_CM

    def cvm(name, key):
        vals = [s[key] for s in cv[name]]
        return statistics.mean(vals), statistics.stdev(vals)

    C = WD_ALIGN_PARAGRAPH.CENTER

    # ---------------------------------------------------------- title page
    for _ in range(5):
        doc.add_paragraph()
    para("M.Tech — Fundamentals of Artificial Intelligence", C, 14, ACCENT, space_after=2)
    para("Mini-Project Report", C, 14, ACCENT, space_after=30)
    para("Student Performance Decision System", C, 26, NAVY, bold=True, space_after=4)
    para("using Bayesian Reasoning", C, 15, ACCENT, space_after=14)
    para("Mini-Project Topic No. 7  |  Technique: Bayesian Reasoning (Naive Bayes, Bayesian Network, "
         "Decision Theory)", C, 11, space_after=36)
    para("Submitted by", C, 12, NAVY, bold=True, space_after=6)
    members = [["S.No.", "Student Name", "Roll Number"]] + [
        [str(i), name, roll] for i, (name, roll) in enumerate(MEMBERS, 1)]
    table(members, [1.6, 9.0, 5.0], font_size=10.5, row_height_cm=1.1)
    doc.add_paragraph()
    doc.add_paragraph()
    para(f"Date of submission: {SUBMISSION_DATE}", C, 11)
    page_break()

    # ---------------------------------------------------------- contents + abstract
    doc.add_heading("Contents", level=2)
    add_field(doc.add_paragraph(), 'TOC \\o "1-1" \\h \\z \\u')
    doc.add_paragraph()
    bn_cv_acc = cvm("Bayesian Network", "accuracy")[0]
    doc.add_heading("Abstract", level=2)
    para("Identifying students at risk of failing early enough to help them is a decision made under "
         "uncertainty: the available evidence (attendance, study habits, internal marks, previous grades, "
         "assignment completion) is noisy, partly missing, and only probabilistically related to the "
         "final result. This project builds a <b>Student Performance Decision System</b> that uses "
         "<b>Bayesian reasoning</b> to compute P(Fail | evidence) and then applies <b>decision theory</b> "
         "to recommend the intervention with the minimum expected cost. Two Bayesian models are "
         "implemented from scratch in Python: a Naive Bayes classifier and a Bayesian network with "
         "exact inference by enumeration. They are evaluated on a 2,000-student dataset and compared "
         "against an ID3 decision tree, a hand-written rule-based system and a prior-only baseline. "
         f"The Bayesian network achieved the best cross-validated accuracy ({bn_cv_acc:.1%}), the best "
         "calibrated probabilities (lowest log loss) and the lowest average decision cost, while also "
         "handling missing inputs and supporting diagnostic queries that the alternatives cannot answer.")
    page_break()

    # ---------------------------------------------------------- 1. problem definition
    h1("1. Problem Definition")
    para("Academic institutions want to identify students who are likely to fail a course while there "
         "is still time to intervene. Teachers usually rely on informal judgement, which is inconsistent, "
         "or on fixed rules (e.g. \"attendance below 65% means at risk\"), which ignore how the different "
         "factors combine and give no measure of confidence.")
    para("The problem has three characteristics that make it a natural fit for probabilistic AI:")
    bullets([
        "<b>Uncertainty</b> — two students with identical records can get different results; the "
        "relationship between evidence and outcome is probabilistic, not deterministic.",
        "<b>Incomplete information</b> — attendance may not be recorded or internal marks not yet "
        "published; the system must still reason with whatever is available.",
        "<b>Asymmetric consequences</b> — failing to help a student who goes on to fail is far more "
        "costly than giving extra support to a student who would have passed anyway.",
    ])
    para("<b>Objective.</b> Given any subset of a student's academic indicators, the system must "
         "(1) estimate the probability that the student will fail, (2) explain which evidence drove "
         "that estimate, and (3) recommend one of three actions — <i>No action</i>, <i>Mentor &amp; "
         "monitor</i>, or <i>Intensive intervention</i> — that minimises expected cost.")

    # ---------------------------------------------------------- 2. formulation
    var_rows = [["Variable", "Type", "States", "Raw measure and cut-offs"]]
    for f in FEATURES:
        var_rows.append([f, "Evidence", ", ".join(STATES[f]), UNITS[f]])
    var_rows.append([TARGET, "Query (hidden)", ", ".join(STATES[TARGET]), "Final course outcome"])
    cost_rows = [["Action", "Cost if student Passes", "Cost if student Fails"]] + [
        [a, decision.COST[a]["Pass"], decision.COST[a]["Fail"]] for a in decision.ACTIONS]
    thr = decision.decision_thresholds()

    h1("2. AI Problem Formulation")
    para("The task is formulated as <b>probabilistic inference followed by a decision under "
         "uncertainty</b>. The world is described by six discrete random variables:")
    table(var_rows, [2.8, 2.4, 3.8, W - 9.0])
    caption("Table 1. Random variables of the model")
    para("<b>Evidence.</b> e = any subset of {StudyHours, Attendance, PrevGPA, InternalMarks, "
         "Assignments}; unobserved variables are left unknown rather than guessed.")
    para("<b>Query.</b> The posterior distribution P(Result | e).")
    para("<b>Actions.</b> A = {No action, Mentor &amp; monitor, Intensive intervention}.")
    para("<b>Cost model.</b> Cost(a, s) for each action a and true outcome s (Table 2). Missing a "
         "failing student (No action, Fail) carries the largest cost.")
    table(cost_rows, [6.0, 5.0, 5.0])
    caption("Table 2. Cost matrix used by the decision layer")
    para("<b>Decision rule</b> (maximum expected utility / minimum expected cost):")
    eq("a* = argmin<sub>a in A</sub> EC(a),    EC(a) = Σ<sub>s</sub> P(s | e) · Cost(a, s)")
    para("Because EC(a) is linear in p = P(Fail | e), the rule is equivalent to two thresholds: "
         f"<b>No action</b> if p &lt; {thr[0][2]:.3f}; <b>Mentor &amp; monitor</b> if "
         f"{thr[0][2]:.3f} ≤ p &lt; {thr[1][2]:.3f}; <b>Intensive intervention</b> if p ≥ {thr[1][2]:.3f}. "
         "Note that a student is escalated at p = 0.4, not 0.5, because of the asymmetric costs.")

    # ---------------------------------------------------------- 3. technique
    h1("3. Selection and Explanation of the AI Technique")
    h2("3.1 Why Bayesian reasoning?")
    bullets([
        "It represents uncertainty explicitly as probabilities, which the decision layer needs in order "
        "to compute expected costs — a hard yes/no classifier cannot do this.",
        "It combines prior knowledge (base pass rate, causal structure) with evidence in a principled "
        "way, and updates beliefs incrementally as new evidence arrives.",
        "Missing evidence is handled exactly by marginalisation, with no ad-hoc imputation.",
        "It is explainable: each probability can be traced to counts and to the contribution of each "
        "piece of evidence.",
    ])
    h2("3.2 Bayes' theorem")
    eq("P(Result | e) = P(e | Result) · P(Result) / P(e)")
    para("The <b>prior</b> P(Result) is the belief before seeing the student; the <b>likelihood</b> "
         "P(e | Result) is how typical the evidence is of passing or failing students; the "
         "<b>posterior</b> P(Result | e) is the updated belief.")
    para("<b>Worked example.</b> Let P(Pass) = 0.7, P(Fail) = 0.3, P(Attendance=Low | Pass) = 0.2 and "
         "P(Attendance=Low | Fail) = 0.7. Then the unnormalised scores are 0.2 × 0.7 = 0.14 for Pass and "
         "0.7 × 0.3 = 0.21 for Fail; normalising gives P(Fail | Low attendance) = 0.21 / 0.35 = "
         "<b>0.60</b>. One observation moved the belief from 30% to 60% (this example is checked by a "
         "unit test).")
    h2("3.3 Model A — Naive Bayes")
    para("Naive Bayes assumes every feature is conditionally independent of the others given Result:")
    eq("P(Result | e<sub>1</sub>, …, e<sub>n</sub>) = α · P(Result) · Π<sub>i</sub> P(e<sub>i</sub> | Result)")
    para("Parameters are learned by counting with Laplace (add-one) smoothing, P(v | c) = "
         "(N<sub>v,c</sub> + 1) / (N<sub>c</sub> + |V|), so unseen combinations never get probability "
         "zero. Products are computed as sums of logarithms for numerical stability. The contribution of "
         "each observed feature is its <b>log-likelihood ratio</b> w = ln[P(v | Fail) / P(v | Pass)]: "
         "positive values push towards Fail. This gives a direct explanation of every prediction.")
    h2("3.4 Model B — Bayesian network")
    para("The independence assumption of Naive Bayes is unrealistic: low study hours cause poor internal "
         "marks, so treating them as independent evidence double-counts the same signal. The Bayesian "
         "network encodes causal domain knowledge instead (Figure 1). The joint distribution factorises "
         "along the graph:")
    eq("P(X<sub>1</sub>, …, X<sub>n</sub>) = Π<sub>i</sub> P(X<sub>i</sub> | Parents(X<sub>i</sub>))")
    figure(bn_diagram(), 14.5)
    caption("Figure 1. Bayesian network structure (Result shaded)")
    para("<b>Learning.</b> Each conditional probability table (CPT) is estimated by counting with "
         "Laplace smoothing; a row contributes to a CPT when the node and all its parents are observed.")
    para("<b>Inference by enumeration.</b> For a query variable Q, evidence e and hidden variables H:")
    eq("P(Q | e) = α Σ<sub>h</sub> Π<sub>i</sub> P(x<sub>i</sub> | parents(X<sub>i</sub>)),  "
       "summed over all assignments h of H")
    para("With six variables of at most three states there are at most 3<super>5</super> = 243 terms per "
         "query value, so exact enumeration is fast. The same routine answers <b>predictive</b> queries "
         "(P(Result | Attendance=Low)), <b>diagnostic</b> queries (P(StudyHours | Result=Fail)) and "
         "infers unobserved inputs (P(InternalMarks | e)).")
    h2("3.5 Decision layer")
    para("The posterior from the Bayesian network is passed to the decision-theoretic rule of Section 2. "
         "The system therefore separates <i>what is likely</i> (inference) from <i>what to do about it</i> "
         "(decision), so the institution can change the costs without retraining any model.")

    # ---------------------------------------------------------- 4. implementation
    mod_rows = [["Module", "Responsibility"],
                ["spds/data.py", "Variable definitions, discretisation, CSV loading, train/test and k-fold splits"],
                ["spds/synthetic.py", "Synthetic dataset generator (hidden-trait model)"],
                ["spds/naive_bayes.py", "Naive Bayes: learning, posterior, sequential update, evidence weights"],
                ["spds/bayes_net.py", "Bayesian network: topological order, CPT learning, exact enumeration"],
                ["spds/decision.py", "Cost matrix, expected-cost decision, analytic thresholds"],
                ["spds/baselines.py", "ID3 decision tree, rule-based system, prior-only baseline"],
                ["spds/metrics.py", "Accuracy, precision, recall, F1, log loss, Brier score, decision cost"],
                ["spds/models.py", "Bayesian network structure and model factory"],
                ["run_experiment.py", "Training, evaluation, comparison; writes results/report.md"],
                ["demo.py", "Interactive command-line prototype"],
                ["tests/test_core.py", "Unit tests"]]
    page_break()
    h1("4. Python Implementation")
    para("The system is implemented in Python 3 using only the standard library — every algorithm "
         "(Naive Bayes, Bayesian network learning and inference, ID3, metrics) is written from scratch. "
         "The code is organised as a package <code>spds</code> plus three entry-point scripts.")
    table(mod_rows, [4.2, W - 4.2])
    caption("Table 3. Project modules")
    h2("4.1 Naive Bayes posterior")
    code(source_of(naive_bayes.NaiveBayes.predict_proba))
    h2("4.2 Bayesian network — CPT learning and exact inference")
    code(source_of(bayes_net.BayesianNetwork.fit))
    code(source_of(bayes_net.BayesianNetwork.joint) + "\n" + source_of(bayes_net.BayesianNetwork.query))
    h2("4.3 Decision layer")
    code(source_of(decision.expected_costs) + "\n" + source_of(decision.decide))
    para("<b>How to run.</b> <code>python generate_data.py</code> creates the dataset; "
         "<code>python run_experiment.py</code> trains and evaluates all models; "
         "<code>python demo.py</code> starts the prototype; "
         "<code>python -m unittest discover tests</code> runs the tests.")

    # ---------------------------------------------------------- 5. dataset
    counts = Counter(r[TARGET] for r in records)
    missing = {f: sum(r[f] is None for r in records) for f in FEATURES}
    dist_rows = [["Variable", "State counts", "Missing"]]
    for f in FEATURES:
        c = Counter(r[f] for r in records if r[f] is not None)
        dist_rows.append([f, ",  ".join(f"{s}: {c[s]}" for s in STATES[f]), missing[f]])
    dist_rows.append([TARGET, f"Pass: {counts['Pass']},  Fail: {counts['Fail']}", 0])
    test_rows = [["Unit test", "Result"]] + [
        [ln.split(" (")[0], ln.rsplit("... ", 1)[1].upper()] for ln in test_lines]

    page_break()
    h1("5. Dataset and Test-Case Preparation")
    h2("5.1 Dataset")
    para(f"A dataset of <b>{len(records)} students</b> is generated by <code>spds/synthetic.py</code> "
         "(seed 42, reproducible). Each student has two hidden traits, <i>motivation</i> and "
         "<i>ability</i>, drawn from a standard normal distribution. The observable measures are noisy "
         "functions of these traits — e.g. study hours and attendance depend on motivation, previous GPA "
         "on ability, internal marks on study hours, attendance and ability — and the final result "
         "depends on the observables plus Gaussian noise. The outcome is therefore genuinely uncertain "
         "given the evidence, as in real life. About 3% of values are blanked at random to simulate "
         "incomplete records. Raw values are discretised using the cut-offs in Table 1.")
    table(dist_rows, [3.0, W - 5.0, 2.0])
    caption(f"Table 4. Dataset summary (fail rate {counts['Fail'] / len(records):.1%})")
    para(f"<b>Splits.</b> A shuffled 70/30 hold-out split ({len(train)} training / {len(test)} test "
         "students) and 5-fold cross-validation on the full dataset. The same CSV format can be filled "
         "from a real dataset such as the UCI <i>Student Performance</i> dataset without changing any code.")
    h2("5.2 Test cases")
    para("Unit tests verify the correctness of the reasoning engine. The key test checks that a Bayesian "
         "network with the naive structure (Result as the only parent of every feature) reproduces the "
         "Naive Bayes posterior to nine decimal places — two independent implementations agreeing.")
    table(test_rows, [W - 2.5, 2.5])
    caption(f"Table 5. Unit test results — {test_result.testsRun} run, "
            f"{len(test_result.failures) + len(test_result.errors)} failed")

    # ---------------------------------------------------------- 6. evaluation
    metric_rows = [["Metric", "Meaning"],
                   ["Accuracy", "Fraction of students classified correctly (Fail if P(Fail) ≥ 0.5)"],
                   ["Precision (Fail)", "Of the students flagged as Fail, the fraction who really failed"],
                   ["Recall (Fail)", "Of the students who failed, the fraction the system caught — most important"],
                   ["F1", "Harmonic mean of precision and recall"],
                   ["Log loss", "−mean ln P(true outcome); penalises confident wrong probabilities"],
                   ["Brier score", "Mean squared error of P(Fail); probability calibration"],
                   ["Avg decision cost", "Mean realised cost of the chosen actions (Table 2); lower is better"]]
    hold_rows = [["Model", "Accuracy", "Precision", "Recall", "F1", "Log loss", "Brier", "Avg cost"]] + [
        [n, f3(s["accuracy"]), f3(s["precision"]), f3(s["recall"]), f3(s["f1"]), f3(s["log_loss"]),
         f3(s["brier"]), f3(s["avg_cost"])] for n, s in holdout.items()]
    cv_rows = [["Model", "Accuracy", "Recall (Fail)", "F1", "Log loss", "Avg cost"]] + [
        [n] + ["%.3f ± %.3f" % cvm(n, k) for k in ("accuracy", "recall", "f1", "log_loss", "avg_cost")]
        for n in names]
    cm_rows = [["Model", "Actual Fail, Pred. Fail (TP)", "Actual Fail, Pred. Pass (FN)",
                "Actual Pass, Pred. Fail (FP)", "Actual Pass, Pred. Pass (TN)"]] + [
        [n, holdout[n]["tp"], holdout[n]["fn"], holdout[n]["fp"], holdout[n]["tn"]]
        for n in ("Bayesian Network", "Naive Bayes", "Decision Tree (ID3)", "Rule-based")]
    short = ["Bayesian Net", "Naive Bayes", "Decision Tree", "Rule-based", "Prior only"]

    page_break()
    h1("6. Performance Evaluation")
    h2("6.1 Metrics")
    para("Fail is treated as the positive class because detecting at-risk students is the goal. Both "
         "classification quality and probability quality are measured, plus the quality of the final "
         "decisions.")
    table(metric_rows, [3.6, W - 3.6])
    caption("Table 6. Evaluation metrics")
    h2("6.2 Hold-out test set")
    table(hold_rows, [3.9] + [(W - 3.9) / 7] * 7)
    caption(f"Table 7. Results on the {len(test)}-student hold-out test set")
    table(cm_rows, [3.9] + [(W - 3.9) / 4] * 4)
    caption("Table 8. Confusion matrices on the hold-out test set")
    h2("6.3 5-fold cross-validation")
    table(cv_rows, [3.5] + [(W - 3.5) / 5] * 5)
    caption("Table 9. 5-fold cross-validation results (mean ± standard deviation)")
    figure(bar_chart(short, [[cvm(n, "accuracy")[0] for n in names], [cvm(n, "f1")[0] for n in names],
                             [cvm(n, "recall")[0] for n in names]],
                     ["Accuracy", "F1", "Recall (Fail)"], "5-fold CV: classification quality", 1.0, 0.2), 14.5)
    caption("Figure 2. Classification metrics by model")
    figure(bar_chart(short, [[cvm(n, "avg_cost")[0] for n in names]], ["Avg cost"],
                     "5-fold CV: average decision cost (lower is better)", 2.5, 0.5), 14.5)
    caption("Figure 3. Average decision cost by model")

    # ---------------------------------------------------------- 7. comparison
    rb = cvm("Rule-based", "log_loss")[0]
    comp_rows = [["Capability", "Bayesian Net", "Naive Bayes", "Decision Tree", "Rule-based"],
                 ["Calibrated probabilities", "Yes (best)", "Over-confident", "Yes", "No (0/1 only)"],
                 ["Handles missing inputs", "Exact marginalisation", "Skips feature", "Stops at node", "Partially"],
                 ["Infers unknown inputs", "Yes", "No", "No", "No"],
                 ["Diagnostic queries (effect → cause)", "Yes", "Limited", "No", "No"],
                 ["Uses domain knowledge", "Graph structure", "No", "No", "Hand-written rules"],
                 ["Explainability", "CPTs + queries", "Evidence weights", "Tree paths (large)", "Rules"],
                 ["Learns from data", "Yes", "Yes", "Yes", "No"]]
    page_break()
    h1("7. Comparison with Alternative Approaches")
    para("Three alternative approaches were implemented to put the Bayesian models in context: an "
         "<b>ID3 decision tree</b> (information-gain splits, maximum depth 4, smoothed leaf probabilities), "
         "a <b>rule-based system</b> encoding typical teacher heuristics (at risk if attendance is Low, or "
         "internal marks are Poor, or previous GPA is Poor and assignments are incomplete), and a "
         "<b>prior-only</b> baseline that ignores the student.")
    table(comp_rows, [4.4] + [(W - 4.4) / 4] * 4)
    caption("Table 10. Qualitative comparison")
    bullets([
        "<b>Bayesian network vs Naive Bayes.</b> The network is more accurate and better calibrated. "
        "Naive Bayes has higher recall but more false alarms, and it is over-confident because it "
        "double-counts correlated evidence.",
        "<b>Bayesian network vs Decision tree.</b> Accuracy is similar, but the tree is a classifier only: "
        "it cannot answer diagnostic queries or infer missing inputs, and its learned structure (tens of "
        "leaves) is harder to explain than a six-node network.",
        f"<b>Bayesian models vs Rule-based.</b> The rules are reasonable classifiers, but they are certain "
        f"even when wrong, giving a log loss of {rb:.2f} — about seven times worse. Without probabilities "
        "the expected-cost decision cannot be made, and their decision cost is the highest of all "
        "approaches except the prior-only baseline.",
        "<b>Prior-only.</b> Shows that the evidence adds real value: decision cost falls by almost half "
        "when the student's data is used.",
    ])

    # ---------------------------------------------------------- 8. results & discussion
    examples = [
        ("No evidence (prior)", {}),
        ("Low attendance", {"Attendance": "Low"}),
        ("Low attendance + good internal marks", {"Attendance": "Low", "InternalMarks": "Good"}),
        ("High study hours + assignments complete (marks unknown)", {"StudyHours": "High", "Assignments": "Complete"}),
        ("Weak on every measure", {"StudyHours": "Low", "Attendance": "Low", "PrevGPA": "Poor",
                                   "InternalMarks": "Poor", "Assignments": "Incomplete"}),
        ("Mixed profile", {"StudyHours": "Medium", "Attendance": "Medium", "PrevGPA": "Average",
                           "InternalMarks": "Average", "Assignments": "Incomplete"}),
    ]
    ex_rows = [["Case", "BN P(Fail)", "NB P(Fail)", "Decision (BN)"]]
    for label, e in examples:
        p_bn, p_nb = bn.predict_proba(e), nb.predict_proba(e)
        ex_rows.append([label, f3(p_bn["Fail"]), f3(p_nb["Fail"]), decision.decide(p_bn)[0]])
    fmt = lambda d: ", ".join(f"{k} {v:.2f}" for k, v in d.items())
    e_missing = {"StudyHours": "High", "Assignments": "Complete"}
    lk_rows = [["Feature = value", "P(v | Pass)", "P(v | Fail)", "Weight ln(ratio)"]]
    for f in FEATURES:
        for v in STATES[f]:
            pp, pf = nb.likelihood[f]["Pass"][v], nb.likelihood[f]["Fail"][v]
            lk_rows.append([f"{f} = {v}", f3(pp), f3(pf), f"{math.log(pf / pp):+.2f}"])
    actions = Counter(decision.decide(bn.predict_proba(r))[0] for r in test)
    bn_acc, bn_cost = cvm("Bayesian Network", "accuracy")[0], cvm("Bayesian Network", "avg_cost")[0]
    prior_cost = cvm("Prior only", "avg_cost")[0]

    page_break()
    h1("8. Results and Discussion")
    h2("8.1 Reasoning examples")
    table(ex_rows, [W - 7.5, 2.2, 2.2, 3.1])
    caption("Table 11. Posterior probabilities and decisions for representative students")
    bullets([
        "Low attendance alone raises P(Fail) from about 0.31 to above 0.5, enough to trigger intensive "
        "intervention.",
        "Adding <i>good internal marks</i> shows the key difference between the models: Naive Bayes "
        "collapses to almost 0, treating the marks as independent strong evidence, while the network keeps "
        "a moderate risk because attendance also directly affects the final result. The network's answer "
        "is the more cautious and realistic one.",
        "With internal marks unknown, the network infers them from study hours and assignments — "
        f"P(InternalMarks | e) = {fmt(bn.query('InternalMarks', e_missing))}, compared with the "
        f"unconditional {fmt(bn.query('InternalMarks', {}))}.",
    ])
    h2("8.2 Diagnostic reasoning")
    para(f"Reasoning from effect to cause: P(StudyHours) = {fmt(bn.query('StudyHours', {}))}, but "
         f"P(StudyHours | Result = Fail) = {fmt(bn.query('StudyHours', {TARGET: 'Fail'}))}. Knowing a "
         "student failed makes low study hours about 50% more likely — useful for planning remedial "
         "programmes.")
    h2("8.3 Evidence strength (learned likelihoods)")
    table(lk_rows, [5.5, 3.0, 3.0, 3.5])
    caption("Table 12. Naive Bayes likelihoods; positive weight pushes towards Fail")
    para("Poor internal marks are by far the strongest single indicator of failure (likelihood ratio above "
         "20), followed by low attendance, low study hours and poor previous GPA. Good internal marks are "
         "almost conclusive evidence of passing.")
    h2("8.4 Decisions")
    para(f"On the {len(test)}-student test set the system recommended: " + ", ".join(
        f"<b>{a}</b> for {actions[a]}" for a in decision.ACTIONS) + ". The average realised cost fell from "
         f"{prior_cost:.2f} (no student information) to {bn_cost:.2f} with the Bayesian network.")
    h2("8.5 Limitations")
    bullets([
        "The data is synthetic; results should be validated on real institutional data.",
        "The network structure is designed by hand; it could be learned from data (e.g. hill-climbing "
        "with the BIC score).",
        "CPT learning ignores rows with missing parents; the EM algorithm would use all data.",
        "Continuous measures are discretised into three states, which loses some information.",
    ])

    # ---------------------------------------------------------- 9. demonstration
    demo1 = demo_output(["--attendance", "58", "--study-hours", "4", "--assignments", "5"])
    demo2 = demo_output(["--attendance", "88", "--study-hours", "14", "--prev-gpa", "8.4",
                         "--internal-marks", "38", "--assignments", "9"])
    page_break()
    h1("9. Demonstration of the Working Prototype")
    para("The prototype <code>demo.py</code> is a command-line application. A user enters any of the five "
         "indicators as numbers (e.g. attendance 58) or category names (e.g. Low); anything left blank is "
         "treated as unknown. It can be run interactively (questions are asked one by one) or with "
         "arguments. For each student it shows the posterior from both models, the step-by-step Bayesian "
         "update, the strength of each piece of evidence, inferred values for unknown inputs, and the "
         "expected cost of each action with the recommendation.")
    h2("Case 1 — at-risk student with incomplete data")
    para("<code>python demo.py --attendance 58 --study-hours 4 --assignments 5</code>",
         align=WD_ALIGN_PARAGRAPH.LEFT)
    code(demo1)
    para("Previous GPA and internal marks were not supplied; the network inferred that the student most "
         "likely has poor internal marks and still recommends intensive intervention.")
    h2("Case 2 — strong student")
    para("<code>python demo.py --attendance 88 --study-hours 14 --prev-gpa 8.4 --internal-marks 38 "
         "--assignments 9</code>", align=WD_ALIGN_PARAGRAPH.LEFT)
    code(demo2)

    # ---------------------------------------------------------- 10. conclusion
    page_break()
    h1("10. Conclusion")
    para("This project developed a Student Performance Decision System based on Bayesian reasoning. The "
         "problem was formulated as probabilistic inference over six discrete random variables followed by "
         "a minimum-expected-cost decision over three interventions. Naive Bayes and a Bayesian network "
         "with exact inference by enumeration were implemented from scratch in Python, evaluated with "
         "classification, calibration and decision-cost metrics, and compared with a decision tree, a "
         "rule-based system and a prior-only baseline.")
    para(f"The Bayesian network gave the best overall performance — {bn_acc:.1%} cross-validated "
         f"accuracy, the lowest log loss and the lowest average decision cost ({bn_cost:.2f}, against "
         f"{prior_cost:.2f} without student information). More importantly, it did things the alternatives "
         "cannot: it reasoned correctly with missing data, inferred unobserved indicators, answered "
         "diagnostic questions, and avoided the over-confidence that Naive Bayes shows when evidence is "
         "correlated. Separating inference from the decision lets an institution adjust its intervention "
         "costs without retraining.")
    para("<b>Future work:</b> validate on real student records; learn the network structure from data; use "
         "EM to learn from incomplete records; add continuous (Gaussian) nodes; track students across the "
         "semester with a dynamic Bayesian network; and provide a web or GUI front end for teachers.")
    h1("References")
    bullets([
        "S. Russell and P. Norvig, <i>Artificial Intelligence: A Modern Approach</i>, 4th ed., Pearson, "
        "2021 — Chapters 12–13 (Quantifying uncertainty, Probabilistic reasoning) and 15–16 (Making "
        "simple decisions).",
        "J. Pearl, <i>Probabilistic Reasoning in Intelligent Systems: Networks of Plausible Inference</i>, "
        "Morgan Kaufmann, 1988.",
        "D. Koller and N. Friedman, <i>Probabilistic Graphical Models: Principles and Techniques</i>, MIT "
        "Press, 2009.",
        "J. R. Quinlan, \"Induction of decision trees,\" <i>Machine Learning</i>, vol. 1, pp. 81–106, 1986.",
        "P. Cortez and A. Silva, \"Using data mining to predict secondary school student performance,\" "
        "Proc. FUBUTEC, 2008 (UCI Student Performance dataset).",
    ])

    OUT_PATH.parent.mkdir(exist_ok=True)
    doc.save(OUT_PATH)
    print(f"Wrote {OUT_PATH}")


if __name__ == "__main__":
    build()
