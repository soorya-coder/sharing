# MEMO pad

A mobile-first notes app with nested folders, notes, and tasks inside notes.
Plain **HTML + Tailwind CSS + vanilla JavaScript** (native ES modules), no build step,
no Node.js. Data lives in the browser (IndexedDB via Dexie) and the app works fully offline as a PWA.

- Folders nest to any depth; breadcrumbs, rename, recolor, move, delete (with Undo)
- Notes with title, auto-growing body, color, autosave, drag to reorder or drag onto a folder to move
- Tasks inside notes: check off, inline rename, drag to reorder, "Completed" section, delete with Undo
- Search across folder names, note titles/bodies and task titles at every level
- Export / import all data as JSON (tap the avatar)
- Installable PWA with offline support

---

## Run it

The app must be served over HTTP (ES modules don't load from `file://`). Any static server works.

### VS Code Live Server (recommended)

1. Install the **Live Server** extension (Ritwick Dey) in VS Code.
2. Open this folder (`memo pad`) in VS Code.
3. Right-click `index.html` → **Open with Live Server**.
   It opens at `http://127.0.0.1:5500/index.html`.

After changing CSS or JS, press **Ctrl+F5** if the browser shows an old version.

### Python (alternative)

Python 3 is installed on this machine, so this also works from the project folder:

```bash
python -m http.server 8000
```

Then open <http://localhost:8000/>.

### Sample data

On `localhost` / `127.0.0.1` a developer helper is available. Open DevTools → Console and run:

```js
await memoDev.seed()
```

It adds a few folders, notes and tasks. (It is not exposed on any other host.)

### On your phone

- **Same Wi-Fi, quick check:** open `http://<your-PC-IP>:5500/` on the phone. Everything works except
  offline mode and install, because service workers need a secure context (https or localhost).
- **Full PWA on the phone:** host the folder on any https static host (e.g. Firebase Hosting:
  `firebase deploy` once Node is available, or drag-and-drop to Netlify), then use
  "Add to Home screen" / "Install app".

### Install as an app / offline

Tap the **avatar** (top-left) → **Install app**:

- **Chrome / Edge (Android, Windows, Mac):** shows the browser's install prompt. The app then opens
  in its own window / from the home screen, with the MEMO pad icon.
- **iPhone / iPad (Safari):** Safari has no install prompt, so the app shows the steps:
  Share → **Add to Home Screen** → Add.
- Other browsers, or a plain `http://192.168.x.x` address: the app explains what's needed
  (Chrome/Edge, https or localhost).
- Once installed, the option disappears from the menu.

To test offline: DevTools → Network → **Offline**, then reload.

---

## Tests

Open **`tests/tests.html`** with Live Server (or `http://localhost:8000/tests/tests.html`).
The page runs every test and shows **"N passed, 0 failed"** in green; failures are listed in red
with details in the DevTools console.

- `tests/testRunner.js` is a tiny `describe` / `it` / `beforeEach` / `assert` runner (no libraries).
- `tests/repos.test.js` tests the adapter interface, all repositories (folders, notes, tasks,
  search, backup/import) including cascade delete + undo, moves, ancestorIds and realtime subscriptions.
- The tests use a **separate IndexedDB database, `memo-pad-test`**, wiped before every test and
  deleted at the end. Your real data (`memo-pad`) is never touched.
- The service worker never caches the `tests/` folder, so tests always run the current code.

---

## Project structure

```
index.html              App page; Tailwind theme tokens (@theme) — the single place for colors, radii, shadows, fonts
manifest.json           PWA manifest
sw.js                   Service worker (offline cache) — list new source files in APP_SHELL
icons/                  PWA icons (192, 512, maskable 512, apple-touch 180, favicon 32)
vendor/                 Pinned third-party files, downloaded once (see vendor/VERSIONS.md)
  tailwindcss-browser.js  Tailwind CSS v4 browser build
  dexie.mjs               Dexie (IndexedDB) ES module
  sortable.esm.js         SortableJS ES module
  fonts/                  Kaushan Script (logo font)
src/
  main.js               Entry: routes, router start, service worker registration, dev helper
  router.js             Hash router: #/  #/folder/:id  #/note/:id  #/search  (back button aware)
  config.js             STORAGE = 'local' | 'firestore' | 'api', DB name, API/Firebase config
  lib/
    auth.js             getCurrentUser() → { id: 'local-user' } (placeholder for real auth)
    utils.js            uuid, dates, debounce, escaping, long-press, FLIP animations, highlight
    palette.js          The 30 pastel colors
    sortable.js         Shared SortableJS setup (the only file importing SortableJS)
    install.js          "Install app": captures the browser install prompt, iOS detection
    devSeed.js          Sample data for memoDev.seed()
    data/
      adapter.js        Picks the adapter from config.STORAGE (lazy import)
      adapters/
        types.js            JSDoc types: Folder, Note, Task, StorageAdapter interface
        localAdapter.js     Dexie implementation (the only file importing Dexie)
        firestoreAdapter.js Stub — every method throws "Not implemented", with TODOs
        apiAdapter.js       Stub for the future Node.js REST API
      repos/
        folderRepo.js   Folders: create, rename, move (rewrites ancestorIds), cascade delete, tree
        noteRepo.js     Notes: create, update, move, reorder, delete (+ tasks), isEmpty
        taskRepo.js     Tasks: create, rename, done, reorder, delete
        searchRepo.js   Search
        backupRepo.js   Export / validated merge-import (JSON)
        common.js       Shared helpers: base fields, undo handles, lazy subscribe
  views/
    folderView.js       Home and every folder (grid, notes, FAB, long-press menus, drag to folder)
    noteView.js         Note editor + task list
    searchView.js       Search screen
    backupMenu.js       Avatar menu: install app, export / import
  components/           UI pieces: icons, dialog, toast, fabMenu, colorPicker, folderPicker,
                        folderCard, noteCard, taskItem
  styles/main.css       Font face, per-item color tints, animations, drag states
tests/                  tests.html, testRunner.js, repos.test.js
```

### Architecture rules

- **UI never talks to storage directly.** Views/components call repositories (`folderRepo`,
  `noteRepo`, `taskRepo`, …), repositories call the **active adapter** (`getAdapter()`), and only
  `localAdapter.js` knows about Dexie.
- **Every adapter implements the same interface** (see `adapters/types.js`):
  `getFolders(parentId)`, `getFolder(id)`, `createFolder(data)`, `updateFolder(id, data)`,
  `deleteFolder(id)`, `getNotes(folderId)`, `getNote(id)`, `createNote(data)`, `updateNote(id, data)`,
  `deleteNote(id)`, `getTasks(noteId)`, `createTask(data)`, `updateTask(id, data)`, `deleteTask(id)`,
  `search(query)`, `subscribe(collection, filter, callback)` → unsubscribe function.
  All return Promises except `subscribe`.
- **Business rules live in the repositories** (ids, `ancestorIds`, cascades, sort order, undo),
  so they behave the same on every backend. Adapters only store, query, scope to the current user,
  hide deleted records, and soft-delete single records.
- **Views render from `subscribe()` callbacks**, so a realtime backend (Firestore `onSnapshot`)
  can drive the UI without UI changes. Locally this is Dexie's `liveQuery`.

### Data model (Firestore-friendly)

Three flat collections. IDs are client-generated (`crypto.randomUUID()`, with a fallback for
non-secure contexts). Every record has `id`, `userId`, `createdAt`, `updatedAt` (ms since epoch)
and `deleted` (soft delete). Dates are formatted only in the UI.

| Collection | Fields |
|---|---|
| `folders` | id, userId, name, colorHex, parentFolderId (null = Home), **ancestorIds** (all parent ids, top-down), sortOrder, createdAt, updatedAt, deleted |
| `notes` | id, userId, folderId (null = Home), title, body, colorHex, sortOrder, createdAt, updatedAt, deleted |
| `tasks` | id, userId, noteId, title, isDone, sortOrder, createdAt, updatedAt, deleted |

- Deleting a folder soft-deletes all its subfolders, notes and tasks; deleting a note soft-deletes
  its tasks. Undo clears the `deleted` flag on exactly those records.
- `ancestorIds` lets a backend find all descendants with one query (`array-contains`).

### Backup file format

`memo-pad-backup-yyyy-MM-dd.json`:

```json
{ "format": "memo-pad-backup", "version": 1, "exportedAt": 1793000000000, "userId": "local-user",
  "folders": [ … ], "notes": [ … ], "tasks": [ … ] }
```

Import **merges**: same id → updated, new id → added, nothing is deleted. Records are re-owned by
the current user, `ancestorIds` are rebuilt, items whose parent is missing go to Home, tasks whose
note is missing are skipped.

### Offline cache (sw.js)

- App files: **network first** (3 s timeout) → you always get fresh code while developing;
  offline the cached copy is used.
- `vendor/`: **cache first** (pinned versions).
- When you **add a source file**, add it to `APP_SHELL` in `sw.js` and bump `CACHE_VERSION`.
- To reset during development: DevTools → Application → Storage → **Clear site data**.

---

## Future migration

### (a) Add Firebase Firestore (still no Node.js)

Firebase's modular SDK can be imported straight from its CDN as ES modules.

1. **Create a Firebase project** in the Firebase console, add a **Web app**, and enable
   **Cloud Firestore** (and **Authentication** if you want real users).
2. **Put the web config** into `src/config.js`:

   ```js
   export const FIREBASE_CONFIG = {
     apiKey: '…', authDomain: '…', projectId: '…', storageBucket: '…', messagingSenderId: '…', appId: '…',
   };
   ```

3. **Fill in `src/lib/data/adapters/firestoreAdapter.js`.** Each method already has a TODO describing
   what to do. Pick the current SDK version from the Firebase docs and import from the CDN, e.g.:

   ```js
   import { initializeApp } from 'https://www.gstatic.com/firebasejs/<version>/firebase-app.js';
   import {
     getFirestore, collection, doc, getDoc, getDocs, setDoc, updateDoc,
     query, where, orderBy, onSnapshot,
   } from 'https://www.gstatic.com/firebasejs/<version>/firebase-firestore.js';
   import { FIREBASE_CONFIG } from '../../../config.js';

   export function createFirestoreAdapter({ getUserId }) {
     const db = getFirestore(initializeApp(FIREBASE_CONFIG));
     const mine = (name, ...clauses) => query(collection(db, name),
       where('userId', '==', getUserId()), where('deleted', '==', false), ...clauses, orderBy('sortOrder'));
     const rows = (snap) => snap.docs.map((d) => d.data());

     return {
       getFolders: async (parentId) => rows(await getDocs(mine('folders', where('parentFolderId', '==', parentId)))),
       getFolder: async (id) => {
         const s = await getDoc(doc(db, 'folders', id));
         const f = s.data();
         return f && f.userId === getUserId() && !f.deleted ? f : null;
       },
       createFolder: async (data) => { await setDoc(doc(db, 'folders', data.id), data); return data; },
       updateFolder: async (id, data) => { await updateDoc(doc(db, 'folders', id), data); return (await getDoc(doc(db, 'folders', id))).data() ?? null; },
       deleteFolder: (id) => updateDoc(doc(db, 'folders', id), { deleted: true, updatedAt: Date.now() }),
       // …notes and tasks follow the same pattern…
       subscribe(collectionName, filter, callback, onError) {
         // map filter → query: parentId/folderId/noteId → where '=='; ids/noteIds → where 'in'
         // (chunks of 30); id → doc ref. Then:
         return onSnapshot(q, (snap) => callback(rows(snap)), onError);
       },
       // search: Firestore has no full-text search — fetch the user's records and filter
       // client-side (fine for personal data), or add a search extension later.
     };
   }
   ```

   Notes:
   - Firestore *can* query `parentFolderId == null`, so Home works directly.
   - The combined `where(...) + orderBy('sortOrder')` queries need **composite indexes**; the first
     time each query runs, the Firestore error message contains a link that creates the index.
   - Enable offline persistence (`initializeFirestore(app, { localCache: persistentLocalCache() })`)
     to keep the app usable offline.

4. **Switch the adapter** in `src/config.js`:

   ```js
   export const STORAGE = 'firestore';
   ```

   Nothing in the UI or repositories changes.

5. **Auth:** replace the placeholder in `src/lib/auth.js` with Firebase Auth (also from the CDN).
   `getCurrentUser()` is synchronous today; with Firebase, wait for `onAuthStateChanged` before
   calling `start()` in `main.js`, then return `{ id: auth.currentUser.uid }`.
6. **Security rules** (Firestore → Rules), so users only see their own data:

   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{db}/documents {
       match /{col}/{id} {
         allow read, update, delete: if request.auth != null && resource.data.userId == request.auth.uid;
         allow create: if request.auth != null && request.resource.data.userId == request.auth.uid;
       }
     }
   }
   ```

7. **Move existing local data:** with `STORAGE = 'local'`, tap the avatar → **Export backup**.
   Switch to `'firestore'`, sign in, tap the avatar → **Import backup…**. The import goes through the
   adapter interface, so it writes straight into Firestore under the signed-in user.

The service worker ignores cross-origin requests, so the Firebase CDN and Firestore traffic are
handled by the browser and Firebase's own offline cache.

### (b) Move to Vite + Node.js later

All code is already standard ES modules with relative imports. Only **how vendor libraries are
loaded** changes:

1. Install **Node.js (LTS)**, then in this folder:

   ```bash
   npm init -y
   npm install dexie sortablejs @fontsource/kaushan-script
   npm install -D vite tailwindcss @tailwindcss/vite vite-plugin-pwa
   ```

2. **Replace the two vendor imports** (the only JS files that touch `vendor/`):
   - `src/lib/data/adapters/localAdapter.js`:
     `import Dexie, { liveQuery } from 'dexie';`
   - `src/lib/sortable.js`:
     `import Sortable from 'sortablejs';`
3. **Tailwind:** remove `<script src="vendor/tailwindcss-browser.js">` from `index.html`, move the
   contents of the `<style type="text/tailwindcss">` block (the `@theme static { … }` tokens) to the top
   of `src/styles/main.css` after `@import "tailwindcss";`, and replace the `@font-face` URL with
   `@import "@fontsource/kaushan-script";`.
4. **`vite.config.js`:**

   ```js
   import { defineConfig } from 'vite';
   import tailwindcss from '@tailwindcss/vite';
   import { VitePWA } from 'vite-plugin-pwa';

   export default defineConfig({
     plugins: [
       tailwindcss(),
       VitePWA({ registerType: 'autoUpdate', manifest: false, workbox: { globPatterns: ['**/*.{js,css,html,png,woff2}'] } }),
     ],
   });
   ```

   `vite-plugin-pwa` generates the precache list automatically, so delete `sw.js` and the manual
   `navigator.serviceWorker.register('./sw.js')` in `main.js` (or use `virtual:pwa-register`).
   Move `manifest.json` and `icons/` into `public/`.
5. **Scripts** in `package.json`: `"dev": "vite"`, `"build": "vite build"`, `"preview": "vite preview"`.
   Run `npm run dev`. Delete `vendor/` once everything works.
6. **Tests:** `tests/tests.html` keeps working under Vite (`/tests/tests.html`). Later you can port
   `repos.test.js` to Vitest (`describe`/`it` are already the same shape) with `fake-indexeddb`.
7. **Node.js backend:** implement the REST endpoints listed in `apiAdapter.js`'s TODOs, fill in that
   adapter with `fetch()`, and set `STORAGE = 'api'`. The backup JSON doubles as a seed/migration file.
