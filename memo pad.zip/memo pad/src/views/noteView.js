/**
 * Note editor (#/note/:id).
 *
 * - Renders from noteRepo.subscribeOne(), so a realtime backend can push changes later.
 *   Remote updates never overwrite a field the user is editing or hasn't saved yet.
 * - Autosaves 500ms after typing stops, and flushes on Save, back, route change and page hide.
 * - When you leave and the note has no title, no body and no tasks, it is discarded.
 */
import * as noteRepo from '../lib/data/repos/noteRepo.js';
import * as taskRepo from '../lib/data/repos/taskRepo.js';
import * as folderRepo from '../lib/data/repos/folderRepo.js';
import { debounce, escapeHtml, flip } from '../lib/utils.js';
import { actionSheet } from '../components/dialog.js';
import { pickFolder } from '../components/folderPicker.js';
import { makeSortable } from '../lib/sortable.js';
import { back } from '../router.js';
import { showToast, showUndoToast } from '../components/toast.js';
import { renderTaskItem, editTaskTitle } from '../components/taskItem.js';
import { pickColor } from '../components/colorPicker.js';
import * as icons from '../components/icons.js';

/** @typedef {import('../lib/data/adapters/types.js').Note} Note */
/** @typedef {import('../lib/data/adapters/types.js').Task} Task */

/**
 * Task list + "Add new task" bar for one note.
 * Open tasks come first, completed ones below (each group keeps its manual order).
 * DOM nodes are reused by id so toggles animate smoothly instead of re-rendering.
 * @param {HTMLElement} section
 * @param {string} noteId
 * @returns {() => void} cleanup
 */
function mountTaskList(section, noteId) {
  section.innerHTML = `
    <h2 data-open-head hidden class="mb-4 px-2 text-sm font-bold uppercase tracking-[0.18em] text-slate">
      Tasks <span data-open-count class="ml-1 rounded-full bg-pill px-2 py-0.5 text-xs text-slate"></span>
    </h2>
    <ul data-open class="flex flex-col gap-5"></ul>
    <button type="button" data-done-head hidden aria-expanded="true"
      class="completed-heading mb-4 mt-8 flex w-full items-center gap-2 px-2 text-left text-sm font-bold uppercase tracking-[0.18em]">
      Completed <span data-done-count class="completed-chip rounded-full px-2 py-0.5 text-xs"></span>
      <span data-chevron class="ml-auto text-slate transition-transform">${icons.chevronRight('size-4 rotate-90')}</span>
    </button>
    <ul data-done class="flex flex-col gap-5"></ul>
    <form data-add class="mx-2 mt-7 flex items-center gap-3 rounded-full bg-linear-to-r from-white via-pill to-white py-2 pl-7 pr-3 shadow-soft">
      <label class="sr-only" for="new-task">Add new task</label>
      <input id="new-task" type="text" placeholder="Add new task" autocomplete="off" maxlength="300" enterkeyhint="done"
        class="min-w-0 flex-1 bg-transparent py-3 text-[22px] tracking-[0.14em] text-ink outline-none placeholder:text-slate">
      <button type="submit" aria-label="Add task"
        class="flex size-11 shrink-0 items-center justify-center rounded-full bg-ink text-white transition active:scale-90">
        ${icons.plus('size-6')}
      </button>
    </form>`;

  const openList = /** @type {HTMLElement} */ (section.querySelector('[data-open]'));
  const doneList = /** @type {HTMLElement} */ (section.querySelector('[data-done]'));
  const form = /** @type {HTMLFormElement} */ (section.querySelector('[data-add]'));
  const input = /** @type {HTMLInputElement} */ (form.querySelector('input'));

  /** @type {Task[]} */
  let tasks = [];
  /** @type {Map<string, HTMLElement>} */
  const nodes = new Map();
  let busy = false; // dragging or editing: hold re-renders until done
  let dirty = false;

  /** @param {Task} t */
  function nodeFor(t) {
    let el = nodes.get(t.id);
    if (!el) {
      el = renderTaskItem(t);
      nodes.set(t.id, el);
      return el;
    }
    el.classList.toggle('is-done', t.isDone);
    const check = /** @type {HTMLElement} */ (el.querySelector('[data-act=toggle]'));
    check.setAttribute('aria-checked', String(t.isDone));
    check.setAttribute('aria-label', t.isDone ? 'Mark as not done' : 'Mark as done');
    const title = el.querySelector('.task-title');
    if (title && title.textContent !== t.title) title.textContent = t.title;
    return el;
  }

  function render() {
    if (busy) {
      dirty = true;
      return;
    }
    dirty = false;
    flip(section, () => {
      const ids = new Set(tasks.map((t) => t.id));
      for (const [id, el] of nodes) {
        if (!ids.has(id)) { el.remove(); nodes.delete(id); }
      }
      const open = tasks.filter((t) => !t.isDone);
      const done = tasks.filter((t) => t.isDone);
      openList.replaceChildren(...open.map(nodeFor));
      doneList.replaceChildren(...done.map(nodeFor));
      openHead.hidden = open.length === 0;
      openCount.textContent = String(open.length);
      doneHead.hidden = done.length === 0;
      doneCount.textContent = String(done.length);
      doneList.hidden = done.length === 0 || collapsed;
    });
  }

  // "Completed" header collapses/expands the finished tasks.
  const openHead = /** @type {HTMLElement} */ (section.querySelector('[data-open-head]'));
  const openCount = /** @type {HTMLElement} */ (section.querySelector('[data-open-count]'));
  const doneHead = /** @type {HTMLElement} */ (section.querySelector('[data-done-head]'));
  const doneCount = /** @type {HTMLElement} */ (section.querySelector('[data-done-count]'));
  const chevron = /** @type {HTMLElement} */ (section.querySelector('[data-chevron]'));
  let collapsed = false;
  doneHead.addEventListener('click', () => {
    collapsed = !collapsed;
    doneHead.setAttribute('aria-expanded', String(!collapsed));
    chevron.style.transform = collapsed ? 'rotate(-90deg)' : '';
    doneList.hidden = collapsed;
  });

  const unsubscribe = taskRepo.subscribeForNote(noteId, (rows) => {
    tasks = rows;
    render();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = input.value.trim();
    if (!title) {
      input.focus();
      return;
    }
    input.value = '';
    input.focus(); // keep the keyboard open for the next task
    await taskRepo.create({ noteId, title });
  });

  section.addEventListener('click', async (e) => {
    const target = /** @type {HTMLElement} */ (e.target);
    const act = target.closest('[data-act]')?.getAttribute('data-act');
    const item = /** @type {HTMLElement | null} */ (target.closest('li[data-id]'));
    const task = tasks.find((t) => t.id === item?.dataset.id);
    if (!item || !task) return;

    if (act === 'toggle') {
      await taskRepo.setDone(task.id, !task.isDone);
    } else if (act === 'delete') {
      const handle = await taskRepo.remove(task.id);
      showUndoToast('Task deleted', handle);
    } else if (act === 'edit') {
      busy = true;
      const title = await editTaskTitle(item);
      if (title) await taskRepo.rename(task.id, title);
      busy = false;
      if (dirty) render();
    }
  });

  // Drag to reorder within each group (open / completed). On touch, a short hold starts the drag
  // so taps and scrolling keep working.
  /** @type {import('../lib/sortable.js').SortableHandlers} */
  const sortHandlers = {
    filter: '[data-act=toggle], [data-act=delete], input',
    onDragState: (on) => {
      busy = on;
      if (!on && dirty) setTimeout(render, 0);
    },
    onReorder: (ids) => taskRepo.reorder(ids),
  };
  const allTasks = () => /** @type {HTMLElement[]} */ ([...openList.children, ...doneList.children]);
  const sortables = [
    makeSortable(openList, { ...sortHandlers, group: 'open' }, allTasks),
    makeSortable(doneList, { ...sortHandlers, group: 'done' }, allTasks),
  ];

  return () => {
    unsubscribe();
    sortables.forEach((s) => s.destroy());
  };
}

/**
 * Grows a textarea to fit its content (fallback for browsers without `field-sizing: content`).
 * @param {HTMLTextAreaElement} el
 */
function autoGrow(el) {
  if (CSS.supports('field-sizing', 'content')) return;
  el.style.height = 'auto';
  el.style.height = `${el.scrollHeight}px`;
}

/**
 * @param {HTMLElement} outlet
 * @param {{ id: string }} params
 * @returns {() => Promise<void>} cleanup (saves, then discards the note if it is empty)
 */
export function noteView(outlet, params) {
  const noteId = params.id;

  outlet.innerHTML = `
    <div class="tinted min-h-dvh" data-root style="--c: #FFCBA8">
      <header class="app-header note-header sticky top-0 z-20 bg-[var(--c-tint)] px-4 pb-2 pt-[max(0.5rem,env(safe-area-inset-top))] transition-colors">
        <!-- Top row: back · NOTES (or the note title once scrolled) · color · more -->
        <div class="flex h-11 items-center gap-2">
          <button data-act="back" class="flex size-9 shrink-0 items-center justify-center rounded-full bg-white/80 text-orange shadow-soft transition active:scale-90" aria-label="Save and go back">
            ${icons.backTriangle('size-[18px]')}
          </button>
          <div class="relative min-w-0 flex-1">
            <h1 class="note-header-label text-[21px] font-semibold tracking-[0.14em] text-orange-text">Notes</h1>
            <p class="note-header-title absolute inset-0 truncate text-[17px] font-semibold leading-[32px] text-ink" aria-hidden="true" data-compact-title></p>
          </div>
          <button data-act="color" class="flex h-9 shrink-0 items-center gap-1.5 rounded-full bg-white/90 pl-1 pr-3.5 shadow-soft transition active:scale-95" aria-label="Change note color">
            <span class="size-7 rounded-full bg-[var(--c-dot)] shadow-[inset_0_0_0_2px_rgb(255_255_255/0.7)]" data-dot></span>
            <span class="text-[15px] text-ink">color</span>
          </button>
          <button data-act="more" class="flex size-9 shrink-0 items-center justify-center rounded-full bg-white/80 text-slate shadow-soft transition active:scale-90" aria-label="Note options">
            ${icons.more('size-5')}
          </button>
        </div>
        <!-- Where the note lives (collapses while scrolling) -->
        <div class="header-hero">
          <nav class="no-scrollbar -mx-1 mt-1.5 flex items-center gap-1 overflow-x-auto whitespace-nowrap px-1 py-0.5 text-[13px]" aria-label="Note location" data-location></nav>
        </div>
      </header>

      <main class="px-6 pb-40 pt-6" data-main>
        <label class="sr-only" for="note-title">Title</label>
        <input id="note-title" data-title type="text" placeholder="Title" autocomplete="off" maxlength="300"
          class="w-full bg-transparent text-[30px] leading-tight tracking-wide text-ink outline-none placeholder:text-ink/85">
        <label class="sr-only" for="note-body">Notes</label>
        <textarea id="note-body" data-body rows="2" placeholder="Notes"
          class="note-body mt-6 w-full resize-none bg-transparent text-[20px] leading-relaxed tracking-wide text-ink outline-none placeholder:text-ink/85"></textarea>
        <section data-tasks class="mt-8"></section>
      </main>

      <button data-act="save" aria-label="Save"
        class="fab-anchor fixed z-40 flex size-16 items-center justify-center rounded-[22px] bg-[var(--c-fab)] text-ink shadow-fab transition active:scale-90">
        ${icons.check('size-8')}
      </button>
    </div>`;

  const root = /** @type {HTMLElement} */ (outlet.querySelector('[data-root]'));
  const titleEl = /** @type {HTMLInputElement} */ (outlet.querySelector('[data-title]'));
  const bodyEl = /** @type {HTMLTextAreaElement} */ (outlet.querySelector('[data-body]'));
  const destroyTasks = mountTaskList(/** @type {HTMLElement} */ (outlet.querySelector('[data-tasks]')), noteId);

  /** @type {Note | null} */
  let note = null;
  let loaded = false;
  let missing = false;
  let leaving = false;

  /** Fields typed but not yet written. */
  /** @type {{ title?: string, body?: string }} */
  let pending = {};
  /** Chain of writes, so flush() can wait for one that is already in flight. */
  /** @type {Promise<unknown>} */
  let writes = Promise.resolve();

  function writePending() {
    const patch = pending;
    pending = {};
    if (Object.keys(patch).length) {
      writes = writes.then(() => noteRepo.update(noteId, patch)).catch((err) => {
        console.error('Saving note failed', err);
        showToast('Could not save the note');
      });
    }
    return writes;
  }

  const save = debounce(writePending, 500);

  /** Writes any pending changes now and waits until every write has finished. */
  async function flush() {
    save.cancel();
    await writePending();
  }

  titleEl.addEventListener('input', () => {
    pending.title = titleEl.value;
    save();
  });
  bodyEl.addEventListener('input', () => {
    pending.body = bodyEl.value;
    autoGrow(bodyEl);
    save();
  });
  titleEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      bodyEl.focus();
    }
  });

  /** @param {Note} n */
  function applyColor(n) {
    root.style.setProperty('--c', n.colorHex);
  }

  // ---- Header: location chips, compact title, shrink on scroll
  const headerEl = /** @type {HTMLElement} */ (root.querySelector('.note-header'));
  const locationEl = /** @type {HTMLElement} */ (root.querySelector('[data-location]'));
  const compactTitleEl = /** @type {HTMLElement} */ (root.querySelector('[data-compact-title]'));
  /** @type {string | null | undefined} */
  let shownFolderId;

  /** @param {string | null} folderId */
  async function renderLocation(folderId) {
    if (folderId === shownFolderId) return;
    shownFolderId = folderId;
    const path = await folderRepo.getPath(folderId);
    const chip = (/** @type {string} */ href, /** @type {string} */ label, /** @type {boolean} */ home) =>
      `<a href="#${href}" class="flex items-center gap-1.5 rounded-full bg-white/55 px-2.5 py-0.5 text-slate transition hover:bg-white/80 hover:text-ink">${home ? icons.homeFilled('size-3.5') : icons.folder('size-3.5')}${escapeHtml(label)}</a>`;
    const sep = `<span class="shrink-0 text-slate/50">${icons.chevronRight('size-3.5')}</span>`;
    locationEl.innerHTML = [chip('/', 'Home', true), ...path.map((f) => chip(`/folder/${f.id}`, f.name, false))].join(sep);
    locationEl.scrollLeft = locationEl.scrollWidth;
  }

  const syncCompactTitle = () => { compactTitleEl.textContent = titleEl.value.trim() || 'Untitled'; };
  titleEl.addEventListener('input', syncCompactTitle);

  const onScroll = () => {
    const y = window.scrollY;
    const room = document.documentElement.scrollHeight - window.innerHeight;
    if (y > 40 && room > 120) headerEl.classList.add('is-compact');
    else if (y < 12) headerEl.classList.remove('is-compact');
  };
  window.addEventListener('scroll', onScroll, { passive: true });

  const unsubscribe = noteRepo.subscribeOne(noteId, (n) => {
    if (!n) {
      if (!loaded && !leaving) renderMissing();
      return;
    }
    note = n;
    applyColor(n);
    // Fill fields on first load; afterwards only take remote values for fields that
    // aren't focused and have no unsaved local edits.
    if (!loaded || (document.activeElement !== titleEl && pending.title === undefined)) {
      if (titleEl.value !== n.title) titleEl.value = n.title;
    }
    if (!loaded || (document.activeElement !== bodyEl && pending.body === undefined)) {
      if (bodyEl.value !== n.body) bodyEl.value = n.body;
    }
    autoGrow(bodyEl);
    syncCompactTitle();
    renderLocation(n.folderId);
    if (!loaded) {
      loaded = true;
      // New, blank notes start with the cursor in the title.
      if (!n.title && !n.body) titleEl.focus();
    }
  });

  function renderMissing() {
    missing = true;
    outlet.innerHTML = `
      <div class="pop-in flex flex-col items-center px-6 py-24 text-center">
        <p class="text-lg font-bold">This note doesn’t exist</p>
        <p class="mt-1 text-slate">It may have been deleted.</p>
        <a href="#/" class="mt-6 rounded-full bg-slate px-6 py-3 font-semibold text-white">Go Home</a>
      </div>`;
  }

  async function changeColor() {
    if (!note) return;
    const hex = await pickColor({ initial: note.colorHex });
    if (hex && hex !== note.colorHex) await noteRepo.update(noteId, { colorHex: hex });
  }

  /** Saves and returns to the note's folder. */
  async function saveAndLeave() {
    await flush();
    back(note?.folderId ? `/folder/${note.folderId}` : '/');
  }

  /** "More" menu: move the note to another folder, or delete it (with Undo). */
  async function openMenu() {
    if (!note) return;
    const choice = await actionSheet({
      title: titleEl.value.trim() || 'Untitled',
      items: [
        { label: 'Move to…', value: 'move', icon: icons.move() },
        { label: 'Delete note', value: 'delete', icon: icons.trash(), danger: true },
      ],
    });
    if (choice === 'move') {
      const from = note.folderId;
      const target = await pickFolder({
        title: `Move “${titleEl.value.trim() || 'Untitled'}” to…`,
        tree: await folderRepo.listTree(),
        currentId: from,
      });
      if (!target) return;
      await flush();
      await noteRepo.move(noteId, target.id);
      const name = target.id ? (await folderRepo.get(target.id))?.name ?? 'folder' : 'Home';
      showUndoToast(`Moved to ${name}`, { undo: async () => { await noteRepo.move(noteId, from); } });
    }
    if (choice === 'delete') {
      const folderId = note.folderId;
      await flush();
      missing = true; // the note is gone: skip the "discard if empty" check on exit
      const handle = await noteRepo.remove(noteId);
      back(folderId ? `/folder/${folderId}` : '/');
      showUndoToast(`Deleted “${note.title.trim() || 'Untitled'}”`, handle);
    }
  }

  // Listen on the view's own root (not `outlet`, which outlives this view).
  root.addEventListener('click', (e) => {
    const act = /** @type {HTMLElement} */ (e.target).closest('[data-act]')?.getAttribute('data-act');
    if (act === 'back' || act === 'save') saveAndLeave();
    if (act === 'color') changeColor();
    if (act === 'more') openMenu();
  });

  // Save when the tab is hidden or closed (mobile browsers may kill the page without a route change).
  const onHide = () => { if (document.visibilityState === 'hidden') flush(); };
  document.addEventListener('visibilitychange', onHide);
  window.addEventListener('pagehide', onHide);

  return async () => {
    leaving = true;
    document.removeEventListener('visibilitychange', onHide);
    window.removeEventListener('pagehide', onHide);
    window.removeEventListener('scroll', onScroll);
    unsubscribe();
    destroyTasks();
    if (missing) return;
    await flush();
    if (await noteRepo.isEmpty(noteId)) await noteRepo.remove(noteId);
  };
}
