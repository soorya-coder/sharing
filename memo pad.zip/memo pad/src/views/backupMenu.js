/**
 * Profile menu (tap the avatar): install the app, export all data as a JSON file, or import one.
 */
import * as backupRepo from '../lib/data/repos/backupRepo.js';
import { formatDate } from '../lib/utils.js';
import { installMode, promptInstall, isIOS } from '../lib/install.js';
import { actionSheet, confirmDialog, openDialog } from '../components/dialog.js';
import { showToast } from '../components/toast.js';
import * as icons from '../components/icons.js';

/**
 * "3 folders, 12 notes and 20 tasks"
 * @param {{ folders: number, notes: number, tasks: number }} c
 */
function describe(c) {
  const parts = [[c.folders, 'folder'], [c.notes, 'note'], [c.tasks, 'task']]
    .map(([n, w]) => `${n} ${w}${n === 1 ? '' : 's'}`);
  return `${parts[0]}, ${parts[1]} and ${parts[2]}`;
}

/** Downloads every folder, note and task as memo-pad-backup-yyyy-MM-dd.json. */
export async function exportBackup() {
  const backup = await backupRepo.exportAll();
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `memo-pad-backup-${formatDate(backup.exportedAt)}.json`;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast(`Exported ${describe({ folders: backup.folders.length, notes: backup.notes.length, tasks: backup.tasks.length })}`);
}

/**
 * Lets the user pick a .json file.
 * @returns {Promise<File | null>}
 */
function chooseFile() {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';
    input.addEventListener('change', () => resolve(input.files?.[0] ?? null), { once: true });
    input.addEventListener('cancel', () => resolve(null), { once: true });
    input.click();
  });
}

/** Picks a backup file, shows what it contains, and merges it in after confirmation. */
export async function importBackup() {
  const file = await chooseFile();
  if (!file) return;
  /** @type {import('../lib/data/repos/backupRepo.js').Backup} */
  let backup;
  try {
    backup = backupRepo.validateBackup(JSON.parse(await file.text()));
  } catch (err) {
    showToast(err instanceof SyntaxError ? 'That file is not valid JSON.' : /** @type {Error} */ (err).message);
    return;
  }
  const ok = await confirmDialog({
    title: 'Import backup?',
    message: `${describe({ folders: backup.folders.length, notes: backup.notes.length, tasks: backup.tasks.length })} `
      + `from ${formatDate(backup.exportedAt ?? Date.now())}. Items you already have are updated; nothing is deleted.`,
    confirmLabel: 'Import',
  });
  if (!ok) return;
  try {
    const result = await backupRepo.importAll(backup);
    showToast(`Imported ${describe(result)}${result.skipped ? ` (${result.skipped} skipped)` : ''}`);
  } catch (err) {
    console.error('Import failed', err);
    showToast(`Import failed: ${/** @type {Error} */ (err).message}`);
  }
}

/** Explains how to install when the browser can't show its own prompt. */
async function showInstallHelp() {
  const step = (/** @type {string} */ n, /** @type {string} */ html) => `
    <li class="flex items-start gap-3">
      <span class="flex size-7 shrink-0 items-center justify-center rounded-full bg-orange text-sm font-bold text-white">${n}</span>
      <span class="pt-0.5">${html}</span>
    </li>`;
  const ios = isIOS();
  await openDialog({
    title: 'Install MEMO pad',
    content: `
      <div class="flex flex-col gap-4 text-ink">
        <img src="icons/icon-192.png" alt="" class="mx-auto size-20 rounded-[22px] shadow-soft">
        <ol class="flex flex-col gap-3 text-[15px] leading-snug">
          ${ios
            ? step('1', `Tap the <b>Share</b> button <span class="inline-flex translate-y-1 text-blue">${icons.share('size-5')}</span> in Safari’s toolbar.`)
              + step('2', 'Scroll down and tap <b>Add to Home Screen</b>.')
              + step('3', 'Tap <b>Add</b>. MEMO pad opens full-screen from your home screen.')
            : step('1', 'Open MEMO pad in <b>Chrome</b> or <b>Edge</b> (Android, Windows, Mac, ChromeOS).')
              + step('2', 'Use an <b>https</b> address, or <b>localhost / 127.0.0.1</b> while developing. Plain http addresses like <code>192.168.x.x</code> can’t install.')
              + step('3', 'Tap <b>Install app</b> here again, or use the install icon in the address bar / browser menu.')}
        </ol>
      </div>`,
    actions: [{ label: 'Got it', value: 'ok', variant: 'primary' }],
  });
}

/** Runs the right install flow for this browser. */
export async function installApp() {
  const mode = installMode();
  if (mode === 'prompt') {
    const outcome = await promptInstall();
    if (outcome === 'accepted') showToast('Installing MEMO pad…');
  } else if (mode === 'installed') {
    showToast('MEMO pad is already installed');
  } else {
    await showInstallHelp();
  }
}

/** Opens the profile menu. */
export async function openProfileMenu() {
  const items = [];
  if (installMode() !== 'installed') {
    items.push({ label: 'Install app', value: 'install', icon: icons.installApp() });
  }
  items.push(
    { label: 'Export backup (JSON)', value: 'export', icon: icons.download() },
    { label: 'Import backup…', value: 'import', icon: icons.upload() },
  );
  const choice = await actionSheet({ title: 'MEMO pad', items });
  if (choice === 'install') await installApp();
  if (choice === 'export') await exportBackup();
  if (choice === 'import') await importBackup();
}
