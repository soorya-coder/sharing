/**
 * Folder view: used for Home (#/) and every folder (#/folder/:id).
 * Renders entirely from repo subscriptions, so a realtime backend can drive it later.
 */
import * as folderRepo from '../lib/data/repos/folderRepo.js';
import * as noteRepo from '../lib/data/repos/noteRepo.js';
import * as taskRepo from '../lib/data/repos/taskRepo.js';
import { DEFAULT_FOLDER_COLOR } from '../lib/data/repos/common.js';
import { escapeHtml, flip, htmlToElement, onLongPress } from '../lib/utils.js';
import { makeSortable } from '../lib/sortable.js';
import { PALETTE } from '../lib/palette.js';
import { navigate, goUp } from '../router.js';
import { renderFolderCard, folderShape } from '../components/folderCard.js';
import { renderNoteCard } from '../components/noteCard.js';
import { mountFabMenu, defaultFabActions } from '../components/fabMenu.js';
import { pickColor } from '../components/colorPicker.js';
import { pickFolder } from '../components/folderPicker.js';
import { openProfileMenu, installApp } from './backupMenu.js';
import { installMode, onInstallChange } from '../lib/install.js';
import { openDialog, confirmDialog, promptDialog, actionSheet } from '../components/dialog.js';
import { showToast, showUndoToast } from '../components/toast.js';
import * as icons from '../components/icons.js';

/** @typedef {import('../lib/data/adapters/types.js').Folder} Folder */
/** @typedef {import('../lib/data/adapters/types.js').Note} Note */
/** @typedef {import('../lib/data/adapters/types.js').Task} Task */

/**
 * Path of a folder route (null = Home).
 * @param {string | null} id
 */
const folderPath = (id) => (id ? `/folder/${id}` : '/');

/**
 * "2 subfolders, 5 notes and 7 tasks"
 * @param {{ folders: number, notes: number, tasks: number }} c
 */
function describeCounts(c) {
  const parts = [
    [c.folders, 'subfolder'], [c.notes, 'note'], [c.tasks, 'task'],
  ].filter(([n]) => n).map(([n, w]) => `${n} ${w}${n === 1 ? '' : 's'}`);
  if (!parts.length) return 'It is empty.';
  const last = parts.pop();
  return `It contains ${parts.length ? `${parts.join(', ')} and ${last}` : last}.`;
}

/**
 * Dialog with a name field and a row of pastel swatches, with a live folder preview.
 * @param {{ title: string, name?: string, colorHex?: string, confirmLabel?: string }} options
 * @returns {Promise<{ name: string, colorHex: string } | null>}
 */
async function folderFormDialog({ title, name = '', colorHex = DEFAULT_FOLDER_COLOR, confirmLabel = 'Create' }) {
  let color = colorHex;
  const content = htmlToElement(`
    <div class="flex flex-col gap-5">
      <div class="tinted mx-auto w-28" data-preview style="--c: ${escapeHtml(color)}">
        ${folderShape('ff-preview', 'w-full')}
      </div>
      <input type="text" maxlength="120" placeholder="Folder name" value="${escapeHtml(name)}"
        class="w-full rounded-full bg-white px-5 py-3 text-base shadow-soft outline-none focus:ring-2 focus:ring-blue/40">
      <div class="grid max-h-40 grid-cols-6 gap-3 overflow-y-auto p-1" role="radiogroup" aria-label="Folder color">
        ${PALETTE.map((hex) => `
          <button type="button" data-color="${hex}" role="radio" aria-label="${hex}"
            class="aspect-square rounded-full transition active:scale-90" style="background:${hex}"></button>`).join('')}
      </div>
    </div>`);
  const input = /** @type {HTMLInputElement} */ (content.querySelector('input'));
  const preview = /** @type {HTMLElement} */ (content.querySelector('[data-preview]'));
  const swatches = /** @type {NodeListOf<HTMLElement>} */ (content.querySelectorAll('[data-color]'));
  const paint = () => {
    preview.style.setProperty('--c', color);
    swatches.forEach((s) => {
      const on = s.dataset.color?.toLowerCase() === color.toLowerCase();
      s.setAttribute('aria-checked', String(on));
      s.classList.toggle('ring-3', on);
      s.classList.toggle('ring-slate', on);
      s.classList.toggle('ring-offset-2', on);
    });
  };
  content.addEventListener('click', (e) => {
    const hex = /** @type {HTMLElement} */ (e.target).closest('[data-color]')?.getAttribute('data-color');
    if (hex) { color = hex; paint(); }
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      /** @type {HTMLButtonElement | null} */ (content.closest('form')?.querySelector('button[value=ok]') ?? null)?.click();
    }
  });
  paint();

  const result = await openDialog({
    title,
    content,
    actions: [
      { label: 'Cancel', value: 'cancel', variant: 'plain' },
      { label: confirmLabel, value: 'ok', variant: 'primary' },
    ],
    onOpen: () => input.focus(),
  });
  if (result !== 'ok') return null;
  return { name: input.value.trim(), colorHex: color };
}

/**
 * Shared folder actions (header icons and the long-press menu).
 */
export const folderActions = {
  /**
   * Asks for name + color and creates a subfolder.
   * @param {string | null} parentFolderId
   */
  async create(parentFolderId) {
    const data = await folderFormDialog({ title: 'New folder' });
    if (data) await folderRepo.create({ ...data, parentFolderId });
  },

  /** @param {Folder} folder */
  async rename(folder) {
    const name = await promptDialog({ title: 'Rename folder', value: folder.name, placeholder: 'Folder name' });
    if (name) await folderRepo.rename(folder.id, name);
  },

  /**
   * Confirms with the number of affected items, soft-deletes, and offers Undo.
   * @param {Folder} folder
   * @param {() => void} [beforeDelete] e.g. leave the folder before it disappears
   */
  async remove(folder, beforeDelete) {
    const counts = await folderRepo.countContents(folder.id);
    const ok = await confirmDialog({
      title: `Delete “${folder.name}”?`,
      message: describeCounts(counts),
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    beforeDelete?.();
    const handle = await folderRepo.remove(folder.id);
    showUndoToast(`Deleted “${folder.name}”`, handle);
  },

  /** @param {Folder} folder */
  async changeColor(folder) {
    const hex = await pickColor({ initial: folder.colorHex });
    if (hex && hex !== folder.colorHex) await folderRepo.update(folder.id, { colorHex: hex });
  },

  /**
   * Folder picker; the folder itself and its subfolders can't be chosen.
   * @param {Folder} folder
   */
  async move(folder) {
    const tree = await folderRepo.listTree();
    const disabledIds = new Set(tree
      .filter(({ folder: f }) => f.id === folder.id || f.ancestorIds.includes(folder.id))
      .map(({ folder: f }) => f.id));
    const target = await pickFolder({ title: `Move “${folder.name}” to…`, tree, currentId: folder.parentFolderId, disabledIds });
    if (!target) return;
    try {
      await folderRepo.move(folder.id, target.id);
      showToast(`Moved to ${await folderName(target.id)}`);
    } catch (err) {
      showToast(/** @type {Error} */ (err).message);
    }
  },

  /**
   * Folder menu (long-press on a folder card, or "more" in the header of the open folder).
   * @param {Folder} folder
   * @param {() => void} [beforeDelete] e.g. leave the folder first when deleting the open one
   */
  async menu(folder, beforeDelete) {
    const choice = await actionSheet({
      title: folder.name,
      items: [
        { label: 'Rename', value: 'rename', icon: icons.pencil() },
        { label: 'Change color', value: 'color', icon: icons.palette() },
        { label: 'Move to…', value: 'move', icon: icons.move() },
        { label: 'Delete', value: 'delete', icon: icons.trash(), danger: true },
      ],
    });
    if (choice === 'rename') await this.rename(folder);
    if (choice === 'color') await this.changeColor(folder);
    if (choice === 'move') await this.move(folder);
    if (choice === 'delete') await this.remove(folder, beforeDelete);
  },
};

/**
 * Display name of a folder id (null = Home).
 * @param {string | null} id
 */
async function folderName(id) {
  return id ? (await folderRepo.get(id))?.name ?? 'folder' : 'Home';
}

/**
 * Note actions (long-press menu on note cards).
 */
export const noteActions = {
  /**
   * Moves a note and shows "Moved to X · Undo".
   * @param {string} noteId
   * @param {string | null} targetId destination folder (null = Home)
   * @param {string | null} fromId   where it was (for Undo)
   */
  async moveTo(noteId, targetId, fromId) {
    if (targetId === fromId) return;
    await noteRepo.move(noteId, targetId);
    showUndoToast(`Moved to ${await folderName(targetId)}`, { undo: async () => { await noteRepo.move(noteId, fromId); } });
  },

  /** @param {Note} note */
  async move(note) {
    const tree = await folderRepo.listTree();
    const label = note.title.trim() || 'Untitled';
    const target = await pickFolder({ title: `Move “${label}” to…`, tree, currentId: note.folderId });
    if (target) await this.moveTo(note.id, target.id, note.folderId);
  },

  /** @param {Note} note */
  async changeColor(note) {
    const hex = await pickColor({ initial: note.colorHex });
    if (hex && hex !== note.colorHex) await noteRepo.update(note.id, { colorHex: hex });
  },

  /** @param {Note} note */
  async remove(note) {
    const handle = await noteRepo.remove(note.id);
    showUndoToast(`Deleted “${note.title.trim() || 'Untitled'}”`, handle);
  },

  /** @param {Note} note */
  async menu(note) {
    const choice = await actionSheet({
      title: note.title.trim() || 'Untitled',
      items: [
        { label: 'Move to…', value: 'move', icon: icons.move() },
        { label: 'Change color', value: 'color', icon: icons.palette() },
        { label: 'Delete', value: 'delete', icon: icons.trash(), danger: true },
      ],
    });
    if (choice === 'move') await this.move(note);
    if (choice === 'color') await this.changeColor(note);
    if (choice === 'delete') await this.remove(note);
  },
};

/**
 * @param {HTMLElement} outlet
 * @param {{ id?: string }} params
 * @returns {() => void} cleanup
 */
export function folderView(outlet, params) {
  const folderId = params.id ?? null;
  const isHome = folderId === null;

  outlet.innerHTML = `
    <header class="app-header header-bg sticky top-0 z-20 px-4 pb-2.5 pt-[max(0.5rem,env(safe-area-inset-top))]">
      <!-- Top row: (back) avatar · MEMO pad · (search) (install) more -->
      <div class="flex h-11 items-center gap-2" data-actions>
        ${isHome ? '' : `
          <button data-act="back" class="flex size-9 shrink-0 items-center justify-center rounded-full bg-slate text-white transition active:scale-90" aria-label="Back">${icons.arrowLeft('size-5')}</button>`}
        <button type="button" data-profile class="flex size-9 shrink-0 items-center justify-center rounded-[11px] bg-avatar text-white shadow-[0_3px_8px_-3px_rgb(0_0_0/0.35)] transition active:scale-90" aria-label="App menu: install and backup">
          ${icons.user('size-5')}
        </button>
        <h1 class="flex min-w-0 items-end gap-1.5 text-slate">
          <span class="font-script text-[clamp(26px,8.5vw,34px)] leading-none">MEMO</span>
          <span class="font-script text-[clamp(13px,4vw,17px)] leading-tight">pad</span>
        </h1>
        <div class="ml-auto flex shrink-0 items-center gap-1.5">
          <a href="#/search" class="header-search-icon flex size-9 items-center justify-center rounded-full bg-white/80 text-slate shadow-soft transition active:scale-90" aria-label="Search" tabindex="-1">
            ${icons.search('size-[18px]')}
          </a>
          <button data-act="install" hidden class="flex h-9 items-center gap-1.5 rounded-full bg-white/80 px-3 text-sm font-semibold text-slate shadow-soft transition active:scale-95" aria-label="Install app">
            ${icons.installApp('size-[18px]')}<span class="hidden min-[400px]:inline">Install</span>
          </button>
          <button data-act="more" class="flex size-9 items-center justify-center rounded-full bg-white/80 text-slate shadow-soft transition active:scale-90" aria-label="${isHome ? 'More' : 'Folder options'}">
            ${icons.more('size-5')}
          </button>
        </div>
      </div>

      <!-- Search pill (opens the search screen); collapses into the top-row icon while scrolling -->
      <div class="header-search">
        <a href="#/search" class="mt-2 flex h-10 items-center gap-2.5 rounded-full bg-white/90 px-4 text-slate/80 shadow-soft transition active:scale-[.98]">
          ${icons.search('size-[18px] text-slate')}
          <span class="truncate text-[15px]">Search notes, tasks, folders…</span>
        </a>
      </div>

      <!-- Breadcrumb chips (notes can be dropped on them) + counts -->
      <div class="mt-2 flex items-center gap-2">
        <nav class="no-scrollbar -mx-1 flex min-w-0 flex-1 items-center gap-1 overflow-x-auto whitespace-nowrap px-1 py-0.5 text-[14px]" aria-label="Breadcrumb" data-crumbs></nav>
        <span class="shrink-0 text-xs font-medium text-slate/80" data-subtitle></span>
      </div>
    </header>

    <main class="px-6 pb-36 pt-6" data-main>
      <section data-folders class="grid grid-cols-2 gap-x-8 gap-y-8"></section>
      <section data-notes class="mt-8 flex flex-col gap-5"></section>
      <div data-empty hidden></div>
    </main>`;

  outlet.querySelector('[data-profile]')?.addEventListener('click', openProfileMenu);
  const crumbsEl = /** @type {HTMLElement} */ (outlet.querySelector('[data-crumbs]'));
  const foldersEl = /** @type {HTMLElement} */ (outlet.querySelector('[data-folders]'));
  const notesEl = /** @type {HTMLElement} */ (outlet.querySelector('[data-notes]'));
  const emptyEl = /** @type {HTMLElement} */ (outlet.querySelector('[data-empty]'));

  /** @type {Array<() => void>} */
  const subs = [];
  /** @type {Folder | null} */
  let current = null;
  /** @type {Folder[] | null} */
  let folders = null;
  /** @type {Note[] | null} */
  let notes = null;
  /** @type {Map<string, { done: number, total: number }>} */
  let taskStats = new Map();
  let dragging = false;
  let notesDirty = false;

  // ---------- Header ----------

  /** @param {Folder[]} ancestors */
  function renderCrumbs(ancestors) {
    // data-drop-folder lets a dragged note be dropped onto a breadcrumb ('' = Home).
    const link = (/** @type {string} */ href, /** @type {string} */ label, /** @type {string} */ dropId) =>
      `<a href="#${href}" data-drop-folder="${escapeHtml(dropId)}" class="crumb flex items-center gap-1.5 rounded-full bg-white/45 px-2.5 py-0.5 text-slate transition hover:bg-white/70 hover:text-ink">${dropId ? '' : icons.homeFilled('size-4')}${escapeHtml(label)}</a>`;
    const sep = `<span class="shrink-0 text-slate/50">${icons.chevronRight('size-3.5')}</span>`;
    const here = (/** @type {string} */ label) =>
      `<span class="crumb flex items-center gap-1.5 rounded-full bg-white px-2.5 py-0.5 font-semibold text-ink shadow-[0_2px_8px_-3px_rgb(60_55_80/0.3)]" aria-current="page">${isHome ? icons.homeFilled('size-4 text-orange') : ''}${escapeHtml(label)}</span>`;

    if (isHome) {
      crumbsEl.innerHTML = here('Home');
      return;
    }
    const parts = [link('/', 'Home', ''), ...ancestors.map((f) => link(folderPath(f.id), f.name, f.id))];
    if (current) parts.push(here(current.name));
    crumbsEl.innerHTML = parts.join(sep);
    crumbsEl.scrollLeft = crumbsEl.scrollWidth; // keep the current level visible
  }

  if (isHome) {
    renderCrumbs([]);
  } else {
    /** @type {(() => void) | null} */
    let unsubAncestors = null;
    let ancestorKey = '';
    subs.push(() => unsubAncestors?.());
    subs.push(folderRepo.subscribeOne(folderId, (folder) => {
      current = folder;
      if (!folder) {
        renderNotFound();
        return;
      }
      renderSubtitle();
      // Re-subscribe to the ancestors only when the path changes (e.g. after a move).
      const key = folder.ancestorIds.join('/');
      if (key !== ancestorKey || !unsubAncestors) {
        ancestorKey = key;
        unsubAncestors?.();
        unsubAncestors = folderRepo.subscribeMany(folder.ancestorIds, (rows) => {
          const byId = new Map(rows.map((r) => [r.id, r]));
          renderCrumbs(folder.ancestorIds.map((id) => byId.get(id)).filter((f) => !!f));
        });
      }
    }));

  }

  // Top-row buttons. "More" = app menu on Home, this folder's actions inside a folder.
  outlet.querySelector('[data-actions]')?.addEventListener('click', async (e) => {
    const act = /** @type {HTMLElement} */ (e.target).closest('[data-act]')?.getAttribute('data-act');
    if (act === 'back') goUp(folderPath(current?.parentFolderId ?? null));
    if (act === 'install') await installApp();
    if (act === 'more') {
      if (isHome) await openProfileMenu();
      else if (current) {
        const parent = folderPath(current.parentFolderId);
        await folderActions.menu(current, () => navigate(parent, { replace: true }));
      }
    }
  });

  // Install button: only when this browser can install right now (or on iPhone, with instructions).
  const installBtn = /** @type {HTMLElement} */ (outlet.querySelector('[data-act=install]'));
  const syncInstall = () => { installBtn.hidden = !['prompt', 'ios'].includes(installMode()); };
  syncInstall();
  subs.push(onInstallChange(syncInstall));

  // Counts at the end of the breadcrumb row, e.g. "4 folders · 2 notes".
  const subtitleEl = /** @type {HTMLElement} */ (outlet.querySelector('[data-subtitle]'));
  function renderSubtitle() {
    if (!folders || !notes) return;
    const plural = (/** @type {number} */ n, /** @type {string} */ w) => `${n} ${w}${n === 1 ? '' : 's'}`;
    subtitleEl.textContent = `${plural(folders.length, 'folder')} · ${plural(notes.length, 'note')}`;
  }

  // Header shrinks while scrolling (greeting + big title fold away), with a little hysteresis.
  const headerEl = /** @type {HTMLElement} */ (outlet.querySelector('.app-header'));
  const onScroll = () => {
    const y = window.scrollY;
    // Only compact when the page is long enough; otherwise shrinking the header would shorten
    // the page, pull the scroll position back up and make the header flicker open/closed.
    const room = document.documentElement.scrollHeight - window.innerHeight;
    if (y > 40 && room > 160) headerEl.classList.add('is-compact');
    else if (y < 16) headerEl.classList.remove('is-compact');
    const compact = headerEl.classList.contains('is-compact');
    searchIcon.tabIndex = compact ? 0 : -1;
    searchPill.tabIndex = compact ? -1 : 0;
  };
  const searchIcon = /** @type {HTMLElement} */ (headerEl.querySelector('.header-search-icon'));
  const searchPill = /** @type {HTMLElement} */ (headerEl.querySelector('.header-search a'));
  window.addEventListener('scroll', onScroll, { passive: true });
  subs.push(() => window.removeEventListener('scroll', onScroll));

  function renderNotFound() {
    crumbsEl.innerHTML = `<a href="#/" class="px-2 py-0.5 text-slate/70">Home</a>`;
    outlet.querySelector('main').innerHTML = `
      <div class="pop-in flex flex-col items-center py-20 text-center">
        <p class="text-lg font-bold">This folder doesn’t exist</p>
        <p class="mt-1 text-slate">It may have been deleted.</p>
        <a href="#/" class="mt-6 rounded-full bg-slate px-6 py-3 font-semibold text-white">Go Home</a>
      </div>`;
  }

  // ---------- Body ----------

  // Cards are cached by id and only rebuilt when their data changes. Keeping the same DOM nodes
  // lets flip() animate reorders, additions and removals instead of the whole list blinking.
  /** @type {Map<string, { el: HTMLElement, sig: string }>} */
  const folderNodes = new Map();
  /** @type {Map<string, { el: HTMLElement, sig: string }>} */
  const noteNodes = new Map();
  const mainEl = /** @type {HTMLElement} */ (outlet.querySelector('[data-main]'));
  let firstPaint = true;

  /**
   * Returns the cached card for `id`, rebuilding it only when `sig` (its visible content) changed.
   * @param {Map<string, { el: HTMLElement, sig: string }>} cache
   * @param {string} id
   * @param {string} sig
   * @param {() => HTMLElement} build
   */
  function cached(cache, id, sig, build) {
    const hit = cache.get(id);
    if (hit && hit.sig === sig) return hit.el;
    const el = build();
    if (hit) hit.el.replaceWith(el); // keep its slot so flip() treats it as the same item
    cache.set(id, { el, sig });
    return el;
  }

  /** Runs a DOM update with glide/fade animations (none on the first paint). */
  function animate(/** @type {() => void} */ mutate) {
    flip(mainEl, mutate, { enter: !firstPaint });
  }

  function renderFolders() {
    if (!folders) return;
    const list = folders;
    animate(() => {
      const ids = new Set(list.map((f) => f.id));
      for (const id of folderNodes.keys()) if (!ids.has(id)) folderNodes.delete(id);
      foldersEl.replaceChildren(...list.map((folder) => cached(folderNodes, folder.id, `${folder.name}|${folder.colorHex}`, () => {
        const card = renderFolderCard(folder);
        onLongPress(card, () => folderActions.menu(folder));
        return card;
      })));
      foldersEl.hidden = list.length === 0;
      notesEl.classList.toggle('mt-8', list.length > 0);
    });
    renderEmpty();
    renderSubtitle();
  }

  function renderNotes() {
    if (!notes) return;
    if (dragging) {
      notesDirty = true;
      return;
    }
    const list = notes;
    animate(() => {
      const ids = new Set(list.map((n) => n.id));
      for (const id of noteNodes.keys()) if (!ids.has(id)) noteNodes.delete(id);
      notesEl.replaceChildren(...list.map((n) => {
        const stats = taskStats.get(n.id);
        const sig = `${n.title}|${n.body}|${n.colorHex}|${stats?.done ?? 0}/${stats?.total ?? 0}`;
        return cached(noteNodes, n.id, sig, () => {
          const card = renderNoteCard(n, stats);
          // Long-press the card body (not the drag handle) for Move / Color / Delete.
          onLongPress(/** @type {HTMLElement} */ (card.querySelector('a')), () => noteActions.menu(n));
          return card;
        });
      }));
      notesEl.hidden = list.length === 0;
      notesEl.classList.toggle('mt-8', !!folders?.length);
    });
    renderEmpty();
    renderSubtitle();
    if (folders) firstPaint = false;
  }

  function renderEmpty() {
    const empty = folders !== null && notes !== null && !folders.length && !notes.length;
    emptyEl.hidden = !empty;
    if (empty && !emptyEl.childElementCount) {
      emptyEl.innerHTML = `
        <div class="pop-in flex flex-col items-center px-6 py-16 text-center">
          <div class="tinted mb-6 w-36 text-slate/60" style="--c: #FFD9B8">
            ${folderShape('empty-g', 'w-full', `
              <circle cx="46" cy="50" r="3" fill="currentColor"/><circle cx="74" cy="50" r="3" fill="currentColor"/>
              <path d="M50 62q10 7 20 0" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>`)}
          </div>
          <p class="text-lg font-semibold">${isHome ? 'Welcome to MEMO pad' : 'This folder is empty'}</p>
          <p class="mt-1 max-w-64 text-slate">Tap the button in the corner to add a note or a folder.</p>
        </div>`;
    }
  }

  subs.push(folderRepo.subscribeChildren(folderId, (rows) => {
    folders = rows;
    renderFolders();
    renderNotes(); // spacing depends on whether folders exist
  }));

  /** @type {(() => void) | null} */
  let unsubTasks = null;
  let noteIdsKey = '';
  subs.push(() => unsubTasks?.());
  subs.push(noteRepo.subscribeInFolder(folderId, (rows) => {
    notes = rows;
    const key = rows.map((n) => n.id).sort().join(',');
    if (key !== noteIdsKey) {
      noteIdsKey = key;
      unsubTasks?.();
      unsubTasks = taskRepo.subscribeForNotes(rows.map((n) => n.id), (tasks) => {
        /** @type {Map<string, { done: number, total: number }>} */
        const stats = new Map();
        for (const t of tasks) {
          const s = stats.get(t.noteId) ?? { done: 0, total: 0 };
          s.total++;
          if (t.isDone) s.done++;
          stats.set(t.noteId, s);
        }
        taskStats = stats;
        renderNotes();
      });
    }
    renderNotes();
  }));

  const sortable = makeSortable(notesEl, {
    handle: '.drag-handle',
    onDragState: (on) => {
      dragging = on;
      if (!on && notesDirty) {
        notesDirty = false;
        // Let Sortable finish its drop animation before syncing with the latest data.
        setTimeout(renderNotes, 0);
      }
    },
    onReorder: (ids) => noteRepo.reorder(ids),
    // Drop a note onto a subfolder or a breadcrumb to move it there.
    dropTarget: {
      selector: '[data-folders] > a[data-id], [data-crumbs] a[data-drop-folder]',
      onDrop: (target, noteId) => {
        const targetId = target.dataset.dropFolder !== undefined ? (target.dataset.dropFolder || null) : (target.dataset.id ?? null);
        noteActions.moveTo(noteId, targetId, folderId);
      },
    },
  });

  const destroyFab = mountFabMenu({
    actions: defaultFabActions({
      onHome: () => navigate('/'),
      onNewNote: async () => {
        const note = await noteRepo.create({ folderId });
        navigate(`/note/${note.id}`);
      },
      onNewFolder: () => folderActions.create(folderId),
    }),
  });

  return () => {
    subs.forEach((unsub) => unsub());
    sortable.destroy();
    destroyFab();
  };
}
