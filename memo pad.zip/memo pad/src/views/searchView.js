/**
 * Search (#/search): folder names, note titles, note bodies and task titles at every level.
 * Results are grouped (Folders, Notes, Tasks), show where each item lives, and highlight matches.
 * The query is kept in sessionStorage so coming back from a result shows the same results.
 */
import * as searchRepo from '../lib/data/repos/searchRepo.js';
import * as folderRepo from '../lib/data/repos/folderRepo.js';
import * as noteRepo from '../lib/data/repos/noteRepo.js';
import { debounce, escapeHtml, highlight, snippet } from '../lib/utils.js';
import { back } from '../router.js';
import { folderShape } from '../components/folderCard.js';
import * as icons from '../components/icons.js';

/** @typedef {import('../lib/data/adapters/types.js').Folder} Folder */
/** @typedef {import('../lib/data/adapters/types.js').Note} Note */
/** @typedef {import('../lib/data/adapters/types.js').Task} Task */

const QUERY_KEY = 'memo-search-query';

/**
 * "Home › Work › Ideas" for a folder id (null = Home).
 * @param {string | null} folderId
 * @param {Map<string, Promise<string>>} cache
 * @returns {Promise<string>}
 */
function locationLabel(folderId, cache) {
  const key = folderId ?? '';
  if (!cache.has(key)) {
    cache.set(key, folderRepo.getPath(folderId).then((path) => ['Home', ...path.map((f) => f.name)].join(' › ')));
  }
  return /** @type {Promise<string>} */ (cache.get(key));
}

/**
 * @param {string} title
 * @param {number} count
 */
const groupHeading = (title, count) => `
  <h2 class="mb-3 mt-8 px-1 text-sm font-bold uppercase tracking-[0.18em] text-slate first:mt-2">
    ${title} <span class="ml-1 rounded-full bg-pill px-2 py-0.5 text-xs">${count}</span>
  </h2>`;

/**
 * @param {HTMLElement} outlet
 * @returns {() => void} cleanup
 */
export function searchView(outlet) {
  outlet.innerHTML = `
    <header class="header-bg sticky top-0 z-20 flex items-center gap-3 px-4 pb-4 pt-[max(1rem,env(safe-area-inset-top))]">
      <button data-act="back" class="flex size-10 shrink-0 items-center justify-center rounded-full bg-slate text-white transition active:scale-90" aria-label="Back">
        ${icons.arrowLeft('size-6')}
      </button>
      <label class="flex min-w-0 flex-1 items-center gap-2 rounded-full bg-white px-4 shadow-soft focus-within:ring-2 focus-within:ring-blue/40">
        <span class="text-slate">${icons.search('size-5')}</span>
        <input data-query type="search" placeholder="Search folders, notes, tasks" autocomplete="off" enterkeyhint="search"
          class="min-w-0 flex-1 bg-transparent py-3 text-[17px] text-ink outline-none placeholder:text-slate/70" aria-label="Search">
        <button type="button" data-act="clear" hidden class="-mr-1 flex size-8 items-center justify-center rounded-full text-slate" aria-label="Clear search">
          ${icons.close('size-4')}
        </button>
      </label>
    </header>
    <main class="px-5 pb-24 pt-4" data-results aria-live="polite"></main>`;

  const input = /** @type {HTMLInputElement} */ (outlet.querySelector('[data-query]'));
  const clearBtn = /** @type {HTMLElement} */ (outlet.querySelector('[data-act=clear]'));
  const results = /** @type {HTMLElement} */ (outlet.querySelector('[data-results]'));
  let token = 0;

  function renderHint() {
    results.innerHTML = `
      <div class="pop-in flex flex-col items-center px-6 py-20 text-center text-slate">
        <span class="mb-4 text-slate/50">${icons.search('size-14')}</span>
        <p>Search folder names, note titles, note text and tasks — in every folder.</p>
      </div>`;
  }

  /** @param {string} q */
  async function run(q) {
    const my = ++token;
    sessionStorage.setItem(QUERY_KEY, q);
    clearBtn.hidden = !q;
    if (!q.trim()) {
      renderHint();
      return;
    }
    const found = await searchRepo.search(q);
    /** @type {Map<string, Promise<string>>} */
    const paths = new Map();
    /** @type {Map<string, Promise<Note | null>>} */
    const notesById = new Map();
    const noteFor = (/** @type {string} */ id) => {
      if (!notesById.has(id)) notesById.set(id, noteRepo.get(id));
      return /** @type {Promise<Note | null>} */ (notesById.get(id));
    };

    const [folderRows, noteRows, taskRows] = await Promise.all([
      Promise.all(found.folders.map(async (f) => ({ f, where: await locationLabel(f.parentFolderId, paths) }))),
      Promise.all(found.notes.map(async (n) => ({ n, where: await locationLabel(n.folderId, paths) }))),
      Promise.all(found.tasks.map(async (t) => ({ t, note: await noteFor(t.noteId) }))),
    ]);
    if (my !== token) return; // a newer search started meanwhile
    const tasks = taskRows.filter((r) => r.note);
    const total = folderRows.length + noteRows.length + tasks.length;

    if (!total) {
      results.innerHTML = `
        <div class="pop-in flex flex-col items-center px-6 py-20 text-center">
          <p class="text-lg font-semibold">No results for “${escapeHtml(q.trim())}”</p>
          <p class="mt-1 text-slate">Try a different word.</p>
        </div>`;
      return;
    }

    let html = '';
    if (folderRows.length) {
      html += groupHeading('Folders', folderRows.length) + `<div class="flex flex-col gap-2">` +
        folderRows.map(({ f, where }) => `
          <a href="#/folder/${encodeURIComponent(f.id)}" class="tinted flex items-center gap-4 rounded-2xl px-3 py-2.5 transition hover:bg-white active:scale-[.98]" style="--c: ${escapeHtml(f.colorHex)}">
            ${folderShape(`sf-${f.id}`, 'w-14 shrink-0')}
            <span class="min-w-0">
              <span class="block truncate text-[17px] text-ink">${highlight(f.name, q)}</span>
              <span class="block truncate text-sm text-slate">${escapeHtml(where)}</span>
            </span>
          </a>`).join('') + `</div>`;
    }
    if (noteRows.length) {
      html += groupHeading('Notes', noteRows.length) + `<div class="flex flex-col gap-3">` +
        noteRows.map(({ n, where }) => `
          <a href="#/note/${encodeURIComponent(n.id)}" class="tinted note-card-bg block rounded-[22px] px-5 py-4 transition active:scale-[.98]" style="--c: ${escapeHtml(n.colorHex)}">
            <span class="block truncate text-xl ${n.title.trim() ? 'text-ink' : 'text-ink/35'}">${n.title.trim() ? highlight(n.title, q) : 'Untitled'}</span>
            ${n.body.trim() ? `<span class="mt-1 block text-[15px] leading-snug text-ink/75">${highlight(snippet(n.body, q), q)}</span>` : ''}
            <span class="mt-2 flex items-center gap-1 text-xs font-semibold text-ink/55">${icons.folder('size-3.5')} ${escapeHtml(where)}</span>
          </a>`).join('') + `</div>`;
    }
    if (tasks.length) {
      html += groupHeading('Tasks', tasks.length) + `<div class="flex flex-col gap-3">` +
        tasks.map(({ t, note }) => {
          const n = /** @type {Note} */ (note);
          return `
          <a href="#/note/${encodeURIComponent(n.id)}" class="tinted flex items-center gap-3 rounded-[22px] bg-[var(--c-task)] px-4 py-3 shadow-soft transition active:scale-[.98]" style="--c: ${escapeHtml(n.colorHex)}">
            <span class="${t.isDone ? 'text-green' : 'text-ink/25'}">${icons.check('size-6')}</span>
            <span class="min-w-0">
              <span class="block truncate text-[17px] font-bold tracking-[0.08em] ${t.isDone ? 'text-ink/50 line-through' : 'text-ink/85'}">${highlight(t.title, q)}</span>
              <span class="block truncate text-sm text-ink/60">in ${escapeHtml(n.title.trim() || 'Untitled')}</span>
            </span>
          </a>`;
        }).join('') + `</div>`;
    }
    results.innerHTML = html;
  }

  const runSoon = debounce(run, 180);
  input.addEventListener('input', () => runSoon(input.value));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); runSoon.cancel(); run(input.value); input.blur(); }
  });

  outlet.querySelector('header')?.addEventListener('click', (e) => {
    const act = /** @type {HTMLElement} */ (e.target).closest('[data-act]')?.getAttribute('data-act');
    if (act === 'back') back('/');
    if (act === 'clear') {
      input.value = '';
      run('');
      input.focus();
    }
  });

  // Restore the previous query (e.g. returning from a result), otherwise start typing right away.
  const previous = sessionStorage.getItem(QUERY_KEY) ?? '';
  input.value = previous;
  run(previous);
  if (!previous) input.focus();

  return () => runSoon.cancel();
}
