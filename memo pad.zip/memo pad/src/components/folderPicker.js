/**
 * "Move to…" dialog: Home plus every folder as an indented tree. The item's current location is
 * marked and can't be chosen; other invalid targets (e.g. a folder's own subfolders) are greyed out.
 */
import { escapeHtml, htmlToElement } from '../lib/utils.js';
import { openDialog } from './dialog.js';
import { folderShape } from './folderCard.js';
import * as icons from './icons.js';

/** @typedef {import('../lib/data/adapters/types.js').Folder} Folder */

/**
 * @param {Object} options
 * @param {string} options.title                     e.g. 'Move “Ideas” to…'
 * @param {Array<{ folder: Folder, depth: number }>} options.tree  from folderRepo.listTree()
 * @param {string | null} options.currentId          where the item is now (null = Home)
 * @param {Set<string>} [options.disabledIds]        folders that can't be chosen
 * @returns {Promise<{ id: string | null } | null>} the chosen folder ({ id: null } = Home), or null if cancelled
 */
export async function pickFolder({ title, tree, currentId, disabledIds = new Set() }) {
  /** @type {string | null | undefined} undefined = nothing selected yet */
  let selected;

  /**
   * @param {string | null} id
   * @param {string} name
   * @param {number} depth
   * @param {string} iconHtml
   * @param {boolean} disabled
   */
  const row = (id, name, depth, iconHtml, disabled) => {
    const isCurrent = id === currentId;
    return `
      <button type="button" data-target="${id ?? ''}" ${disabled || isCurrent ? 'disabled' : ''}
        class="picker-row flex w-full items-center gap-3 rounded-2xl py-2 pr-3 text-left transition
               enabled:hover:bg-white/70 enabled:active:scale-[.98] disabled:opacity-45"
        style="padding-left: ${0.75 + depth * 1.25}rem">
        ${iconHtml}
        <span class="min-w-0 flex-1 truncate text-[17px] text-ink">${escapeHtml(name)}</span>
        ${isCurrent ? '<span class="shrink-0 rounded-full bg-pill px-2 py-0.5 text-xs font-semibold text-slate">Current</span>' : ''}
        <span class="picker-tick hidden shrink-0 text-blue">${icons.check('size-5')}</span>
      </button>`;
  };

  const content = htmlToElement(`
    <div class="flex flex-col">
      <h2 class="mb-4 text-center text-xl font-bold text-ink">${escapeHtml(title)}</h2>
      <div class="no-scrollbar -mx-2 flex max-h-[min(24rem,calc(100dvh-14rem))] flex-col gap-0.5 overflow-y-auto px-1" role="listbox" aria-label="Folders">
        ${row(null, 'Home', 0, `<span class="flex size-9 shrink-0 items-center justify-center rounded-xl bg-orange text-white">${icons.homeFilled('size-5')}</span>`, false)}
        ${tree.map(({ folder, depth }) => row(
          folder.id, folder.name, depth + 1,
          `<span class="tinted w-9 shrink-0" style="--c: ${escapeHtml(folder.colorHex)}">${folderShape(`pk-${folder.id}`, 'w-full')}</span>`,
          disabledIds.has(folder.id),
        )).join('')}
      </div>
      <div class="mt-5 flex items-center justify-end gap-4">
        <button value="cancel" class="px-2 py-2.5 text-lg font-medium text-red transition active:scale-95">Cancel</button>
        <button value="ok" data-confirm disabled
          class="rounded-full bg-slate px-7 py-2.5 text-lg font-semibold text-white shadow-soft transition active:scale-95 disabled:opacity-40">Move here</button>
      </div>
    </div>`);

  const confirm = /** @type {HTMLButtonElement} */ (content.querySelector('[data-confirm]'));
  content.addEventListener('click', (e) => {
    const rowEl = /** @type {HTMLElement | null} */ (/** @type {HTMLElement} */ (e.target).closest('[data-target]'));
    if (!rowEl || rowEl.hasAttribute('disabled')) return;
    selected = rowEl.dataset.target || null;
    content.querySelectorAll('.picker-row').forEach((r) => {
      const on = r === rowEl;
      r.classList.toggle('bg-white', on);
      r.classList.toggle('shadow-soft', on);
      r.setAttribute('aria-selected', String(on));
      r.querySelector('.picker-tick')?.classList.toggle('hidden', !on);
    });
    confirm.disabled = false;
  });

  const result = await openDialog({ content, panelClass: 'px-5 pt-7 pb-5' });
  return result === 'ok' && selected !== undefined ? { id: selected } : null;
}
