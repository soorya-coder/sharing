/**
 * Dialog helpers built on the native <dialog> element. Each returns a Promise that resolves
 * when the dialog closes (Esc and backdrop taps count as cancel → null/false).
 */
import { escapeHtml } from '../lib/utils.js';

/**
 * @typedef {Object} DialogAction
 * @property {string} label
 * @property {string} value          returned when this button is pressed
 * @property {'primary' | 'danger' | 'plain'} [variant]
 */

const BUTTON = {
  primary: 'bg-slate text-white',
  danger: 'bg-red text-white',
  plain: 'text-slate',
};

/**
 * Opens a modal dialog with arbitrary content. The dialog element is removed after closing.
 * @param {Object} options
 * @param {string} [options.title]
 * @param {HTMLElement | string} [options.content] element or trusted HTML string
 * @param {DialogAction[]} [options.actions]
 * @param {(dialog: HTMLDialogElement) => void} [options.onOpen] e.g. focus an input
 * @param {string} [options.panelClass] extra classes for the panel
 * @returns {Promise<string | null>} the pressed action's value, or null if dismissed
 */
export function openDialog({ title, content, actions = [], onOpen, panelClass = '' }) {
  const dialog = document.createElement('dialog');
  dialog.className = 'memo-dialog';
  dialog.innerHTML = `
    <form method="dialog" class="dialog-panel rounded-dialog bg-dialog p-7 shadow-lift ${panelClass}">
      ${title ? `<h2 class="mb-4 text-center text-lg font-bold">${escapeHtml(title)}</h2>` : ''}
      <div class="dialog-content"></div>
      ${actions.length ? `<div class="mt-6 flex justify-end gap-2">
        ${actions.map((a) => `<button value="${escapeHtml(a.value)}"
            class="rounded-full px-5 py-2.5 text-sm font-semibold active:scale-95 transition ${BUTTON[a.variant ?? 'plain']}">
            ${escapeHtml(a.label)}</button>`).join('')}
      </div>` : ''}
    </form>`;
  const slot = /** @type {HTMLElement} */ (dialog.querySelector('.dialog-content'));
  if (typeof content === 'string') slot.innerHTML = content;
  else if (content) slot.append(content);

  // Tapping the backdrop (outside the panel) closes the dialog.
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) dialog.close('');
  });

  document.body.append(dialog);
  dialog.showModal();
  onOpen?.(dialog);

  return new Promise((resolve) => {
    dialog.addEventListener('close', () => {
      const value = dialog.returnValue;
      dialog.remove();
      resolve(value ? value : null);
    }, { once: true });
  });
}

/**
 * Yes/no confirmation.
 * @param {{ title: string, message?: string, confirmLabel?: string, danger?: boolean }} options
 * @returns {Promise<boolean>}
 */
export async function confirmDialog({ title, message = '', confirmLabel = 'OK', danger = false }) {
  const result = await openDialog({
    title,
    content: message ? `<p class="text-center text-slate">${escapeHtml(message)}</p>` : undefined,
    actions: [
      { label: 'Cancel', value: 'cancel', variant: 'plain' },
      { label: confirmLabel, value: 'ok', variant: danger ? 'danger' : 'primary' },
    ],
  });
  return result === 'ok';
}

/**
 * Asks for a line of text.
 * @param {{ title: string, value?: string, placeholder?: string, confirmLabel?: string }} options
 * @returns {Promise<string | null>} trimmed text, or null if cancelled
 */
export async function promptDialog({ title, value = '', placeholder = '', confirmLabel = 'Save' }) {
  const input = document.createElement('input');
  input.type = 'text';
  input.value = value;
  input.placeholder = placeholder;
  input.maxLength = 120;
  input.className = 'w-full rounded-full bg-white px-5 py-3 text-base shadow-soft outline-none focus:ring-2 focus:ring-blue/40';
  const result = await openDialog({
    title,
    content: input,
    actions: [
      { label: 'Cancel', value: 'cancel', variant: 'plain' },
      { label: confirmLabel, value: 'ok', variant: 'primary' },
    ],
    onOpen: () => { input.focus(); input.select(); },
  });
  return result === 'ok' ? input.value.trim() : null;
}

/**
 * @typedef {Object} SheetItem
 * @property {string} label
 * @property {string} value
 * @property {string} [icon] SVG string
 * @property {boolean} [danger]
 */

/**
 * A list of choices (used for the folder long-press menu).
 * @param {{ title?: string, items: SheetItem[] }} options
 * @returns {Promise<string | null>}
 */
export function actionSheet({ title, items }) {
  const list = items.map((item) => `
    <button value="${escapeHtml(item.value)}"
      class="flex w-full items-center gap-4 rounded-2xl px-4 py-3.5 text-left font-semibold transition active:scale-[.98] hover:bg-white/60 ${item.danger ? 'text-red' : 'text-ink'}">
      <span class="${item.danger ? 'text-red' : 'text-slate'}">${item.icon ?? ''}</span>
      ${escapeHtml(item.label)}
    </button>`).join('');
  return openDialog({ title, content: `<div class="flex flex-col gap-1">${list}</div>`, panelClass: 'p-4' });
}
