/**
 * Bottom toast with an optional action (used for "Undo"). Only one toast is shown at a time.
 */
import { escapeHtml } from '../lib/utils.js';

/** @type {{ el: HTMLElement, timer: ReturnType<typeof setTimeout> } | null} */
let current = null;

function dismiss() {
  if (!current) return;
  clearTimeout(current.timer);
  current.el.remove();
  current = null;
}

/**
 * Shows a toast.
 * @param {string} message
 * @param {{ actionLabel?: string, onAction?: () => void | Promise<void>, duration?: number }} [options]
 */
export function showToast(message, { actionLabel, onAction, duration = 5000 } = {}) {
  dismiss();
  const el = document.createElement('div');
  el.setAttribute('role', 'status');
  el.className = 'toast-in fixed inset-x-0 bottom-28 z-50 mx-auto flex w-[min(92vw,26rem)] items-center gap-3 rounded-full bg-ink px-5 py-3 text-sm text-white shadow-lift';
  el.innerHTML = `
    <span class="flex-1">${escapeHtml(message)}</span>
    ${actionLabel ? `<button class="rounded-full px-3 py-1 font-bold text-orange active:scale-95">${escapeHtml(actionLabel)}</button>` : ''}`;
  el.querySelector('button')?.addEventListener('click', async () => {
    dismiss();
    await onAction?.();
  });
  document.body.append(el);
  current = { el, timer: setTimeout(dismiss, duration) };
}

/**
 * Shows "<message>" with an Undo button that runs handle.undo().
 * @param {string} message
 * @param {{ undo: () => Promise<void> }} handle
 */
export function showUndoToast(message, handle) {
  showToast(message, {
    actionLabel: 'Undo',
    duration: 6000,
    onAction: async () => {
      await handle.undo();
      showToast('Restored', { duration: 1800 });
    },
  });
}
