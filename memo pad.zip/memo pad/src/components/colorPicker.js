/**
 * "Pick a Color" dialog, reused for folders and notes.
 * Large preview circle with a soft glow of the selected color, a scrollable 5-column grid of
 * pastels (selected one gets a ring), red "Cancel" and a "Done" pill in a muted version of the color.
 */
import { escapeHtml, htmlToElement } from '../lib/utils.js';
import { PALETTE } from '../lib/palette.js';
import { openDialog } from './dialog.js';

/**
 * Opens the picker.
 * @param {{ initial: string, title?: string }} options
 * @returns {Promise<string | null>} the chosen hex color, or null if cancelled
 */
export async function pickColor({ initial, title = 'Pick a Color' }) {
  let color = initial;
  // If the current color isn't in the palette (e.g. imported data), offer it first.
  const colors = PALETTE.some((c) => c.toLowerCase() === initial.toLowerCase()) ? PALETTE : [initial, ...PALETTE];

  const content = htmlToElement(`
    <div class="tinted flex flex-col" data-picker style="--c: ${escapeHtml(color)}">
      <h2 class="text-center text-[28px] font-bold text-ink">${escapeHtml(title)}</h2>
      <div class="flex justify-center py-[min(2rem,4dvh)]">
        <div class="color-preview size-[min(8rem,16dvh)] rounded-full bg-[var(--c)]" aria-hidden="true"></div>
      </div>
      <div class="no-scrollbar -mx-2 grid max-h-[min(17.5rem,calc(100dvh-22rem))] min-h-24 grid-cols-5 gap-4 overflow-y-auto px-3 py-2
                  [mask-image:linear-gradient(to_bottom,black_88%,transparent)]"
           role="radiogroup" aria-label="Colors">
        ${colors.map((hex) => `
          <button type="button" role="radio" data-color="${escapeHtml(hex)}" aria-label="Color ${escapeHtml(hex)}"
            class="swatch aspect-square rounded-full transition active:scale-90" style="background:${escapeHtml(hex)}"></button>`).join('')}
      </div>
      <div class="mt-5 flex items-center justify-end gap-6">
        <button value="cancel" class="px-2 py-3 text-[22px] font-medium text-red transition active:scale-95">Cancel</button>
        <button value="ok" class="rounded-full bg-[var(--c-muted)] px-10 py-3 text-[22px] font-semibold text-white shadow-soft transition active:scale-95">Done</button>
      </div>
    </div>`);

  const picker = /** @type {HTMLElement} */ (content);
  const swatches = /** @type {NodeListOf<HTMLElement>} */ (content.querySelectorAll('[data-color]'));

  const paint = () => {
    picker.style.setProperty('--c', color);
    swatches.forEach((s) => {
      const on = s.dataset.color?.toLowerCase() === color.toLowerCase();
      s.setAttribute('aria-checked', String(on));
      s.classList.toggle('is-selected', on);
    });
  };
  content.addEventListener('click', (e) => {
    const hex = /** @type {HTMLElement} */ (e.target).closest('[data-color]')?.getAttribute('data-color');
    if (hex) {
      color = hex;
      paint();
    }
  });
  paint();

  const result = await openDialog({
    content,
    panelClass: 'px-6 pt-8 pb-5',
    onOpen: () => {
      const selected = /** @type {HTMLElement | null} */ (content.querySelector('.is-selected'));
      selected?.scrollIntoView({ block: 'nearest' });
      selected?.focus({ preventScroll: true });
    },
  });
  return result === 'ok' ? color : null;
}
