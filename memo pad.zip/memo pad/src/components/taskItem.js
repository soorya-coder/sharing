/**
 * One task row in the note editor: a rounded card in the note's color.
 * Left: check toggle (green when done). Middle: bold title + "created at : yyyy-MM-dd".
 * Right: white rounded-square delete button with a red trash icon.
 *
 * Interactive parts carry data-act="toggle" | "edit" | "delete"; the note view handles them.
 */
import { escapeHtml, formatDate, htmlToElement } from '../lib/utils.js';
import * as icons from './icons.js';

/** @typedef {import('../lib/data/adapters/types.js').Task} Task */

/**
 * @param {Task} task
 * @returns {HTMLElement} element with data-id
 */
export function renderTaskItem(task) {
  return htmlToElement(`
    <li data-id="${escapeHtml(task.id)}"
        class="task-card flex items-center gap-3 rounded-card bg-[var(--c-task)] py-4 pl-3 pr-3 shadow-soft ${task.isDone ? 'is-done' : ''}">
      <button type="button" data-act="toggle" role="checkbox" aria-checked="${task.isDone}"
        aria-label="${task.isDone ? 'Mark as not done' : 'Mark as done'}"
        class="task-check flex size-12 shrink-0 items-center justify-center rounded-full transition active:scale-90">
        ${icons.check('size-8')}
      </button>
      <div class="task-drag min-w-0 flex-1 py-1">
        <button type="button" data-act="edit"
          class="task-title inline-block max-w-full truncate align-top text-left text-[22px] font-bold tracking-[0.12em] text-ink/85">${escapeHtml(task.title)}</button>
        <p class="mt-0.5 flex flex-wrap items-center gap-x-2 text-[15px] font-medium tracking-wide text-ink/60">
          <span>created at : ${formatDate(task.createdAt)}</span>
          <span class="task-done-chip completed-chip items-center gap-1 rounded-full px-2 py-0.5 text-xs font-bold tracking-wide">${icons.check('size-3')} Completed</span>
        </p>
      </div>
      <button type="button" data-act="delete" aria-label="Delete task"
        class="flex size-12 shrink-0 items-center justify-center rounded-[12px] bg-white text-red shadow-[0_2px_6px_-2px_rgb(0_0_0/0.25)] transition active:scale-90">
        ${icons.trashFilled('size-7')}
      </button>
    </li>`);
}

/**
 * Swaps the title button for an input and resolves with the new text (or null if cancelled /
 * unchanged / empty). Enter or blur saves, Escape cancels.
 * @param {HTMLElement} item a rendered task item
 * @returns {Promise<string | null>}
 */
export function editTaskTitle(item) {
  const titleBtn = /** @type {HTMLElement} */ (item.querySelector('.task-title'));
  const original = titleBtn.textContent ?? '';
  const input = document.createElement('input');
  input.type = 'text';
  input.value = original;
  input.maxLength = 300;
  input.setAttribute('aria-label', 'Task title');
  input.className = 'w-full rounded-lg bg-white/60 px-2 py-0.5 text-[22px] font-bold tracking-[0.12em] text-ink outline-none ring-2 ring-white';
  titleBtn.replaceWith(input);
  input.focus();
  input.select();

  return new Promise((resolve) => {
    let done = false;
    /** @param {string | null} value */
    const finish = (value) => {
      if (done) return;
      done = true;
      input.replaceWith(titleBtn);
      const clean = value?.trim() ?? '';
      if (value !== null && clean && clean !== original) titleBtn.textContent = clean;
      resolve(value !== null && clean && clean !== original ? clean : null);
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(input.value); }
      if (e.key === 'Escape') { e.preventDefault(); finish(null); }
    });
    input.addEventListener('blur', () => finish(input.value));
  });
}
