/**
 * Folder tile: an inline-SVG folder shape (tab on the top-left) filled with a soft diagonal
 * gradient of the folder's pastel color, name centered below in grey.
 */
import { escapeHtml, htmlToElement } from '../lib/utils.js';

/** @typedef {import('../lib/data/adapters/types.js').Folder} Folder */

/**
 * The folder shape on its own (also used by the empty state and, later, the folder picker).
 * Needs a `.tinted` ancestor with style="--c: <hex>".
 * @param {string} gradientId must be unique in the document
 * @param {string} [cls] classes for the <svg>
 * @param {string} [extra] extra SVG markup drawn on top
 * @returns {string} SVG markup
 */
export function folderShape(gradientId, cls = 'w-full', extra = '') {
  return `
    <svg class="folder-svg ${cls}" viewBox="0 0 120 90" aria-hidden="true">
      <defs>
        <linearGradient id="${gradientId}" x1="0" y1="0" x2="1" y2="1">
          <stop class="stop-a" offset="0"/>
          <stop class="stop-b" offset=".55"/>
          <stop class="stop-c" offset="1"/>
        </linearGradient>
      </defs>
      <path fill="url(#${gradientId})"
        d="M0 14A12 12 0 0 1 12 2h27a10 10 0 0 1 7.4 3.3L52.5 12H108a12 12 0 0 1 12 12v54a12 12 0 0 1-12 12H12A12 12 0 0 1 0 78z"/>
      ${extra}
    </svg>`;
}

/**
 * @param {Folder} folder
 * @returns {HTMLElement} an <a> linking to the folder, with data-id
 */
export function renderFolderCard(folder) {
  return htmlToElement(`
    <a href="#/folder/${encodeURIComponent(folder.id)}" data-id="${escapeHtml(folder.id)}"
       class="tinted flex select-none flex-col items-center gap-4 rounded-tile px-3 py-2 transition active:scale-95 [-webkit-touch-callout:none]"
       style="--c: ${escapeHtml(folder.colorHex)}">
      ${folderShape(`fg-${folder.id}`, 'w-full max-w-40')}
      <span class="line-clamp-2 max-w-full break-words text-center text-[17px] text-slate">${escapeHtml(folder.name)}</span>
    </a>`);
}
