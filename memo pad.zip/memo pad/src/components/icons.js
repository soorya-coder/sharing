/**
 * Inline SVG icons. Each function returns an SVG string sized by the `cls` classes
 * and colored with currentColor (outline icons) unless noted.
 */

/**
 * @param {string} body SVG inner markup
 * @param {string} cls classes for the <svg>
 * @param {{ fill?: boolean, stroke?: number }} [opts]
 */
const svg = (body, cls, { fill = false, stroke = 2 } = {}) =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true" ${fill
    ? 'fill="currentColor"'
    : `fill="none" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round"`}>${body}</svg>`;

/** @param {string} [cls] */
export const pencil = (cls = 'size-5') =>
  svg('<path d="M16.9 3.6a2.1 2.1 0 0 1 3 3L8.5 18 4 19.5 5.5 15z"/><path d="m14.5 6 3.5 3.5"/>', cls);

/** @param {string} [cls] */
export const trash = (cls = 'size-5') =>
  svg('<path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12"/><path d="M9 7V4.5A1.5 1.5 0 0 1 10.5 3h3A1.5 1.5 0 0 1 15 4.5V7"/>', cls);

/** Filled trash can (task delete button). @param {string} [cls] */
export const trashFilled = (cls = 'size-6') =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">
    <path fill="currentColor" d="M9.5 3h5a1.5 1.5 0 0 1 1.5 1.5V5h3.5a1 1 0 1 1 0 2h-15a1 1 0 0 1 0-2H8v-.5A1.5 1.5 0 0 1 9.5 3z"/>
    <path fill="currentColor" d="M5.8 8.5h12.4l-.9 10.7A2 2 0 0 1 15.3 21H8.7a2 2 0 0 1-2-1.8z"/>
  </svg>`;

/** @param {string} [cls] */
export const arrowLeft =(cls = 'size-5') =>
  svg('<path d="M19 12H5"/><path d="m11 6-6 6 6 6"/>', cls, { stroke: 2.4 });

/** Small filled, rounded left-pointing triangle (note editor back). @param {string} [cls] */
export const backTriangle = (cls = 'size-6') =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round" d="M16 5.5v13L6.5 12z"/></svg>`;

/** @param {string} [cls] */
export const search =(cls = 'size-5') =>
  svg('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>', cls, { stroke: 2.2 });

/** 2x2 grid of rounded squares (FAB closed). @param {string} [cls] */
export const grid = (cls = 'size-6') =>
  svg('<rect x="4" y="4" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="2"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="2"/>', cls, { fill: true });

/** @param {string} [cls] */
export const close = (cls = 'size-6') =>
  svg('<path d="M6 6l12 12M18 6 6 18"/>', cls, { stroke: 2.6 });

/** @param {string} [cls] */
export const home = (cls = 'size-5') =>
  svg('<path d="M4 11.5 12 5l8 6.5"/><path d="M6 10v8.5a1.5 1.5 0 0 0 1.5 1.5H10v-5h4v5h2.5a1.5 1.5 0 0 0 1.5-1.5V10"/>', cls, { stroke: 2.2 });

/** @param {string} [cls] */
export const filePlus = (cls = 'size-5') =>
  svg('<path d="M14 3H7.5A2.5 2.5 0 0 0 5 5.5v13A2.5 2.5 0 0 0 7.5 21h9a2.5 2.5 0 0 0 2.5-2.5V8z"/><path d="M14 3v5h5"/><path d="M12 11.5v6M9 14.5h6"/>', cls, { stroke: 2.1 });

/** @param {string} [cls] */
export const folder = (cls = 'size-5') =>
  svg('<path d="M3.5 7.5A2.5 2.5 0 0 1 6 5h3.6a2 2 0 0 1 1.6.8L12.5 7.5H18a2.5 2.5 0 0 1 2.5 2.5v7.5A2.5 2.5 0 0 1 18 20H6a2.5 2.5 0 0 1-2.5-2.5z"/>', cls, { stroke: 2.1 });

/** @param {string} [cls] */
export const check = (cls = 'size-5') =>
  svg('<path d="m5 12.5 4.5 4.5L19 7.5"/>', cls, { stroke: 2.6 });

/** @param {string} [cls] */
export const plus = (cls = 'size-5') =>
  svg('<path d="M12 5v14M5 12h14"/>', cls, { stroke: 2.6 });

/** Two horizontal lines (drag handle). @param {string} [cls] */
export const dragHandle = (cls = 'size-5') =>
  svg('<path d="M5 9.5h14M5 14.5h14"/>', cls, { stroke: 2.4 });

/** @param {string} [cls] */
export const user = (cls = 'size-6') =>
  svg('<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c1.2-3.6 4.1-5.5 7.5-5.5s6.3 1.9 7.5 5.5"/>', cls, { stroke: 2 });

/** @param {string} [cls] */
export const palette = (cls = 'size-5') =>
  svg('<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.2 0 1.8-.9 1.8-1.8 0-1.2-.9-1.5-.9-2.5 0-.9.7-1.6 1.6-1.6h2.1a3.9 3.9 0 0 0 3.9-3.9c0-4-3.8-7.2-8.5-7.2z"/><circle cx="7.8" cy="11" r="1.1" fill="currentColor"/><circle cx="10.5" cy="7.4" r="1.1" fill="currentColor"/><circle cx="15" cy="7.6" r="1.1" fill="currentColor"/>', cls);

/** Filled folder with a plus badge (FAB "new folder"). @param {string} [cls] */
export const folderPlus = (cls = 'size-6') =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">
    <path fill="currentColor" d="M2.5 7A2.5 2.5 0 0 1 5 4.5h3.7a2 2 0 0 1 1.5.7l1.4 1.8H19A2.5 2.5 0 0 1 21.5 9.5v8A2.5 2.5 0 0 1 19 20H5a2.5 2.5 0 0 1-2.5-2.5z"/>
    <circle cx="18" cy="8.5" r="4.2" fill="currentColor" stroke="white" stroke-width="1.5"/>
    <path d="M18 6.6v3.8M16.1 8.5h3.8" stroke="white" stroke-width="1.6" stroke-linecap="round"/>
  </svg>`;

/** Filled document with a plus badge (FAB "new note"). @param {string} [cls] */
export const notePlus = (cls = 'size-6') =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">
    <path fill="currentColor" d="M6.5 2.5h6.8L18.5 7.7v4a6 6 0 0 0-7.3 9.8H6.5A2.5 2.5 0 0 1 4 19V5a2.5 2.5 0 0 1 2.5-2.5z"/>
    <path fill="white" fill-opacity=".55" d="M13.3 2.5v3.7a1.5 1.5 0 0 0 1.5 1.5h3.7z"/>
    <circle cx="17" cy="17" r="4.6" fill="currentColor" stroke="white" stroke-width="1.5"/>
    <path d="M17 14.9v4.2M14.9 17h4.2" stroke="white" stroke-width="1.6" stroke-linecap="round"/>
  </svg>`;

/** Filled house (FAB "home"). @param {string} [cls] */
export const homeFilled = (cls = 'size-6') =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">
    <path fill="currentColor" d="M10.6 3.5a2.2 2.2 0 0 1 2.8 0l6.4 5.3c.5.4.7 1 .7 1.6V18a2.5 2.5 0 0 1-2.5 2.5H15v-5a1.5 1.5 0 0 0-1.5-1.5h-3A1.5 1.5 0 0 0 9 15.5v5H6A2.5 2.5 0 0 1 3.5 18v-7.6c0-.6.3-1.2.7-1.6z"/>
  </svg>`;

/** Folder with an arrow (move). @param {string} [cls] */
export const move = (cls = 'size-5') =>
  svg('<path d="M3.5 7.5A2.5 2.5 0 0 1 6 5h3.6a2 2 0 0 1 1.6.8L12.5 7.5H18a2.5 2.5 0 0 1 2.5 2.5v7.5A2.5 2.5 0 0 1 18 20H6a2.5 2.5 0 0 1-2.5-2.5z"/><path d="M9 13.5h6M12.5 11l2.5 2.5-2.5 2.5"/>', cls, { stroke: 2 });

/** @param {string} [cls] */
export const download = (cls = 'size-5') =>
  svg('<path d="M12 4v11"/><path d="m7 10.5 5 5 5-5"/><path d="M5 19.5h14"/>', cls, { stroke: 2.2 });

/** @param {string} [cls] */
export const upload = (cls = 'size-5') =>
  svg('<path d="M12 15.5V4.5"/><path d="m7 9 5-5 5 5"/><path d="M5 19.5h14"/>', cls, { stroke: 2.2 });

/** Three dots (more options). @param {string} [cls] */
export const more = (cls = 'size-5') =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><circle cx="5.5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="18.5" cy="12" r="2"/></svg>`;

/** Phone with a down arrow (install app). @param {string} [cls] */
export const installApp = (cls = 'size-5') =>
  svg('<rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M12 7.5v7"/><path d="m9 11.5 3 3 3-3"/><path d="M10.5 18.5h3"/>', cls, { stroke: 2 });

/** iOS-style share (box with up arrow). @param {string} [cls] */
export const share = (cls = 'size-5') =>
  svg('<path d="M12 3v12"/><path d="m8 7 4-4 4 4"/><path d="M8 10.5H6.5A1.5 1.5 0 0 0 5 12v7.5A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5V12a1.5 1.5 0 0 0-1.5-1.5H16"/>', cls, { stroke: 2 });

/** @param {string} [cls] */
export const chevronRight = (cls = 'size-3.5') =>
  svg('<path d="m9.5 6 6 6-6 6"/>', cls, { stroke: 2.4 });
