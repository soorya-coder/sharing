/**
 * Floating action button (bottom-right). Closed: slate circle with a 2x2 grid icon.
 * Open: blue circle with an X, and three mini-buttons fan out in an arc with a staggered
 * scale + fade: Home (up), New note (diagonal), New folder (left).
 */
import { htmlToElement } from '../lib/utils.js';
import * as icons from './icons.js';

/**
 * @typedef {Object} FabAction
 * @property {string} id
 * @property {string} label           accessible name
 * @property {string} icon            SVG markup
 * @property {boolean} [accent]       orange-filled circle with white icon (Home)
 * @property {[number, number]} offset  [x, y] in px from the FAB center when open
 * @property {() => void} run
 */

/**
 * Creates and mounts the FAB. Call the returned function to remove it.
 * @param {{ actions: FabAction[] }} options
 * @returns {() => void} destroy
 */
export function mountFabMenu({ actions }) {
  const root = htmlToElement(`
    <div class="fab-root">
      <button type="button" class="fab-backdrop fixed inset-0 z-30 cursor-default" tabindex="-1" aria-hidden="true" hidden></button>
      <div class="fab-anchor fixed z-40 size-16">
        ${actions.map((a, i) => `
          <button type="button" data-fab="${a.id}" aria-label="${a.label}" title="${a.label}" tabindex="-1"
            class="fab-mini absolute left-1 top-1 flex size-14 items-center justify-center rounded-full shadow-fab
                   ${a.accent ? 'bg-orange text-white' : 'bg-white text-orange'}"
            style="--x: ${a.offset[0]}px; --y: ${a.offset[1]}px; --i: ${i}">
            ${a.icon}
          </button>`).join('')}
        <button type="button" data-fab="toggle" aria-label="Open menu" aria-expanded="false"
          class="fab-main relative flex size-16 items-center justify-center rounded-full bg-slate text-white shadow-fab">
          <span class="fab-icon-grid absolute">${icons.grid('size-7')}</span>
          <span class="fab-icon-close absolute">${icons.close('size-7')}</span>
        </button>
      </div>
    </div>`);

  const toggle = /** @type {HTMLButtonElement} */ (root.querySelector('[data-fab="toggle"]'));
  const backdrop = /** @type {HTMLButtonElement} */ (root.querySelector('.fab-backdrop'));
  const minis = /** @type {NodeListOf<HTMLButtonElement>} */ (root.querySelectorAll('.fab-mini'));

  /** @param {boolean} open */
  function setOpen(open) {
    root.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    backdrop.hidden = !open;
    minis.forEach((m) => { m.tabIndex = open ? 0 : -1; });
  }

  root.addEventListener('click', (e) => {
    const id = /** @type {HTMLElement} */ (e.target).closest('[data-fab]')?.getAttribute('data-fab');
    if (id === 'toggle') {
      setOpen(!root.classList.contains('is-open'));
      return;
    }
    if (e.target === backdrop) {
      setOpen(false);
      return;
    }
    const action = actions.find((a) => a.id === id);
    if (action) {
      setOpen(false);
      action.run();
    }
  });

  /** @param {KeyboardEvent} e */
  const onKey = (e) => {
    if (e.key === 'Escape' && root.classList.contains('is-open')) setOpen(false);
  };
  document.addEventListener('keydown', onKey);
  document.body.append(root);

  return () => {
    document.removeEventListener('keydown', onKey);
    root.remove();
  };
}

/**
 * The standard three actions, arranged in a quarter-circle arc (radius ~104px).
 * @param {{ onHome: () => void, onNewNote: () => void, onNewFolder: () => void }} handlers
 * @returns {FabAction[]}
 */
export function defaultFabActions({ onHome, onNewNote, onNewFolder }) {
  return [
    { id: 'home', label: 'Home', icon: icons.homeFilled('size-7'), accent: true, offset: [0, -104], run: onHome },
    { id: 'note', label: 'New note', icon: icons.notePlus('size-7'), offset: [-74, -74], run: onNewNote },
    { id: 'folder', label: 'New folder', icon: icons.folderPlus('size-7'), offset: [-104, 0], run: onNewFolder },
  ];
}
