/**
 * Note card: full-width rounded card with a horizontal gradient of the note's color,
 * title, body preview, task progress, and a drag handle for SortableJS.
 */
import { escapeHtml, htmlToElement } from '../lib/utils.js';
import * as icons from './icons.js';

const { dragHandle } = icons;

/** @typedef {import('../lib/data/adapters/types.js').Note} Note */

/**
 * @param {Note} note
 * @param {{ done: number, total: number }} [taskStats]
 * @returns {HTMLElement} element with data-id
 */
export function renderNoteCard(note, taskStats = { done: 0, total: 0 }) {
  const title = note.title.trim();
  const body = note.body.trim();
  return htmlToElement(`
    <div data-id="${escapeHtml(note.id)}"
         class="tinted note-card-bg flex min-h-28 items-stretch rounded-card transition"
         style="--c: ${escapeHtml(note.colorHex)}">
      <a href="#/note/${encodeURIComponent(note.id)}" class="flex min-w-0 flex-1 select-none flex-col justify-center py-6 pl-7 pr-2 active:opacity-80 [-webkit-touch-callout:none]">
        <h3 class="truncate text-[26px] leading-tight ${title ? 'text-ink' : 'text-ink/35'}">${escapeHtml(title || 'Untitled')}</h3>
        ${body ? `<p class="line-clamp-3 mt-2 whitespace-pre-line text-[16px] leading-snug text-ink/75">${escapeHtml(body)}</p>` : ''}
        ${taskStats.total && taskStats.done === taskStats.total ? `
          <span class="completed-chip mt-3 inline-flex items-center gap-1 self-start rounded-full px-3 py-1 text-xs font-bold tracking-wide">
            ${icons.check('size-3.5')} Completed
          </span>` : taskStats.total ? `
          <span class="mt-3 self-start rounded-full bg-white/60 px-3 py-1 text-xs font-semibold tracking-wide text-ink/70">
            ${taskStats.done}/${taskStats.total} tasks
          </span>` : ''}
      </a>
      <button type="button" class="drag-handle flex w-16 shrink-0 items-center justify-center text-ink/70" aria-label="Drag to reorder">
        ${dragHandle('size-7')}
      </button>
    </div>`);
}
