/**
 * App configuration.
 *
 * STORAGE picks the storage adapter used by all repositories:
 *   'local'     – IndexedDB via Dexie (works offline, implemented)
 *   'firestore' – Firebase Firestore via the Firebase CDN (stub, see firestoreAdapter.js)
 *   'api'       – Future Node.js REST backend (stub, see apiAdapter.js)
 *
 * @type {'local' | 'firestore' | 'api'}
 */
export const STORAGE = 'local';

/** IndexedDB database name used by the local adapter. */
export const LOCAL_DB_NAME = 'memo-pad';

/** Base URL for the future REST API (used by apiAdapter.js). */
export const API_BASE_URL = '/api';

/**
 * Firebase web config (used by firestoreAdapter.js). Fill in when adding Firestore.
 * @type {Record<string, string>}
 */
export const FIREBASE_CONFIG = {};
