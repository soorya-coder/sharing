/**
 * Hash-based router: #/ , #/folder/:id , #/note/:id , #/search
 *
 * A view is a function mount(outlet, params) that renders into `outlet` and returns a cleanup
 * function (which may be async, e.g. the note editor saves on exit). The router awaits the
 * previous view's cleanup before mounting the next one.
 *
 * Every history entry gets an index in history.state so we can tell whether "back" stays inside
 * the app, and what the previous route was.
 */

/**
 * @typedef {(outlet: HTMLElement, params: Record<string, string>) => (void | (() => void | Promise<void>))} View
 */

/** @type {Array<{ pattern: RegExp, keys: string[], view: View }>} */
const routes = [];
/** @type {View | null} */
let notFound = null;
/** @type {HTMLElement} */
let outlet;
/** @type {(() => void | Promise<void>) | void} */
let cleanup;
let renderToken = 0;

const STACK_KEY = 'memo-route-stack';
/** @type {string[]} path for each history index in this tab */
const stack = JSON.parse(sessionStorage.getItem(STACK_KEY) || '[]');

/**
 * Registers a route. Pattern segments starting with ":" are params, e.g. "/folder/:id".
 * @param {string} path
 * @param {View} view
 */
export function route(path, view) {
  const keys = [];
  const re = path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; });
  routes.push({ pattern: new RegExp(`^${re}$`), keys, view });
}

/** @param {View} view shown when no route matches */
export function fallback(view) {
  notFound = view;
}

/**
 * Current path without the leading "#", e.g. "/folder/abc".
 * @returns {string}
 */
export function currentPath() {
  return location.hash.replace(/^#/, '') || '/';
}

/**
 * Goes to a path. replace: true replaces the current history entry.
 * @param {string} path e.g. "/note/123"
 * @param {{ replace?: boolean }} [options]
 */
export function navigate(path, { replace = false } = {}) {
  if (replace) {
    history.replaceState(history.state, '', `#${path}`);
    onRouteChange();
  } else if (currentPath() !== path) {
    location.hash = path;
  }
}

/**
 * Navigates "up" to a target (e.g. the parent folder). If the previous history entry is exactly
 * that target, uses history.back() so the browser back stack stays clean; otherwise pushes it.
 * @param {string} path
 */
export function goUp(path) {
  const idx = history.state?.memoIdx ?? 0;
  if (idx > 0 && stack[idx - 1] === path) history.back();
  else navigate(path);
}

/**
 * Goes back if the previous entry belongs to this app, otherwise replaces with `fallbackPath`.
 * @param {string} fallbackPath
 */
export function back(fallbackPath = '/') {
  const idx = history.state?.memoIdx ?? 0;
  if (idx > 0 && stack[idx - 1] != null) history.back();
  else navigate(fallbackPath, { replace: true });
}

function trackHistory() {
  let idx = history.state?.memoIdx;
  if (idx == null) {
    // A brand-new entry: it follows the entry we were on (stack length - 1 after truncation).
    idx = Math.max(0, lastIdx + 1);
    history.replaceState({ ...(history.state || {}), memoIdx: idx }, '');
    stack.length = idx;
  }
  stack[idx] = currentPath();
  lastIdx = idx;
  sessionStorage.setItem(STACK_KEY, JSON.stringify(stack));
}
let lastIdx = -1;

async function onRouteChange() {
  trackHistory();
  const token = ++renderToken;
  const path = currentPath();

  if (typeof cleanup === 'function') {
    const c = cleanup;
    cleanup = undefined;
    try { await c(); } catch (err) { console.error('view cleanup failed', err); }
  }
  if (token !== renderToken) return; // another navigation happened meanwhile

  /** @type {View | null} */
  let view = notFound;
  /** @type {Record<string, string>} */
  let params = {};
  for (const r of routes) {
    const m = path.match(r.pattern);
    if (m) {
      view = r.view;
      params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
      break;
    }
  }

  outlet.replaceChildren();
  outlet.classList.remove('view-enter');
  void outlet.offsetWidth; // restart the enter animation
  outlet.classList.add('view-enter');
  window.scrollTo(0, 0);
  cleanup = view ? view(outlet, params) : undefined;
}

/**
 * Starts listening for hash changes and renders the current route.
 * @param {HTMLElement} el outlet element
 */
export function start(el) {
  outlet = el;
  lastIdx = (history.state?.memoIdx ?? stack.length) - 1;
  window.addEventListener('hashchange', onRouteChange);
  if (!location.hash) history.replaceState(history.state, '', '#/');
  onRouteChange();
}
