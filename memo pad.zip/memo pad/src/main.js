/**
 * App entry point: registers routes and starts the router.
 */
import { route, fallback, start } from './router.js';
import { folderView } from './views/folderView.js';
import { noteView } from './views/noteView.js';
import { searchView } from './views/searchView.js';
import { initInstall } from './lib/install.js';

initInstall(); // first, so the browser's install event is never missed

route('/', (outlet) => folderView(outlet, {}));
route('/folder/:id', folderView);
route('/note/:id', noteView);
route('/search', searchView);
fallback((outlet) => folderView(outlet, {}));

start(/** @type {HTMLElement} */ (document.getElementById('app')));

// Offline support (PWA). Service workers need a secure context: https, or localhost / 127.0.0.1.
// Opened over plain http from another device (http://192.168.x.x) the app still works, just not offline.
if ('serviceWorker' in navigator && window.isSecureContext) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((err) => console.warn('Service worker registration failed', err));
  });
}

// Developer helpers, only on local hosts: open DevTools and run `await memoDev.seed()`.
if (['localhost', '127.0.0.1'].includes(location.hostname)) {
  /** @type {any} */ (window).memoDev = {
    async seed() {
      const { seedSampleData } = await import('./lib/devSeed.js');
      await seedSampleData();
    },
  };
}
