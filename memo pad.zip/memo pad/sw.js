/**
 * MEMO pad service worker: makes the app work fully offline.
 *
 * Strategy
 *   - On install, pre-cache the app shell (HTML, JS modules, CSS, icons) and vendor files.
 *   - App files: NETWORK FIRST (with a short timeout), falling back to the cache. While you
 *     develop with Live Server you always get the latest code; offline you get the cached copy.
 *   - vendor/ files: CACHE FIRST. They are pinned versions and never change.
 *   - Page navigations offline fall back to the cached index.html (the router uses #hash URLs).
 *
 * When you add a new source file, add it to APP_SHELL below and bump CACHE_VERSION.
 * When you upgrade a vendor library, update VENDOR and bump CACHE_VERSION.
 */
const CACHE_VERSION = 'v6';
const APP_CACHE = `memo-app-${CACHE_VERSION}`;
const VENDOR_CACHE = `memo-vendor-${CACHE_VERSION}`;
const NETWORK_TIMEOUT_MS = 3000;

const APP_SHELL = [
  './',
  'index.html',
  'manifest.json',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-512.png',
  'icons/apple-touch-icon.png',
  'icons/favicon-32.png',
  'src/styles/main.css',
  'src/main.js',
  'src/router.js',
  'src/config.js',
  'src/lib/auth.js',
  'src/lib/utils.js',
  'src/lib/palette.js',
  'src/lib/sortable.js',
  'src/lib/install.js',
  'src/lib/devSeed.js',
  'src/lib/data/adapter.js',
  'src/lib/data/adapters/localAdapter.js',
  'src/lib/data/adapters/firestoreAdapter.js',
  'src/lib/data/adapters/apiAdapter.js',
  'src/lib/data/repos/common.js',
  'src/lib/data/repos/folderRepo.js',
  'src/lib/data/repos/noteRepo.js',
  'src/lib/data/repos/taskRepo.js',
  'src/lib/data/repos/searchRepo.js',
  'src/lib/data/repos/backupRepo.js',
  'src/views/folderView.js',
  'src/views/noteView.js',
  'src/views/searchView.js',
  'src/views/backupMenu.js',
  'src/components/icons.js',
  'src/components/dialog.js',
  'src/components/toast.js',
  'src/components/folderCard.js',
  'src/components/noteCard.js',
  'src/components/taskItem.js',
  'src/components/fabMenu.js',
  'src/components/colorPicker.js',
  'src/components/folderPicker.js',
];

const VENDOR = [
  'vendor/tailwindcss-browser.js',
  'vendor/dexie.mjs',
  'vendor/sortable.esm.js',
  'vendor/fonts/kaushan-script-latin-400-normal.woff2',
];

/** Absolute URL for a path relative to the service worker's scope. */
const url = (path) => new URL(path, self.registration.scope).href;

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const [app, vendor] = await Promise.all([caches.open(APP_CACHE), caches.open(VENDOR_CACHE)]);
    // cache: 'reload' bypasses the HTTP cache so we store fresh copies.
    await Promise.all([
      app.addAll(APP_SHELL.map((p) => new Request(url(p), { cache: 'reload' }))),
      vendor.addAll(VENDOR.map((p) => new Request(url(p), { cache: 'reload' }))),
    ]);
    await self.skipWaiting(); // activate the new version right away
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keep = new Set([APP_CACHE, VENDOR_CACHE]);
    for (const key of await caches.keys()) {
      if (key.startsWith('memo-') && !keep.has(key)) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});

/**
 * Network first with a timeout; on failure (offline / too slow) use the cache.
 * Successful responses refresh the cache.
 * @param {Request} request
 * @param {string} [fallbackPath] cached path to use when nothing matches (navigations)
 */
async function networkFirst(request, fallbackPath) {
  const cache = await caches.open(APP_CACHE);
  try {
    const response = await Promise.race([
      fetch(request),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), NETWORK_TIMEOUT_MS)),
    ]);
    if (response.ok) cache.put(request, response.clone());
    return response;
  } catch {
    const cached = await cache.match(request, { ignoreSearch: true })
      ?? (fallbackPath ? await cache.match(url(fallbackPath)) : undefined);
    if (cached) return cached;
    return new Response('Offline and not cached yet.', { status: 503, headers: { 'Content-Type': 'text/plain' } });
  }
}

/**
 * Cache first (immutable vendor files); fetch and store on a miss.
 * @param {Request} request
 */
async function cacheFirst(request) {
  const cache = await caches.open(VENDOR_CACHE);
  const cached = await cache.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response.ok) cache.put(request, response.clone());
  return response;
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const reqUrl = new URL(request.url);
  if (reqUrl.origin !== self.location.origin) return; // e.g. a future Firebase CDN: let the browser handle it
  const path = reqUrl.pathname;
  if (path.includes('/tests/')) return; // never cache the test pages

  if (request.mode === 'navigate') {
    event.respondWith(networkFirst(request, 'index.html'));
  } else if (path.includes('/vendor/')) {
    event.respondWith(cacheFirst(request));
  } else {
    event.respondWith(networkFirst(request));
  }
});
