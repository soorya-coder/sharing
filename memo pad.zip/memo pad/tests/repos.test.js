/**
 * Repository tests. Each test gets a fresh, separate IndexedDB database ('memo-pad-test'),
 * so the app's real database ('memo-pad') is never touched.
 */
import { describe, it, beforeEach, assert, waitFor } from './testRunner.js';
import { setAdapter } from '../src/lib/data/adapter.js';
import { createLocalAdapter } from '../src/lib/data/adapters/localAdapter.js';
import { createFirestoreAdapter } from '../src/lib/data/adapters/firestoreAdapter.js';
import { createApiAdapter } from '../src/lib/data/adapters/apiAdapter.js';
import { getCurrentUser } from '../src/lib/auth.js';
import * as folderRepo from '../src/lib/data/repos/folderRepo.js';
import * as noteRepo from '../src/lib/data/repos/noteRepo.js';
import * as taskRepo from '../src/lib/data/repos/taskRepo.js';
import * as searchRepo from '../src/lib/data/repos/searchRepo.js';
import * as backupRepo from '../src/lib/data/repos/backupRepo.js';

const TEST_DB = 'memo-pad-test';

/** @type {ReturnType<typeof createLocalAdapter> | null} */
let adapter = null;

async function freshDb() {
  if (adapter) await adapter.deleteDatabase();
  adapter = createLocalAdapter({ dbName: TEST_DB, getUserId: () => getCurrentUser().id });
  setAdapter(adapter);
}

const INTERFACE = [
  'getFolders', 'getFolder', 'createFolder', 'updateFolder', 'deleteFolder',
  'getNotes', 'getNote', 'createNote', 'updateNote', 'deleteNote',
  'getTasks', 'createTask', 'updateTask', 'deleteTask',
  'search', 'subscribe',
];

describe('Adapter interface', () => {
  it('local, firestore and api adapters expose the same methods', () => {
    const opts = { getUserId: () => 'u' };
    for (const [name, a] of [
      ['local', createLocalAdapter({ ...opts, dbName: 'memo-pad-test-iface' })],
      ['firestore', createFirestoreAdapter(opts)],
      ['api', createApiAdapter(opts)],
    ]) {
      for (const m of INTERFACE) assert(typeof a[m] === 'function', `${name} adapter is missing ${m}`);
    }
  });

  it('stub adapters throw "Not implemented"', async () => {
    const a = createFirestoreAdapter({ getUserId: () => 'u' });
    await assert.rejects(() => a.getFolders(null), /Not implemented/);
    const b = createApiAdapter({ getUserId: () => 'u' });
    await assert.rejects(() => b.getNote('x'), /Not implemented/);
  });
});

describe('folderRepo', () => {
  beforeEach(freshDb);

  it('creates a folder with all base fields', async () => {
    const f = await folderRepo.create({ name: 'Work', colorHex: '#ABCDEF' });
    assert(typeof f.id === 'string' && f.id.length > 10, 'id');
    assert.equal(f.userId, 'local-user');
    assert(typeof f.createdAt === 'number' && f.createdAt === f.updatedAt, 'timestamps');
    assert.equal(f.deleted, false);
    assert.equal(f.parentFolderId, null);
    assert.equal(f.ancestorIds, []);
    assert.equal((await folderRepo.get(f.id))?.name, 'Work');
  });

  it('lists Home and nested folders separately, sorted by creation', async () => {
    const a = await folderRepo.create({ name: 'A' });
    const b = await folderRepo.create({ name: 'B' });
    const a1 = await folderRepo.create({ name: 'A1', parentFolderId: a.id });
    assert.equal((await folderRepo.list(null)).map((f) => f.name), ['A', 'B']);
    assert.equal((await folderRepo.list(a.id)).map((f) => f.name), ['A1']);
    assert.equal((await folderRepo.list(b.id)), []);
    assert.equal(a1.ancestorIds, [a.id]);
  });

  it('stores full ancestorIds at any depth and builds the breadcrumb path', async () => {
    const a = await folderRepo.create({ name: 'Work' });
    const b = await folderRepo.create({ name: 'Ideas', parentFolderId: a.id });
    const c = await folderRepo.create({ name: 'Deep', parentFolderId: b.id });
    assert.equal(c.ancestorIds, [a.id, b.id]);
    assert.equal((await folderRepo.getPath(c.id)).map((f) => f.name), ['Work', 'Ideas', 'Deep']);
    assert.equal(await folderRepo.getPath(null), []);
  });

  it('renames and updates updatedAt', async () => {
    const f = await folderRepo.create({ name: 'Old' });
    await new Promise((r) => setTimeout(r, 5));
    const r = await folderRepo.rename(f.id, '  New  ');
    assert.equal(r?.name, 'New');
    assert(/** @type {any} */ (r).updatedAt > f.updatedAt, 'updatedAt bumped');
  });

  it('delete cascades to subfolders, notes and tasks, with correct counts', async () => {
    const a = await folderRepo.create({ name: 'A' });
    const b = await folderRepo.create({ name: 'B', parentFolderId: a.id });
    const n1 = await noteRepo.create({ folderId: a.id, title: 'n1' });
    const n2 = await noteRepo.create({ folderId: b.id, title: 'n2' });
    await taskRepo.create({ noteId: n1.id, title: 't1' });
    await taskRepo.create({ noteId: n2.id, title: 't2' });
    await taskRepo.create({ noteId: n2.id, title: 't3' });
    const keep = await folderRepo.create({ name: 'Keep' });

    assert.equal(await folderRepo.countContents(a.id), { folders: 1, notes: 2, tasks: 3 });
    const handle = await folderRepo.remove(a.id);
    assert.equal(handle.counts, { folders: 2, notes: 2, tasks: 3 });

    assert.equal((await folderRepo.list(null)).map((f) => f.id), [keep.id]);
    assert.equal(await folderRepo.get(b.id), null);
    assert.equal(await noteRepo.get(n2.id), null);
    assert.equal(await taskRepo.list(n2.id), []);
  });

  it('undo restores a deleted folder tree', async () => {
    const a = await folderRepo.create({ name: 'A' });
    const b = await folderRepo.create({ name: 'B', parentFolderId: a.id });
    const n = await noteRepo.create({ folderId: b.id, title: 'n' });
    await taskRepo.create({ noteId: n.id, title: 't' });
    const handle = await folderRepo.remove(a.id);
    await handle.undo();
    assert.equal((await folderRepo.list(null)).length, 1);
    assert.equal((await folderRepo.list(a.id)).length, 1);
    assert.equal((await noteRepo.list(b.id)).length, 1);
    assert.equal((await taskRepo.list(n.id)).length, 1);
  });

  it('move rewrites ancestorIds of the folder and all descendants', async () => {
    const x = await folderRepo.create({ name: 'X' });
    const y = await folderRepo.create({ name: 'Y' });
    const a = await folderRepo.create({ name: 'A', parentFolderId: x.id });
    const b = await folderRepo.create({ name: 'B', parentFolderId: a.id });
    const c = await folderRepo.create({ name: 'C', parentFolderId: b.id });

    await folderRepo.move(a.id, y.id);
    assert.equal((await folderRepo.get(a.id))?.ancestorIds, [y.id]);
    assert.equal((await folderRepo.get(a.id))?.parentFolderId, y.id);
    assert.equal((await folderRepo.get(b.id))?.ancestorIds, [y.id, a.id]);
    assert.equal((await folderRepo.get(c.id))?.ancestorIds, [y.id, a.id, b.id]);
    assert.equal(await folderRepo.list(x.id), []);

    await folderRepo.move(a.id, null);
    assert.equal((await folderRepo.get(c.id))?.ancestorIds, [a.id, b.id]);
  });

  it('listTree returns every folder depth-first with depths', async () => {
    const a = await folderRepo.create({ name: 'A' });
    const a1 = await folderRepo.create({ name: 'A1', parentFolderId: a.id });
    await folderRepo.create({ name: 'A1x', parentFolderId: a1.id });
    await folderRepo.create({ name: 'B' });
    const tree = await folderRepo.listTree();
    assert.equal(tree.map((r) => [r.folder.name, r.depth]), [['A', 0], ['A1', 1], ['A1x', 2], ['B', 0]]);
  });

  it('refuses to move a folder into itself or a descendant', async () => {
    const a = await folderRepo.create({ name: 'A' });
    const b = await folderRepo.create({ name: 'B', parentFolderId: a.id });
    const c = await folderRepo.create({ name: 'C', parentFolderId: b.id });
    await assert.rejects(() => folderRepo.move(a.id, a.id), /cannot be moved/);
    await assert.rejects(() => folderRepo.move(a.id, c.id), /cannot be moved/);
    assert(await folderRepo.isSelfOrDescendant(a.id, b.id));
    assert(!(await folderRepo.isSelfOrDescendant(b.id, a.id)));
  });

  it('subscribeChildren fires on changes', async () => {
    /** @type {string[][]} */
    const seen = [];
    const unsub = folderRepo.subscribeChildren(null, (rows) => seen.push(rows.map((f) => f.name)));
    await waitFor(() => seen.length >= 1);
    await folderRepo.create({ name: 'Live' });
    await waitFor(() => seen.some((s) => s.includes('Live')));
    unsub();
  });
});

describe('noteRepo', () => {
  beforeEach(freshDb);

  it('creates notes at the top of the folder', async () => {
    const n1 = await noteRepo.create({ title: 'first' });
    const n2 = await noteRepo.create({ title: 'second' });
    assert.equal((await noteRepo.list(null)).map((n) => n.id), [n2.id, n1.id]);
    assert.equal(n1.folderId, null);
    assert.equal(n1.deleted, false);
  });

  it('updates title and body', async () => {
    const n = await noteRepo.create();
    await noteRepo.update(n.id, { title: 'T', body: 'B' });
    const got = await noteRepo.get(n.id);
    assert.equal([got?.title, got?.body], ['T', 'B']);
  });

  it('reorder persists the given order', async () => {
    const a = await noteRepo.create({ title: 'a' });
    const b = await noteRepo.create({ title: 'b' });
    const c = await noteRepo.create({ title: 'c' });
    await noteRepo.reorder([a.id, c.id, b.id]);
    assert.equal((await noteRepo.list(null)).map((n) => n.title), ['a', 'c', 'b']);
  });

  it('delete soft-deletes the note and its tasks; undo restores them', async () => {
    const n = await noteRepo.create({ title: 'n' });
    await taskRepo.create({ noteId: n.id, title: 't1' });
    await taskRepo.create({ noteId: n.id, title: 't2' });
    const handle = await noteRepo.remove(n.id);
    assert.equal(handle.counts, { folders: 0, notes: 1, tasks: 2 });
    assert.equal(await noteRepo.get(n.id), null);
    assert.equal(await taskRepo.list(n.id), []);
    await handle.undo();
    assert.equal((await noteRepo.get(n.id))?.title, 'n');
    assert.equal((await taskRepo.list(n.id)).length, 2);
  });

  it('move puts the note in another folder', async () => {
    const f = await folderRepo.create({ name: 'F' });
    const n = await noteRepo.create({ title: 'n' });
    await noteRepo.move(n.id, f.id);
    assert.equal(await noteRepo.list(null), []);
    assert.equal((await noteRepo.list(f.id)).map((x) => x.id), [n.id]);
  });

  it('isEmpty is true only with no title, body or tasks', async () => {
    const n = await noteRepo.create();
    assert(await noteRepo.isEmpty(n.id), 'blank note');
    await noteRepo.update(n.id, { title: '   ' });
    assert(await noteRepo.isEmpty(n.id), 'whitespace title counts as empty');
    await taskRepo.create({ noteId: n.id, title: 'x' });
    assert(!(await noteRepo.isEmpty(n.id)), 'has a task');
  });

  it('subscribeOne reports null after delete', async () => {
    const n = await noteRepo.create({ title: 'live' });
    /** @type {any[]} */
    const seen = [];
    const unsub = noteRepo.subscribeOne(n.id, (note) => seen.push(note));
    await waitFor(() => seen.length >= 1 && seen[0]?.title === 'live');
    await noteRepo.remove(n.id);
    await waitFor(() => seen[seen.length - 1] === null);
    unsub();
  });
});

describe('taskRepo', () => {
  beforeEach(freshDb);

  it('creates tasks at the end and requires a title', async () => {
    const n = await noteRepo.create();
    await taskRepo.create({ noteId: n.id, title: 'one' });
    await taskRepo.create({ noteId: n.id, title: ' two ' });
    assert.equal((await taskRepo.list(n.id)).map((t) => t.title), ['one', 'two']);
    await assert.rejects(() => taskRepo.create({ noteId: n.id, title: '  ' }), /required/);
  });

  it('toggles done, renames, reorders', async () => {
    const n = await noteRepo.create();
    const a = await taskRepo.create({ noteId: n.id, title: 'a' });
    const b = await taskRepo.create({ noteId: n.id, title: 'b' });
    await taskRepo.setDone(a.id, true);
    await taskRepo.rename(b.id, 'bee');
    await taskRepo.reorder([b.id, a.id]);
    const list = await taskRepo.list(n.id);
    assert.equal(list.map((t) => [t.title, t.isDone]), [['bee', false], ['a', true]]);
  });

  it('rename rejects an empty title and keeps the old one', async () => {
    const n = await noteRepo.create();
    const t = await taskRepo.create({ noteId: n.id, title: 'keep me' });
    await assert.rejects(() => taskRepo.rename(t.id, '   '), /required/);
    assert.equal((await taskRepo.list(n.id))[0].title, 'keep me');
  });

  it('delete + undo', async () => {
    const n = await noteRepo.create();
    const t = await taskRepo.create({ noteId: n.id, title: 't' });
    const handle = await taskRepo.remove(t.id);
    assert.equal(await taskRepo.list(n.id), []);
    await handle.undo();
    assert.equal((await taskRepo.list(n.id)).length, 1);
  });

  it('subscribeForNotes covers several notes', async () => {
    const n1 = await noteRepo.create();
    const n2 = await noteRepo.create();
    /** @type {number[]} */
    const counts = [];
    const unsub = taskRepo.subscribeForNotes([n1.id, n2.id], (tasks) => counts.push(tasks.length));
    await waitFor(() => counts.length >= 1);
    await taskRepo.create({ noteId: n1.id, title: 'x' });
    await taskRepo.create({ noteId: n2.id, title: 'y' });
    await waitFor(() => counts[counts.length - 1] === 2);
    unsub();
  });
});

describe('searchRepo', () => {
  beforeEach(freshDb);

  it('finds folders, note titles, note bodies and task titles at any depth, case-insensitively', async () => {
    const a = await folderRepo.create({ name: 'Projects' });
    const b = await folderRepo.create({ name: 'Garden plans', parentFolderId: a.id });
    const n1 = await noteRepo.create({ folderId: b.id, title: 'Tomatoes' });
    await noteRepo.create({ folderId: b.id, title: 'Misc', body: 'buy a GARDEN hose' });
    await taskRepo.create({ noteId: n1.id, title: 'water the garden' });
    await noteRepo.create({ title: 'unrelated' });

    const r = await searchRepo.search('garden');
    assert.equal(r.folders.map((f) => f.name), ['Garden plans']);
    assert.equal(r.notes.map((n) => n.title), ['Misc']);
    assert.equal(r.tasks.map((t) => t.title), ['water the garden']);
  });

  it('ignores deleted items and empty queries', async () => {
    const f = await folderRepo.create({ name: 'Secret' });
    await folderRepo.remove(f.id);
    assert.equal((await searchRepo.search('secret')).folders, []);
    assert.equal(await searchRepo.search('   '), { folders: [], notes: [], tasks: [] });
  });
});

describe('backupRepo', () => {
  beforeEach(freshDb);

  it('round-trips folders, notes and tasks through export → fresh database → import', async () => {
    const a = await folderRepo.create({ name: 'A', colorHex: '#FFB3D1' });
    const b = await folderRepo.create({ name: 'B', parentFolderId: a.id });
    const n = await noteRepo.create({ folderId: b.id, title: 'Deep', body: 'note' });
    await noteRepo.create({ title: 'Top' });
    const t = await taskRepo.create({ noteId: n.id, title: 'do it' });
    await taskRepo.setDone(t.id, true);
    const gone = await noteRepo.create({ title: 'deleted' });
    await noteRepo.remove(gone.id);

    const backup = JSON.parse(JSON.stringify(await backupRepo.exportAll()));
    assert.equal([backup.format, backup.version], ['memo-pad-backup', 1]);
    assert.equal([backup.folders.length, backup.notes.length, backup.tasks.length], [2, 2, 1], 'deleted note excluded');

    await freshDb();
    const result = await backupRepo.importAll(backup);
    assert.equal(result, { folders: 2, notes: 2, tasks: 1, skipped: 0 });
    assert.equal((await folderRepo.getPath(b.id)).map((f) => f.name), ['A', 'B']);
    assert.equal((await folderRepo.get(a.id))?.colorHex, '#FFB3D1');
    assert.equal((await noteRepo.list(b.id)).map((x) => x.title), ['Deep']);
    assert.equal((await taskRepo.list(n.id)).map((x) => [x.title, x.isDone]), [['do it', true]]);
  });

  it('merges: same ids are updated, existing data is kept', async () => {
    const keep = await noteRepo.create({ title: 'keep' });
    const n = await noteRepo.create({ title: 'old title' });
    const backup = JSON.parse(JSON.stringify(await backupRepo.exportAll()));
    backup.notes = backup.notes.filter((x) => x.id === n.id).map((x) => ({ ...x, title: 'new title' }));
    await backupRepo.importAll(backup);
    assert.equal((await noteRepo.get(n.id))?.title, 'new title');
    assert.equal((await noteRepo.get(keep.id))?.title, 'keep');
  });

  it('repairs orphans: missing parents go to Home, tasks without a note are skipped', async () => {
    const result = await backupRepo.importAll({
      format: 'memo-pad-backup', version: 1,
      folders: [{ id: 'f1', name: 'Orphan', parentFolderId: 'missing' }, { id: 'f2', name: 'Child', parentFolderId: 'f1' }],
      notes: [{ id: 'n1', title: 'Lost', folderId: 'nope' }],
      tasks: [{ id: 't1', noteId: 'n1', title: 'ok' }, { id: 't2', noteId: 'ghost', title: 'orphan' }],
    });
    assert.equal(result, { folders: 2, notes: 1, tasks: 1, skipped: 1 });
    assert.equal((await folderRepo.get('f1'))?.parentFolderId, null);
    assert.equal((await folderRepo.get('f2'))?.ancestorIds, ['f1']);
    assert.equal((await noteRepo.list(null)).map((x) => x.id), ['n1']);
    assert.equal((await noteRepo.get('n1'))?.userId, 'local-user');
  });

  it('survives a parent cycle in a hand-edited file', async () => {
    await backupRepo.importAll({
      format: 'memo-pad-backup', version: 1, notes: [], tasks: [],
      folders: [{ id: 'x', name: 'X', parentFolderId: 'y' }, { id: 'y', name: 'Y', parentFolderId: 'x' }],
    });
    const x = await folderRepo.get('x');
    const y = await folderRepo.get('y');
    assert(x && y, 'both imported');
    assert(!x.ancestorIds.includes('x') && !y.ancestorIds.includes('y'), 'no folder is its own ancestor');
  });

  it('rejects files that are not MEMO pad backups', async () => {
    await assert.rejects(() => backupRepo.importAll({ hello: 'world' }), /not a MEMO pad backup/);
    await assert.rejects(() => backupRepo.importAll({ format: 'memo-pad-backup', version: 99, folders: [], notes: [], tasks: [] }), /newer version/);
    await assert.rejects(() => backupRepo.importAll({ format: 'memo-pad-backup', version: 1, folders: [{}], notes: [], tasks: [] }), /without an id/);
  });
});

describe('Cleanup', () => {
  it('deletes the test database', async () => {
    if (adapter) await adapter.deleteDatabase();
    adapter = null;
  });
});
