/**
 * A tiny describe/it/assert test runner. No libraries. Tests run sequentially and may be async.
 */

/**
 * @typedef {{ name: string, fn: () => (void | Promise<void>) }} TestCase
 * @typedef {{ name: string, tests: TestCase[], beforeEach: Array<() => any>, afterEach: Array<() => any> }} Suite
 */

/** @type {Suite[]} */
const suites = [];
/** @type {Suite | null} */
let current = null;

/**
 * Groups tests.
 * @param {string} name
 * @param {() => void} body registers tests via it()
 */
export function describe(name, body) {
  current = { name, tests: [], beforeEach: [], afterEach: [] };
  suites.push(current);
  body();
  current = null;
}

/**
 * Registers a test inside describe().
 * @param {string} name
 * @param {() => (void | Promise<void>)} fn
 */
export function it(name, fn) {
  if (!current) throw new Error('it() must be called inside describe()');
  current.tests.push({ name, fn });
}

/** @param {() => any} fn runs before every test in the current describe() */
export function beforeEach(fn) {
  current?.beforeEach.push(fn);
}

/** @param {() => any} fn runs after every test in the current describe() */
export function afterEach(fn) {
  current?.afterEach.push(fn);
}

/**
 * @param {unknown} condition
 * @param {string} [message]
 */
export function assert(condition, message = 'Assertion failed') {
  if (!condition) throw new Error(message);
}

/**
 * Deep equality via JSON (fine for plain records).
 * @param {unknown} actual
 * @param {unknown} expected
 * @param {string} [message]
 */
assert.equal = (actual, expected, message) => {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a !== e) throw new Error(`${message ? message + ': ' : ''}expected ${e}, got ${a}`);
};

/**
 * Asserts that an async function rejects.
 * @param {() => Promise<unknown>} fn
 * @param {RegExp} [pattern] optional match on the error message
 */
assert.rejects = async (fn, pattern) => {
  try {
    await fn();
  } catch (err) {
    if (pattern && !pattern.test(String(/** @type {Error} */ (err).message))) {
      throw new Error(`Rejected with unexpected message: ${/** @type {Error} */ (err).message}`);
    }
    return;
  }
  throw new Error('Expected function to reject');
};

/**
 * Resolves when `predicate` returns true, polling every 10ms (for subscribe() tests).
 * @param {() => boolean} predicate
 * @param {number} [timeout]
 */
export async function waitFor(predicate, timeout = 2000) {
  const start = Date.now();
  while (!predicate()) {
    if (Date.now() - start > timeout) throw new Error('waitFor timed out');
    await new Promise((r) => setTimeout(r, 10));
  }
}

/**
 * Runs every registered suite and renders results into `root`.
 * Also exposes window.__testResults = { passed, failed, done } for automation.
 * @param {HTMLElement} root
 */
export async function run(root) {
  let passed = 0;
  let failed = 0;
  const summary = document.createElement('p');
  summary.className = 'summary';
  summary.textContent = 'Running…';
  root.append(summary);

  for (const suite of suites) {
    const h = document.createElement('h2');
    h.textContent = suite.name;
    const ul = document.createElement('ul');
    root.append(h, ul);
    for (const test of suite.tests) {
      const li = document.createElement('li');
      try {
        for (const fn of suite.beforeEach) await fn();
        await test.fn();
        for (const fn of suite.afterEach) await fn();
        passed++;
        li.className = 'pass';
        li.textContent = `✓ ${test.name}`;
      } catch (err) {
        failed++;
        li.className = 'fail';
        li.textContent = `✗ ${test.name} — ${/** @type {Error} */ (err).message}`;
        console.error(suite.name, '›', test.name, err);
      }
      ul.append(li);
    }
  }

  summary.textContent = `${passed} passed, ${failed} failed`;
  summary.classList.add(failed ? 'fail' : 'pass');
  /** @type {any} */ (window).__testResults = { passed, failed, done: true };
}
