"""Categorical Naive Bayes, written from scratch.

Model:  Result -> every feature, features independent given Result.
    P(R | e1..en)  ∝  P(R) * Π P(ei | R)
Probabilities are estimated by counting with Laplace (add-alpha) smoothing.
Missing evidence is simply left out of the product -- marginalising out an
unobserved leaf of a Naive Bayes model contributes a factor of 1.
"""
import math
from collections import Counter


def normalise_log(log_scores):
    top = max(log_scores.values())
    exp = {k: math.exp(v - top) for k, v in log_scores.items()}
    total = sum(exp.values())
    return {k: v / total for k, v in exp.items()}


class NaiveBayes:
    def __init__(self, features, states, target, alpha=1.0):
        self.features = list(features)
        self.states = states
        self.target = target
        self.classes = list(states[target])
        self.alpha = alpha
        self.prior = {}
        self.likelihood = {}  # feature -> class -> value -> P(value | class)

    def fit(self, records):
        rows = [r for r in records if r.get(self.target) is not None]
        a = self.alpha
        class_counts = Counter(r[self.target] for r in rows)
        self.prior = {c: (class_counts[c] + a) / (len(rows) + a * len(self.classes))
                      for c in self.classes}
        for f in self.features:
            values = self.states[f]
            self.likelihood[f] = {}
            for c in self.classes:
                counts = Counter(r[f] for r in rows if r[self.target] == c and r.get(f) is not None)
                total = sum(counts.values())
                self.likelihood[f][c] = {v: (counts[v] + a) / (total + a * len(values)) for v in values}
        return self

    def observed(self, evidence):
        return [(f, evidence[f]) for f in self.features if evidence.get(f) is not None]

    def predict_proba(self, evidence):
        log_scores = {c: math.log(self.prior[c]) for c in self.classes}
        for f, v in self.observed(evidence):
            for c in self.classes:
                log_scores[c] += math.log(self.likelihood[f][c][v])
        return normalise_log(log_scores)

    def sequential_update(self, evidence):
        """Posterior after adding each observed feature one at a time.

        Returns [(feature, value, posterior), ...] starting with the prior.
        This is Bayes' rule applied repeatedly: today's posterior is
        tomorrow's prior.
        """
        log_scores = {c: math.log(self.prior[c]) for c in self.classes}
        steps = [("(prior)", None, dict(self.prior))]
        for f, v in self.observed(evidence):
            for c in self.classes:
                log_scores[c] += math.log(self.likelihood[f][c][v])
            steps.append((f, v, normalise_log(log_scores)))
        return steps

    def evidence_weights(self, evidence, towards="Fail", against="Pass"):
        """Log-likelihood ratio of each observed feature.

        weight = ln P(v | towards) / P(v | against);  > 0 pushes the
        decision towards `towards`, < 0 pushes it away.
        """
        out = []
        for f, v in self.observed(evidence):
            p_t = self.likelihood[f][towards][v]
            p_a = self.likelihood[f][against][v]
            out.append((f, v, p_t, p_a, math.log(p_t / p_a)))
        return out
