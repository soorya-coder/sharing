"""Evaluation metrics, treating "Fail" (at-risk) as the positive class."""
import math

from .data import POSITIVE, TARGET, without_target
from .decision import decide, realised_cost

EPS = 1e-6


def evaluate(model, records, threshold=0.5):
    """Score a fitted model on labelled records.

    Classification metrics use P(Fail) >= threshold; decision cost uses the
    minimum-expected-cost action from the decision layer.
    """
    tp = fp = fn = tn = 0
    log_loss = brier = cost = 0.0
    n = 0
    for r in records:
        truth = r.get(TARGET)
        if truth is None:
            continue
        posterior = model.predict_proba(without_target(r))
        p = posterior[POSITIVE]
        is_pos = truth == POSITIVE
        pred_pos = p >= threshold
        tp += pred_pos and is_pos
        fp += pred_pos and not is_pos
        fn += (not pred_pos) and is_pos
        tn += (not pred_pos) and not is_pos

        p_clip = min(max(p, EPS), 1 - EPS)
        log_loss -= math.log(p_clip if is_pos else 1 - p_clip)
        brier += (p - is_pos) ** 2
        action, _ = decide(posterior)
        cost += realised_cost(action, truth)
        n += 1

    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    return {
        "n": n, "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "accuracy": (tp + tn) / n,
        "precision": precision,
        "recall": recall,
        "specificity": tn / (tn + fp) if tn + fp else 0.0,
        "f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.0,
        "log_loss": log_loss / n,
        "brier": brier / n,
        "avg_cost": cost / n,
    }
