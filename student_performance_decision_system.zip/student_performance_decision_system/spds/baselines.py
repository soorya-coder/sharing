"""Alternative approaches to compare the Bayesian models against."""
import math
from collections import Counter


class PriorBaseline:
    """Ignores the student entirely and always returns the class frequencies."""

    def __init__(self, target, classes):
        self.target = target
        self.classes = classes
        self.prior = {}

    def fit(self, records):
        counts = Counter(r[self.target] for r in records if r.get(self.target))
        total = sum(counts.values())
        self.prior = {c: counts[c] / total for c in self.classes}
        return self

    def predict_proba(self, evidence):
        return dict(self.prior)


class RuleBasedBaseline:
    """Hand-written rules a teacher might use. Certain (0/1) answers, no learning."""

    def fit(self, records):
        return self

    @staticmethod
    def at_risk(e):
        return (e.get("Attendance") == "Low"
                or e.get("InternalMarks") == "Poor"
                or (e.get("PrevGPA") == "Poor" and e.get("Assignments") == "Incomplete"))

    def predict_proba(self, evidence):
        fail = 1.0 if self.at_risk(evidence) else 0.0
        return {"Pass": 1.0 - fail, "Fail": fail}


def _entropy(counts):
    total = sum(counts.values())
    return -sum(c / total * math.log2(c / total) for c in counts.values() if c)


class DecisionTreeID3:
    """ID3 decision tree (information gain) with smoothed leaf probabilities.

    Rows missing the split feature stay in the parent's statistics but are not
    sent down a branch; at prediction time a missing value stops at the
    current node and uses its class distribution.
    """

    def __init__(self, features, states, target, max_depth=4, min_samples=20, alpha=1.0):
        self.features = list(features)
        self.states = states
        self.target = target
        self.classes = list(states[target])
        self.max_depth = max_depth
        self.min_samples = min_samples
        self.alpha = alpha
        self.root = None

    def fit(self, records):
        rows = [r for r in records if r.get(self.target) is not None]
        self.root = self._build(rows, self.features, 0)
        return self

    def _dist(self, rows):
        counts = Counter(r[self.target] for r in rows)
        total = len(rows) + self.alpha * len(self.classes)
        return {c: (counts[c] + self.alpha) / total for c in self.classes}

    def _build(self, rows, features, depth):
        node = {"dist": self._dist(rows), "n": len(rows)}
        labels = Counter(r[self.target] for r in rows)
        if depth >= self.max_depth or len(rows) < self.min_samples or len(labels) <= 1 or not features:
            return node

        best, best_gain = None, 1e-3
        for f in features:
            known = [r for r in rows if r.get(f) is not None]
            if not known:
                continue
            parent_h = _entropy(Counter(r[self.target] for r in known))
            child_h = 0.0
            for v in self.states[f]:
                subset = [r for r in known if r[f] == v]
                if subset:
                    child_h += len(subset) / len(known) * _entropy(Counter(r[self.target] for r in subset))
            gain = parent_h - child_h
            if gain > best_gain:
                best, best_gain = f, gain
        if best is None:
            return node

        node["feature"] = best
        node["children"] = {}
        remaining = [f for f in features if f != best]
        for v in self.states[best]:
            subset = [r for r in rows if r.get(best) == v]
            if subset:
                node["children"][v] = self._build(subset, remaining, depth + 1)
        return node

    def predict_proba(self, evidence):
        node = self.root
        while "feature" in node:
            child = node["children"].get(evidence.get(node["feature"]))
            if child is None:
                break
            node = child
        return dict(node["dist"])

    def describe(self, node=None, indent=""):
        node = node or self.root
        if "feature" not in node:
            return [f"{indent}-> P(Fail)={node['dist']['Fail']:.2f}  (n={node['n']})"]
        lines = []
        for v, child in node["children"].items():
            lines.append(f"{indent}{node['feature']} = {v}:")
            lines.extend(self.describe(child, indent + "    "))
        return lines
