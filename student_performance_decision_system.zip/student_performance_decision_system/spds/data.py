"""Variable definitions, loading, discretisation and train/test splitting."""
import csv
import random
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "students.csv"

TARGET = "Result"
CLASSES = ["Pass", "Fail"]
POSITIVE = "Fail"  # the class we care about detecting (at-risk students)

INF = float("inf")

# Each AI variable is a discretised version of a raw CSV column.
# variable -> (raw column, [(upper bound, exclusive), label), ...])
BINS = {
    "StudyHours":    ("study_hours_per_week",  [(5, "Low"), (12, "Medium"), (INF, "High")]),
    "Attendance":    ("attendance_pct",        [(65, "Low"), (85, "Medium"), (INF, "High")]),
    "PrevGPA":       ("prev_gpa",              [(6, "Poor"), (8, "Average"), (INF, "Good")]),
    "InternalMarks": ("internal_marks",        [(20, "Poor"), (35, "Average"), (INF, "Good")]),
    "Assignments":   ("assignments_submitted", [(7, "Incomplete"), (INF, "Complete")]),
}
FEATURES = list(BINS)
RAW_COLUMNS = [col for col, _ in BINS.values()]

STATES = {var: [label for _, label in bins] for var, (_, bins) in BINS.items()}
STATES[TARGET] = CLASSES

UNITS = {
    "StudyHours": "hours/week (Low <5, Medium 5-12, High >=12)",
    "Attendance": "% (Low <65, Medium 65-85, High >=85)",
    "PrevGPA": "out of 10 (Poor <6, Average 6-8, Good >=8)",
    "InternalMarks": "out of 50 (Poor <20, Average 20-35, Good >=35)",
    "Assignments": "submitted out of 10 (Incomplete <7, Complete >=7)",
}


def discretise_value(var, raw):
    """Map a raw number to its category label; None/'' means missing."""
    if raw is None or raw == "":
        return None
    x = float(raw)
    for upper, label in BINS[var][1]:
        if x < upper:
            return label


def discretise_row(raw_row):
    record = {var: discretise_value(var, raw_row.get(col)) for var, (col, _) in BINS.items()}
    if raw_row.get("final_result"):
        record[TARGET] = raw_row["final_result"]
    return record


def parse_user_value(var, text):
    """Accept a category label (any case), a raw number, or blank/'?' for unknown."""
    text = (text or "").strip().lstrip("﻿")
    if text in ("", "?"):
        return None
    for label in STATES[var]:
        if text.lower() == label.lower():
            return label
    try:
        return discretise_value(var, float(text))
    except ValueError:
        raise ValueError(f"{var}: expected a number or one of {STATES[var]}, got {text!r}")


def load_dataset(path=DATA_PATH):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"{path} not found -- run `python generate_data.py` first")
    with open(path, newline="") as f:
        return [discretise_row(row) for row in csv.DictReader(f)]


def train_test_split(records, test_ratio=0.3, seed=7):
    rows = list(records)
    random.Random(seed).shuffle(rows)
    cut = int(len(rows) * (1 - test_ratio))
    return rows[:cut], rows[cut:]


def k_fold_splits(records, k=5, seed=7):
    rows = list(records)
    random.Random(seed).shuffle(rows)
    folds = [rows[i::k] for i in range(k)]
    for i in range(k):
        train = [r for j, fold in enumerate(folds) if j != i for r in fold]
        yield train, folds[i]


def without_target(record):
    return {k: v for k, v in record.items() if k != TARGET}
