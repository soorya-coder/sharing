"""Decision layer: turn a posterior P(Result | evidence) into an action.

Uses the decision-theoretic rule: choose the action with the minimum
expected cost,
    EC(a) = Σ_s P(s | evidence) * Cost(a, s)
The costs below say that ignoring a student who goes on to fail is by far the
worst outcome, and that an unnecessary intervention wastes some staff time.
"""

ACTIONS = ("No action", "Mentor & monitor", "Intensive intervention")

COST = {
    "No action":              {"Pass": 0, "Fail": 10},
    "Mentor & monitor":       {"Pass": 1, "Fail": 4},
    "Intensive intervention": {"Pass": 3, "Fail": 1},
}


def expected_costs(posterior):
    return {a: sum(posterior[s] * COST[a][s] for s in posterior) for a in ACTIONS}


def decide(posterior):
    costs = expected_costs(posterior)
    return min(costs, key=costs.get), costs


def realised_cost(action, true_result):
    return COST[action][true_result]


def decision_thresholds():
    """P(Fail) values at which the best action switches (costs are linear in p).

    For actions a, b: EC(a) = a_pass + (a_fail - a_pass) p, so they tie at
        p = (b_pass - a_pass) / ((a_fail - a_pass) - (b_fail - b_pass)).
    """
    out = []
    for a, b in zip(ACTIONS, ACTIONS[1:]):
        ca, cb = COST[a], COST[b]
        p = (cb["Pass"] - ca["Pass"]) / ((ca["Fail"] - ca["Pass"]) - (cb["Fail"] - cb["Pass"]))
        out.append((a, b, p))
    return out
