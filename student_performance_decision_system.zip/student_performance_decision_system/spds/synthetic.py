"""Synthetic student dataset generator.

Every student has two hidden traits -- motivation and ability. The observable
measures (study hours, attendance, GPA, marks, assignments) are noisy functions
of those traits, and the final pass/fail outcome depends on the observables
plus random noise. So the outcome is genuinely uncertain: no model can be
100% accurate, which is exactly the setting Bayesian reasoning is built for.
"""
import csv
import random

from .data import DATA_PATH, RAW_COLUMNS


def _clip(x, lo, hi):
    return max(lo, min(hi, x))


def generate(n=2000, seed=42, missing_rate=0.03):
    rng = random.Random(seed)
    rows = []
    for i in range(1, n + 1):
        motivation = rng.gauss(0, 1)
        ability = rng.gauss(0, 1)

        study = _clip(8 + 4 * motivation + rng.gauss(0, 3), 0, 30)
        attendance = _clip(78 + 9 * motivation + rng.gauss(0, 8), 30, 100)
        prev_gpa = _clip(7 + 1.2 * ability + rng.gauss(0, 0.6), 3, 10)
        assignments = int(_clip(round(6.5 + 0.25 * (study - 8) + motivation + rng.gauss(0, 1.5)), 0, 10))
        internal = _clip(27 + 0.8 * (study - 8) + 0.25 * (attendance - 78) + 4 * ability
                         + rng.gauss(0, 5), 0, 50)

        score = (0.9 * (internal - 27) + 0.2 * (attendance - 78) + 3 * (prev_gpa - 7)
                 + 0.8 * (assignments - 6.5) + rng.gauss(0, 5))

        row = {
            "student_id": f"S{i:04d}",
            "study_hours_per_week": round(study, 1),
            "attendance_pct": round(attendance, 1),
            "prev_gpa": round(prev_gpa, 2),
            "internal_marks": round(internal, 1),
            "assignments_submitted": assignments,
        }
        # Real records are incomplete -- blank out a few values at random.
        for col in RAW_COLUMNS:
            if rng.random() < missing_rate:
                row[col] = ""
        row["final_result"] = "Pass" if score > -6 else "Fail"
        rows.append(row)
    return rows


def write_csv(rows, path=DATA_PATH):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return path
