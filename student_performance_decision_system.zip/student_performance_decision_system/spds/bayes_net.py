"""Discrete Bayesian network with exact inference by enumeration.

The joint distribution factorises along the graph:
    P(X1..Xn) = Π P(Xi | Parents(Xi))
A query P(Q | e) is answered by summing the joint over every hidden
(unobserved, non-query) variable and normalising:
    P(Q | e) = α Σ_h P(Q, e, h)
With six variables of at most three states each this is at most 3^5 = 243
terms per query value, so plain enumeration is fast enough.
"""
import itertools
from collections import Counter, defaultdict


def normalise(dist):
    total = sum(dist.values())
    return {k: v / total for k, v in dist.items()}


class BayesianNetwork:
    def __init__(self, parents, states, target, alpha=1.0):
        self.parents = parents  # node -> [parent nodes]
        self.states = states
        self.target = target
        self.alpha = alpha
        self.order = self._topological_order()
        self.cpt = {}  # node -> {parent values tuple: {value: prob}}

    def _topological_order(self):
        order, placed = [], set()
        while len(order) < len(self.parents):
            ready = [n for n, ps in self.parents.items()
                     if n not in placed and all(p in placed for p in ps)]
            if not ready:
                raise ValueError("network structure contains a cycle")
            for n in ready:
                order.append(n)
                placed.add(n)
        return order

    def fit(self, records):
        """Learn every CPT by counting (maximum likelihood + Laplace smoothing).

        A row only counts towards a CPT if the node and all its parents are
        observed in that row (available-case analysis).
        """
        a = self.alpha
        for node in self.order:
            pars = self.parents[node]
            counts = defaultdict(Counter)
            for r in records:
                if r.get(node) is None or any(r.get(p) is None for p in pars):
                    continue
                counts[tuple(r[p] for p in pars)][r[node]] += 1
            values = self.states[node]
            table = {}
            for config in itertools.product(*(self.states[p] for p in pars)):
                c = counts[config]
                total = sum(c.values())
                table[config] = {v: (c[v] + a) / (total + a * len(values)) for v in values}
            self.cpt[node] = table
        return self

    def joint(self, assignment):
        p = 1.0
        for node in self.order:
            config = tuple(assignment[q] for q in self.parents[node])
            p *= self.cpt[node][config][assignment[node]]
        return p

    def query(self, variable, evidence):
        """Exact posterior P(variable | evidence) by enumeration."""
        evidence = {k: v for k, v in evidence.items() if v is not None and k in self.parents}
        if variable in evidence:
            return {v: float(v == evidence[variable]) for v in self.states[variable]}
        hidden = [n for n in self.order if n != variable and n not in evidence]
        dist = {}
        for value in self.states[variable]:
            total = 0.0
            for combo in itertools.product(*(self.states[h] for h in hidden)):
                assignment = dict(evidence)
                assignment[variable] = value
                assignment.update(zip(hidden, combo))
                total += self.joint(assignment)
            dist[value] = total
        return normalise(dist)

    def predict_proba(self, evidence):
        evidence = {k: v for k, v in evidence.items() if k != self.target}
        return self.query(self.target, evidence)

    def edges(self):
        return [(p, n) for n in self.order for p in self.parents[n]]
