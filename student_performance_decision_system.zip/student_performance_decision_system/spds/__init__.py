"""Student Performance Decision System -- Bayesian reasoning (pure Python)."""
