"""Model definitions in one place, so experiments and the demo agree."""
from .baselines import DecisionTreeID3, PriorBaseline, RuleBasedBaseline
from .bayes_net import BayesianNetwork
from .data import CLASSES, FEATURES, STATES, TARGET
from .naive_bayes import NaiveBayes

# Domain-knowledge structure (arrows point from cause to effect).
#   StudyHours -> Assignments
#   StudyHours, Attendance -> InternalMarks
#   InternalMarks, Attendance, PrevGPA, Assignments -> Result
BN_STRUCTURE = {
    "StudyHours": [],
    "Attendance": [],
    "PrevGPA": [],
    "Assignments": ["StudyHours"],
    "InternalMarks": ["StudyHours", "Attendance"],
    TARGET: ["InternalMarks", "Attendance", "PrevGPA", "Assignments"],
}


def build_models():
    """Fresh, unfitted instances of every model, keyed by display name."""
    return {
        "Bayesian Network": BayesianNetwork(BN_STRUCTURE, STATES, TARGET),
        "Naive Bayes": NaiveBayes(FEATURES, STATES, TARGET),
        "Decision Tree (ID3)": DecisionTreeID3(FEATURES, STATES, TARGET),
        "Rule-based": RuleBasedBaseline(),
        "Prior only": PriorBaseline(TARGET, CLASSES),
    }
