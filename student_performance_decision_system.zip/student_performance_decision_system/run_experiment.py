"""Train, evaluate and compare every model; writes results/report.md.

Usage: python run_experiment.py
"""
import statistics
from collections import Counter

from spds.data import (DATA_PATH, FEATURES, PROJECT_ROOT, STATES, TARGET, k_fold_splits,
                       load_dataset, train_test_split)
from spds.decision import ACTIONS, COST, decide, decision_thresholds
from spds.metrics import evaluate
from spds.models import build_models
from spds.synthetic import generate, write_csv

REPORT_PATH = PROJECT_ROOT / "results" / "report.md"


def md_table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    lines += ["| " + " | ".join(str(c) for c in row) + " |" for row in rows]
    return "\n".join(lines)


def fmt_dist(dist):
    return ", ".join(f"{k}={v:.3f}" for k, v in dist.items())


def fmt_evidence(e):
    return ", ".join(f"{k}={v}" for k, v in e.items()) or "(none)"


def main():
    if not DATA_PATH.exists():
        write_csv(generate())
        print(f"Generated {DATA_PATH}")
    records = load_dataset()
    train, test = train_test_split(records)
    out = ["# Student Performance Decision System -- Results", ""]

    # ---------------------------------------------------------------- dataset
    results = Counter(r[TARGET] for r in records)
    missing = {f: sum(r[f] is None for r in records) for f in FEATURES}
    out += ["## 1. Dataset", "",
            f"- Students: **{len(records)}** (train {len(train)}, test {len(test)}, 70/30 split)",
            f"- Pass: {results['Pass']}, Fail: {results['Fail']} "
            f"(fail rate {results['Fail'] / len(records):.1%})",
            f"- Missing values: " + ", ".join(f"{f} {n}" for f, n in missing.items()), ""]
    dist_rows = []
    for f in FEATURES:
        c = Counter(r[f] for r in records if r[f] is not None)
        dist_rows.append([f] + [", ".join(f"{s}: {c[s]}" for s in STATES[f])])
    out += [md_table(["Variable", "State counts"], dist_rows), ""]

    # --------------------------------------------------------- hold-out test
    models = build_models()
    for m in models.values():
        m.fit(train)
    scores = {name: evaluate(m, test) for name, m in models.items()}

    rows = [[name, f"{s['accuracy']:.3f}", f"{s['precision']:.3f}", f"{s['recall']:.3f}",
             f"{s['f1']:.3f}", f"{s['log_loss']:.3f}", f"{s['brier']:.3f}", f"{s['avg_cost']:.3f}"]
            for name, s in scores.items()]
    out += ["## 2. Hold-out test set results", "",
            "Positive class = **Fail** (at-risk student). Prediction = Fail when P(Fail) >= 0.5. "
            "*Avg cost* is the mean realised cost of the minimum-expected-cost action "
            "(lower is better).", "",
            md_table(["Model", "Accuracy", "Precision", "Recall (Fail)", "F1", "Log loss",
                      "Brier", "Avg cost"], rows), ""]

    out += ["### Confusion matrices", ""]
    for name in ("Bayesian Network", "Naive Bayes", "Decision Tree (ID3)", "Rule-based"):
        s = scores[name]
        out += [f"**{name}**", "",
                md_table(["", "Predicted Fail", "Predicted Pass"],
                         [["Actual Fail", s["tp"], s["fn"]], ["Actual Pass", s["fp"], s["tn"]]]), ""]

    # ------------------------------------------------------ cross-validation
    cv = {name: [] for name in models}
    for fold_train, fold_test in k_fold_splits(records, k=5):
        for name, m in build_models().items():
            cv[name].append(evaluate(m.fit(fold_train), fold_test))

    def ms(name, key):
        vals = [s[key] for s in cv[name]]
        return f"{statistics.mean(vals):.3f} ± {statistics.stdev(vals):.3f}"

    out += ["## 3. 5-fold cross-validation (mean ± sd)", "",
            md_table(["Model", "Accuracy", "Recall (Fail)", "F1", "Log loss", "Avg cost"],
                     [[n, ms(n, "accuracy"), ms(n, "recall"), ms(n, "f1"), ms(n, "log_loss"),
                       ms(n, "avg_cost")] for n in models]), ""]

    # -------------------------------------------------- learned parameters
    nb, bn, tree = models["Naive Bayes"], models["Bayesian Network"], models["Decision Tree (ID3)"]
    out += ["## 4. Learned parameters", "",
            f"### Naive Bayes prior: {fmt_dist(nb.prior)}", "",
            "### Naive Bayes likelihoods P(feature = value | Result)", ""]
    lk_rows = [[f, v, f"{nb.likelihood[f]['Pass'][v]:.3f}", f"{nb.likelihood[f]['Fail'][v]:.3f}",
                f"{nb.likelihood[f]['Fail'][v] / nb.likelihood[f]['Pass'][v]:.2f}"]
               for f in FEATURES for v in STATES[f]]
    out += [md_table(["Feature", "Value", "P(v \\| Pass)", "P(v \\| Fail)", "Likelihood ratio Fail:Pass"],
                     lk_rows), ""]

    out += ["### Bayesian network structure", "", "```"]
    out += [f"{p} -> {c}" for p, c in bn.edges()]
    out += ["```", "", "### CPT: P(InternalMarks | StudyHours, Attendance)", ""]
    cpt_rows = [[*config] + [f"{dist[v]:.3f}" for v in STATES["InternalMarks"]]
                for config, dist in bn.cpt["InternalMarks"].items()]
    out += [md_table(["StudyHours", "Attendance"] + STATES["InternalMarks"], cpt_rows), ""]

    out += ["### Decision tree (ID3) learned for comparison", "", "```"]
    out += tree.describe()
    out += ["```", ""]

    # ----------------------------------------------------- reasoning examples
    examples = [
        ("Prior (no evidence)", {}),
        ("Predictive: low attendance", {"Attendance": "Low"}),
        ("...and good internal marks", {"Attendance": "Low", "InternalMarks": "Good"}),
        ("Missing marks: high study hours, assignments complete",
         {"StudyHours": "High", "Assignments": "Complete"}),
        ("Weak student on every measure", {"StudyHours": "Low", "Attendance": "Low", "PrevGPA": "Poor",
                                           "InternalMarks": "Poor", "Assignments": "Incomplete"}),
        ("Mixed profile", {"StudyHours": "Medium", "Attendance": "Medium", "PrevGPA": "Average",
                           "InternalMarks": "Average", "Assignments": "Incomplete"}),
    ]
    ex_rows = []
    for label, e in examples:
        p_bn = bn.predict_proba(e)
        p_nb = nb.predict_proba(e)
        action, _ = decide(p_bn)
        ex_rows.append([label, fmt_evidence(e), f"{p_bn['Fail']:.3f}", f"{p_nb['Fail']:.3f}", action])
    out += ["## 5. Reasoning examples", "",
            md_table(["Case", "Evidence", "BN P(Fail)", "NB P(Fail)", "Decision (BN)"], ex_rows), ""]

    e = {"StudyHours": "High", "Assignments": "Complete"}
    out += ["### Inferring an unobserved variable",
            f"With evidence {fmt_evidence(e)} (internal marks unknown), the network infers:", "",
            f"- P(InternalMarks | e) = {fmt_dist(bn.query('InternalMarks', e))}",
            f"- Compare the unconditional P(InternalMarks) = {fmt_dist(bn.query('InternalMarks', {}))}", "",
            "### Diagnostic reasoning (effect -> cause)", "",
            f"- P(StudyHours) = {fmt_dist(bn.query('StudyHours', {}))}",
            f"- P(StudyHours | Result=Fail) = {fmt_dist(bn.query('StudyHours', {TARGET: 'Fail'}))}",
            f"- P(Attendance | Result=Fail) = {fmt_dist(bn.query('Attendance', {TARGET: 'Fail'}))}", ""]

    # --------------------------------------------------------- decision policy
    out += ["## 6. Decision policy", "",
            "Action = argmin over a of EC(a) = Σ_s P(s | evidence) · Cost(a, s)", "",
            md_table(["Action", "Cost if student Passes", "Cost if student Fails"],
                     [[a, COST[a]["Pass"], COST[a]["Fail"]] for a in ACTIONS]), "",
            "Equivalent P(Fail) thresholds:", ""]
    out += [f"- {a} -> {b} when P(Fail) > {p:.3f}" for a, b, p in decision_thresholds()]
    test_actions = Counter(decide(bn.predict_proba(r))[0] for r in test)
    out += ["", "Actions chosen by the Bayesian network on the test set: "
            + ", ".join(f"{a}: {test_actions[a]}" for a in ACTIONS), ""]

    report = "\n".join(out)
    REPORT_PATH.parent.mkdir(exist_ok=True)
    REPORT_PATH.write_text(report, encoding="utf-8")
    print(report)
    print(f"\nReport written to {REPORT_PATH}")


if __name__ == "__main__":
    main()
