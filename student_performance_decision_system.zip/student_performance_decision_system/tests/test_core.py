"""Correctness checks.  Run with:  python -m unittest discover tests"""
import math
import unittest

from spds.bayes_net import BayesianNetwork
from spds.data import FEATURES, STATES, TARGET, parse_user_value
from spds.decision import decide, decision_thresholds
from spds.naive_bayes import NaiveBayes
from spds.synthetic import generate
from spds.data import discretise_row


def sample_records(n=600):
    return [discretise_row({k: str(v) for k, v in row.items()}) for row in generate(n, seed=1)]


class TestBayesRule(unittest.TestCase):
    def test_worked_example(self):
        # Prior P(Pass)=0.7; P(LowAtt|Pass)=0.2, P(LowAtt|Fail)=0.7  ->  P(Fail|LowAtt)=0.6
        states = {"Attendance": ["Low", "High"], TARGET: ["Pass", "Fail"]}
        nb = NaiveBayes(["Attendance"], states, TARGET)
        nb.prior = {"Pass": 0.7, "Fail": 0.3}
        nb.likelihood = {"Attendance": {"Pass": {"Low": 0.2, "High": 0.8},
                                        "Fail": {"Low": 0.7, "High": 0.3}}}
        self.assertAlmostEqual(nb.predict_proba({"Attendance": "Low"})["Fail"], 0.6)


class TestModels(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records = sample_records()

    def test_posteriors_sum_to_one(self):
        nb = NaiveBayes(FEATURES, STATES, TARGET).fit(self.records)
        bn = BayesianNetwork({f: [] for f in FEATURES} | {TARGET: ["InternalMarks"]}, STATES, TARGET)
        bn.fit(self.records)
        e = {"Attendance": "Low", "InternalMarks": "Poor"}
        for model in (nb, bn):
            self.assertAlmostEqual(sum(model.predict_proba(e).values()), 1.0)

    def test_bn_with_naive_structure_equals_naive_bayes(self):
        # A BN where Result is the only parent of every feature IS Naive Bayes,
        # so exact enumeration must reproduce the NB posterior.
        structure = {TARGET: []} | {f: [TARGET] for f in FEATURES}
        bn = BayesianNetwork(structure, STATES, TARGET).fit(self.records)
        nb = NaiveBayes(FEATURES, STATES, TARGET).fit(self.records)
        for e in ({}, {"Attendance": "Low"},
                  {"StudyHours": "High", "PrevGPA": "Poor", "Assignments": "Complete"}):
            self.assertAlmostEqual(bn.predict_proba(e)["Fail"], nb.predict_proba(e)["Fail"], places=9)

    def test_cpts_are_distributions(self):
        bn = BayesianNetwork({TARGET: [], "Attendance": [TARGET]}, STATES, TARGET).fit(self.records)
        for table in bn.cpt.values():
            for dist in table.values():
                self.assertTrue(math.isclose(sum(dist.values()), 1.0))

    def test_sequential_update_matches_batch(self):
        nb = NaiveBayes(FEATURES, STATES, TARGET).fit(self.records)
        e = {"Attendance": "Low", "InternalMarks": "Average", "PrevGPA": "Good"}
        self.assertAlmostEqual(nb.sequential_update(e)[-1][2]["Fail"], nb.predict_proba(e)["Fail"])


class TestDecision(unittest.TestCase):
    def test_actions_follow_thresholds(self):
        (_, _, t1), (_, _, t2) = decision_thresholds()
        self.assertEqual(decide({"Pass": 1 - (t1 - 0.01), "Fail": t1 - 0.01})[0], "No action")
        self.assertEqual(decide({"Pass": 1 - (t1 + t2) / 2, "Fail": (t1 + t2) / 2})[0], "Mentor & monitor")
        self.assertEqual(decide({"Pass": 1 - (t2 + 0.01), "Fail": t2 + 0.01})[0], "Intensive intervention")


class TestInputParsing(unittest.TestCase):
    def test_numbers_labels_and_blanks(self):
        self.assertEqual(parse_user_value("Attendance", "58"), "Low")
        self.assertEqual(parse_user_value("Attendance", "high"), "High")
        self.assertIsNone(parse_user_value("Attendance", ""))
        with self.assertRaises(ValueError):
            parse_user_value("Attendance", "lots")


if __name__ == "__main__":
    unittest.main()
