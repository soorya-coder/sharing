# Student Performance Decision System -- Results

## 1. Dataset

- Students: **2000** (train 1400, test 600, 70/30 split)
- Pass: 1361, Fail: 639 (fail rate 31.9%)
- Missing values: StudyHours 62, Attendance 65, PrevGPA 50, InternalMarks 65, Assignments 54

| Variable | State counts |
|---|---|
| StudyHours | Low: 485, Medium: 1026, High: 427 |
| Attendance | Low: 268, Medium: 1110, High: 557 |
| PrevGPA | Poor: 425, Average: 1101, Good: 424 |
| InternalMarks | Poor: 405, Average: 1156, Good: 374 |
| Assignments | Incomplete: 967, Complete: 979 |

## 2. Hold-out test set results

Positive class = **Fail** (at-risk student). Prediction = Fail when P(Fail) >= 0.5. *Avg cost* is the mean realised cost of the minimum-expected-cost action (lower is better).

| Model | Accuracy | Precision | Recall (Fail) | F1 | Log loss | Brier | Avg cost |
|---|---|---|---|---|---|---|---|
| Bayesian Network | 0.858 | 0.864 | 0.702 | 0.775 | 0.349 | 0.109 | 1.113 |
| Naive Bayes | 0.845 | 0.786 | 0.760 | 0.773 | 0.368 | 0.111 | 1.123 |
| Decision Tree (ID3) | 0.847 | 0.826 | 0.707 | 0.762 | 0.357 | 0.114 | 1.185 |
| Rule-based | 0.830 | 0.762 | 0.740 | 0.751 | 2.349 | 0.170 | 1.397 |
| Prior only | 0.653 | 0.000 | 0.000 | 0.000 | 0.649 | 0.228 | 2.040 |

### Confusion matrices

**Bayesian Network**

|  | Predicted Fail | Predicted Pass |
|---|---|---|
| Actual Fail | 146 | 62 |
| Actual Pass | 23 | 369 |

**Naive Bayes**

|  | Predicted Fail | Predicted Pass |
|---|---|---|
| Actual Fail | 158 | 50 |
| Actual Pass | 43 | 349 |

**Decision Tree (ID3)**

|  | Predicted Fail | Predicted Pass |
|---|---|---|
| Actual Fail | 147 | 61 |
| Actual Pass | 31 | 361 |

**Rule-based**

|  | Predicted Fail | Predicted Pass |
|---|---|---|
| Actual Fail | 154 | 54 |
| Actual Pass | 48 | 344 |

## 3. 5-fold cross-validation (mean ± sd)

| Model | Accuracy | Recall (Fail) | F1 | Log loss | Avg cost |
|---|---|---|---|---|---|
| Bayesian Network | 0.859 ± 0.014 | 0.691 ± 0.018 | 0.757 ± 0.021 | 0.339 ± 0.021 | 1.100 ± 0.049 |
| Naive Bayes | 0.840 ± 0.016 | 0.733 ± 0.028 | 0.745 ± 0.024 | 0.361 ± 0.032 | 1.106 ± 0.078 |
| Decision Tree (ID3) | 0.853 ± 0.016 | 0.670 ± 0.057 | 0.743 ± 0.030 | 0.340 ± 0.021 | 1.105 ± 0.046 |
| Rule-based | 0.832 ± 0.013 | 0.719 ± 0.013 | 0.732 ± 0.013 | 2.321 ± 0.180 | 1.363 ± 0.099 |
| Prior only | 0.680 ± 0.017 | 0.000 ± 0.000 | 0.000 ± 0.000 | 0.627 ± 0.014 | 1.958 ± 0.052 |

## 4. Learned parameters

### Naive Bayes prior: Pass=0.692, Fail=0.308

### Naive Bayes likelihoods P(feature = value | Result)

| Feature | Value | P(v \| Pass) | P(v \| Fail) | Likelihood ratio Fail:Pass |
|---|---|---|---|---|
| StudyHours | Low | 0.140 | 0.488 | 3.48 |
| StudyHours | Medium | 0.558 | 0.450 | 0.81 |
| StudyHours | High | 0.302 | 0.061 | 0.20 |
| Attendance | Low | 0.066 | 0.283 | 4.31 |
| Attendance | Medium | 0.544 | 0.626 | 1.15 |
| Attendance | High | 0.390 | 0.092 | 0.24 |
| PrevGPA | Poor | 0.130 | 0.395 | 3.05 |
| PrevGPA | Average | 0.581 | 0.540 | 0.93 |
| PrevGPA | Good | 0.289 | 0.065 | 0.23 |
| InternalMarks | Poor | 0.026 | 0.600 | 23.40 |
| InternalMarks | Average | 0.686 | 0.398 | 0.58 |
| InternalMarks | Good | 0.288 | 0.002 | 0.01 |
| Assignments | Incomplete | 0.374 | 0.738 | 1.97 |
| Assignments | Complete | 0.626 | 0.262 | 0.42 |

### Bayesian network structure

```
StudyHours -> Assignments
StudyHours -> InternalMarks
Attendance -> InternalMarks
InternalMarks -> Result
Attendance -> Result
PrevGPA -> Result
Assignments -> Result
```

### CPT: P(InternalMarks | StudyHours, Attendance)

| StudyHours | Attendance | Poor | Average | Good |
|---|---|---|---|---|
| Low | Low | 0.670 | 0.320 | 0.010 |
| Low | Medium | 0.412 | 0.564 | 0.025 |
| Low | High | 0.222 | 0.611 | 0.167 |
| Medium | Low | 0.339 | 0.610 | 0.051 |
| Medium | Medium | 0.158 | 0.725 | 0.118 |
| Medium | High | 0.076 | 0.652 | 0.273 |
| High | Low | 0.091 | 0.727 | 0.182 |
| High | Medium | 0.038 | 0.600 | 0.362 |
| High | High | 0.012 | 0.372 | 0.616 |

### Decision tree (ID3) learned for comparison

```
InternalMarks = Poor:
    PrevGPA = Poor:
        Assignments = Incomplete:
            -> P(Fail)=0.99  (n=80)
        Assignments = Complete:
            StudyHours = Low:
                -> P(Fail)=0.71  (n=5)
            StudyHours = Medium:
                -> P(Fail)=0.90  (n=18)
            StudyHours = High:
                -> P(Fail)=0.75  (n=2)
    PrevGPA = Average:
        Attendance = Low:
            StudyHours = Low:
                -> P(Fail)=0.98  (n=41)
            StudyHours = Medium:
                -> P(Fail)=0.86  (n=12)
        Attendance = Medium:
            Assignments = Incomplete:
                -> P(Fail)=0.88  (n=54)
            Assignments = Complete:
                -> P(Fail)=0.62  (n=14)
        Attendance = High:
            -> P(Fail)=0.80  (n=8)
    PrevGPA = Good:
        Attendance = Low:
            -> P(Fail)=0.85  (n=11)
        Attendance = Medium:
            -> P(Fail)=0.62  (n=11)
InternalMarks = Average:
    PrevGPA = Poor:
        Attendance = Low:
            -> P(Fail)=0.57  (n=5)
        Attendance = Medium:
            StudyHours = Low:
                -> P(Fail)=0.67  (n=10)
            StudyHours = Medium:
                -> P(Fail)=0.51  (n=57)
            StudyHours = High:
                -> P(Fail)=0.43  (n=19)
        Attendance = High:
            StudyHours = Low:
                -> P(Fail)=0.25  (n=2)
            StudyHours = Medium:
                -> P(Fail)=0.17  (n=34)
            StudyHours = High:
                -> P(Fail)=0.24  (n=23)
    PrevGPA = Average:
        StudyHours = Low:
            Attendance = Low:
                -> P(Fail)=0.73  (n=13)
            Attendance = Medium:
                -> P(Fail)=0.40  (n=66)
            Attendance = High:
                -> P(Fail)=0.29  (n=5)
        StudyHours = Medium:
            Attendance = Low:
                -> P(Fail)=0.36  (n=23)
            Attendance = Medium:
                -> P(Fail)=0.17  (n=182)
            Attendance = High:
                -> P(Fail)=0.15  (n=66)
        StudyHours = High:
            Attendance = Low:
                -> P(Fail)=0.29  (n=5)
            Attendance = Medium:
                -> P(Fail)=0.13  (n=37)
            Attendance = High:
                -> P(Fail)=0.03  (n=34)
    PrevGPA = Good:
        Assignments = Incomplete:
            StudyHours = Low:
                -> P(Fail)=0.18  (n=42)
            StudyHours = Medium:
                -> P(Fail)=0.07  (n=44)
            StudyHours = High:
                -> P(Fail)=0.33  (n=1)
        Assignments = Complete:
            -> P(Fail)=0.01  (n=74)
InternalMarks = Good:
    -> P(Fail)=0.00  (n=269)
```

## 5. Reasoning examples

| Case | Evidence | BN P(Fail) | NB P(Fail) | Decision (BN) |
|---|---|---|---|---|
| Prior (no evidence) | (none) | 0.311 | 0.308 | Mentor & monitor |
| Predictive: low attendance | Attendance=Low | 0.545 | 0.657 | Intensive intervention |
| ...and good internal marks | Attendance=Low, InternalMarks=Good | 0.393 | 0.016 | Mentor & monitor |
| Missing marks: high study hours, assignments complete | StudyHours=High, Assignments=Complete | 0.158 | 0.037 | Mentor & monitor |
| Weak student on every measure | StudyHours=Low, Attendance=Low, PrevGPA=Poor, InternalMarks=Poor, Assignments=Incomplete | 0.955 | 0.999 | Intensive intervention |
| Mixed profile | StudyHours=Medium, Attendance=Medium, PrevGPA=Average, InternalMarks=Average, Assignments=Incomplete | 0.279 | 0.305 | Mentor & monitor |

### Inferring an unobserved variable
With evidence StudyHours=High, Assignments=Complete (internal marks unknown), the network infers:

- P(InternalMarks | e) = Poor=0.037, Average=0.548, Good=0.414
- Compare the unconditional P(InternalMarks) = Poor=0.187, Average=0.621, Good=0.192

### Diagnostic reasoning (effect -> cause)

- P(StudyHours) = Low=0.248, Medium=0.525, High=0.227
- P(StudyHours | Result=Fail) = Low=0.381, Medium=0.498, High=0.121
- P(Attendance | Result=Fail) = Low=0.230, Medium=0.596, High=0.174

## 6. Decision policy

Action = argmin over a of EC(a) = Σ_s P(s | evidence) · Cost(a, s)

| Action | Cost if student Passes | Cost if student Fails |
|---|---|---|
| No action | 0 | 10 |
| Mentor & monitor | 1 | 4 |
| Intensive intervention | 3 | 1 |

Equivalent P(Fail) thresholds:

- No action -> Mentor & monitor when P(Fail) > 0.143
- Mentor & monitor -> Intensive intervention when P(Fail) > 0.400

Actions chosen by the Bayesian network on the test set: No action: 272, Mentor & monitor: 129, Intensive intervention: 199
