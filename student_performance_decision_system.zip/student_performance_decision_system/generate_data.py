"""Create data/students.csv.  Usage: python generate_data.py [--n 2000] [--seed 42]"""
import argparse
from collections import Counter

from spds.synthetic import generate, write_csv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n", type=int, default=2000, help="number of students")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--missing-rate", type=float, default=0.03)
    args = parser.parse_args()

    rows = generate(args.n, args.seed, args.missing_rate)
    path = write_csv(rows)
    counts = Counter(r["final_result"] for r in rows)
    print(f"Wrote {len(rows)} students to {path}")
    print(f"  Pass: {counts['Pass']}  Fail: {counts['Fail']}  "
          f"(fail rate {counts['Fail'] / len(rows):.1%})")


if __name__ == "__main__":
    main()
