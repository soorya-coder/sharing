# Student Performance Decision System — Bayesian Reasoning

M.Tech Fundamentals of AI — Mini-Project #7

Given what is known about a student (study hours, attendance, previous GPA,
internal marks, assignment completion), the system computes the probability that
they will **pass or fail**, then recommends an **action** (no action, mentor &
monitor, or intensive intervention) by minimising expected cost.

Pure Python 3 standard library: **no packages to install**. Every algorithm is
written from scratch.

---

## Quick start

```bash
python generate_data.py          # creates data/students.csv (2000 synthetic students)
python run_experiment.py         # trains, evaluates, compares -> results/report.md
python demo.py                   # interactive: type a student's details
python -m unittest discover tests
python build_report_pdf.py       # project report PDF -> report/ (needs: pip install reportlab)
python build_report_docx.py      # same report as Word (needs: pip install python-docx reportlab pypdfium2)
```

Demo with arguments (numbers or category names; anything left out = unknown):

```bash
python demo.py --attendance 58 --study-hours 4 --assignments 5
```

---

## 1. Problem definition

Teachers need to identify at-risk students **early**, while there's still time to help.
The information is **uncertain** (the same marks can lead to different outcomes)
and often **incomplete** (missing attendance records, marks not yet published).
The system should:

1. estimate P(Fail) for a student from whatever evidence is available,
2. explain which evidence drove that estimate,
3. recommend the intervention with the lowest expected cost.

## 2. AI problem formulation

| Element | Definition |
|---|---|
| Random variables | StudyHours {Low, Medium, High}, Attendance {Low, Medium, High}, PrevGPA {Poor, Average, Good}, InternalMarks {Poor, Average, Good}, Assignments {Incomplete, Complete}, **Result {Pass, Fail}** |
| Evidence **e** | Any subset of the five input variables (others unknown) |
| Query | P(Result \| e) |
| Actions | No action, Mentor & monitor, Intensive intervention |
| Cost model | Cost(action, true result); see `spds/decision.py` |
| Decision rule | a* = argmin over a of Σ_s P(s \| e) · Cost(a, s) |

Discretisation thresholds are in `spds/data.py` (e.g. Attendance: Low < 65%, Medium 65–85%, High ≥ 85%).

## 3. AI technique: Bayesian reasoning

**Bayes' theorem**

    P(Result | e) = P(e | Result) · P(Result) / P(e)

**Model A: Naive Bayes** (`spds/naive_bayes.py`). Assumes the features are
independent given Result:
P(Result | e₁…eₙ) ∝ P(Result) · Π P(eᵢ | Result).
It is simple and explainable: each feature's log-likelihood ratio
ln P(eᵢ|Fail)/P(eᵢ|Pass) shows how far it pushes the result towards Fail.

**Model B: Bayesian network** (`spds/bayes_net.py`). Drops the independence
assumption and encodes causal domain knowledge:

```
StudyHours ──► Assignments ────► Result
StudyHours ──► InternalMarks ──► Result
Attendance ──► InternalMarks
Attendance ────────────────────► Result
PrevGPA ───────────────────────► Result
```

- **Learning:** each conditional probability table (CPT) is estimated by counting, with Laplace smoothing.
- **Inference:** exact **enumeration**: P(Q | e) = α Σₕ Π P(Xᵢ | Parents(Xᵢ)), summing over the hidden variables.
- **Missing evidence** is handled correctly by marginalising it out. The network can also infer the unknown variable itself (e.g. likely internal marks given study hours).
- It supports **predictive** reasoning (cause → effect) and **diagnostic** reasoning (effect → cause, e.g. P(StudyHours | Fail)).

**Decision layer** (`spds/decision.py`): decision theory with a cost matrix.
Because expected cost is linear in p = P(Fail), the policy reduces to thresholds:
no action if p < 0.143, mentor if 0.143 ≤ p < 0.4, intensive intervention if p ≥ 0.4.

## 4. Dataset

`spds/synthetic.py` generates 2000 students from a hidden-trait model:
**motivation** and **ability** (unobserved) drive the observable measures, and the
final result depends on the observables plus noise. That makes the outcome
uncertain rather than a fixed rule of the inputs. About 3% of values are blanked
out to simulate incomplete records. Fail rate ≈ 32%.

To use a real dataset (e.g. the UCI *Student Performance* dataset), write a CSV
with the same column names (`study_hours_per_week, attendance_pct, prev_gpa,
internal_marks, assignments_submitted, final_result`) to `data/students.csv`,
or change `BINS` in `spds/data.py`.

## 5. Evaluation and comparison

`run_experiment.py` compares five approaches on a 70/30 hold-out split and with 5-fold cross-validation:

| Model | Role |
|---|---|
| Bayesian network | main technique |
| Naive Bayes | main technique (simpler) |
| Decision tree (ID3, from scratch) | alternative ML approach |
| Rule-based | alternative: hand-written teacher rules, no probabilities |
| Prior only | sanity baseline |

Metrics (positive class = Fail): accuracy, precision, **recall**, F1, confusion
matrix, **log loss** and **Brier score** (how good the probabilities are), and
**average decision cost** (how good the *decisions* are).

### Results (5-fold CV, from `results/report.md`)

| Model | Accuracy | Recall (Fail) | F1 | Log loss | Avg cost |
|---|---|---|---|---|---|
| **Bayesian network** | **0.859** | 0.691 | **0.757** | **0.339** | **1.100** |
| Naive Bayes | 0.840 | **0.733** | 0.745 | 0.361 | 1.106 |
| Decision tree (ID3) | 0.853 | 0.670 | 0.743 | 0.340 | 1.105 |
| Rule-based | 0.832 | 0.719 | 0.732 | 2.321 | 1.363 |
| Prior only | 0.680 | 0.000 | 0.000 | 0.627 | 1.958 |

### Discussion points

- **The Bayesian network performs best overall.** It has the highest accuracy and F1, the best-calibrated probabilities (lowest log loss) and the lowest decision cost.
- **Naive Bayes catches the most failing students** (highest recall) but is **over-confident**. It counts correlated evidence twice. For example, low attendance and poor internal marks are partly the same signal, because attendance affects marks. With "low attendance + good internal marks", Naive Bayes gives P(Fail) ≈ 0.02 while the network gives ≈ 0.39.
- **The rule-based system is reasonable at classifying but terrible at probabilities.** Its log loss is 2.3 because it is 100% certain even when it's wrong, so it can't support cost-based decisions. This is why probabilistic reasoning is needed.
- **The decision tree matches the network on accuracy**, but it isn't a probabilistic model of the domain. It can't answer diagnostic queries or infer missing values, and the tree it learns is large and hard to explain.
- **Decision cost matters more than accuracy here.** The system deliberately flags students at P(Fail) ≥ 0.4, not 0.5, because missing a failing student costs 10× more.

Limitations / possible extensions: structure is hand-designed (could be learned
with hill-climbing over structures + BIC score); CPT learning ignores rows with
missing parents (could use EM); variables are discretised (could use Gaussian
nodes); synthetic data (validate on a real dataset); add a GUI (Streamlit/Tkinter).

## 6. Project structure

```
generate_data.py      create the synthetic dataset
run_experiment.py     train + evaluate + compare, write results/report.md
demo.py               interactive prototype (CLI)
spds/
  data.py             variables, discretisation, loading, splits
  synthetic.py        dataset generator
  naive_bayes.py      Naive Bayes (from scratch)
  bayes_net.py        Bayesian network: CPT learning + exact enumeration
  decision.py         cost matrix, expected-cost decision, thresholds
  baselines.py        ID3 decision tree, rule-based, prior-only
  metrics.py          accuracy/precision/recall/F1/log-loss/Brier/decision cost
  models.py           network structure + model factory
tests/test_core.py    unit tests (incl. BN with naive structure == Naive Bayes)
results/report.md     generated results
```

## 7. Mapping to the mini-project requirements

| Requirement | Where |
|---|---|
| Problem definition | §1 above |
| AI problem formulation | §2, `spds/data.py`, `spds/decision.py` |
| Technique selection and explanation | §3, `spds/naive_bayes.py`, `spds/bayes_net.py` |
| Python implementation | `spds/` |
| Dataset / test cases | `generate_data.py`, `data/students.csv`, `tests/` |
| Performance evaluation | `run_experiment.py` → `results/report.md` §2–3 |
| Comparison with alternatives | Decision tree, rule-based, prior baselines |
| Results, discussion, conclusion | §5 above + `results/report.md` |
| Working prototype | `demo.py` |
