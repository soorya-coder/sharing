"""Interactive demo: enter a student's details, get probabilities and a decision.

Usage:
    python demo.py                       # asks questions (leave blank if unknown)
    python demo.py --attendance 58 --internal-marks 31 --study-hours 4
    python demo.py --attendance Low --prev-gpa Good   # category names work too

Any input left out is treated as unknown evidence: the Bayesian network
marginalises over it instead of guessing.
"""
import argparse

from spds.data import DATA_PATH, FEATURES, STATES, UNITS, load_dataset, parse_user_value
from spds.decision import decide
from spds.models import build_models
from spds.synthetic import generate, write_csv

ARG_NAMES = {
    "StudyHours": "study_hours",
    "Attendance": "attendance",
    "PrevGPA": "prev_gpa",
    "InternalMarks": "internal_marks",
    "Assignments": "assignments",
}


def bar(p, width=30):
    filled = round(p * width)
    return "#" * filled + "." * (width - filled)


def ask_interactively():
    print("Enter the student's details. Use a number or a category name; leave blank if unknown.\n")
    evidence = {}
    for f in FEATURES:
        while True:
            try:
                text = input(f"  {f} [{UNITS[f]}]: ")
            except EOFError:
                text = ""
            try:
                evidence[f] = parse_user_value(f, text)
                break
            except ValueError as err:
                print(f"    {err}")
    return evidence


def report(evidence, bn, nb):
    observed = {f: v for f, v in evidence.items() if v is not None}
    unknown = [f for f in FEATURES if evidence.get(f) is None]

    print("\n=== Evidence ===")
    for f in FEATURES:
        print(f"  {f:<14} {evidence.get(f) or '(unknown)'}")

    p_bn = bn.predict_proba(observed)
    p_nb = nb.predict_proba(observed)
    print("\n=== Posterior probability of the final result ===")
    for name, p in (("Bayesian network", p_bn), ("Naive Bayes", p_nb)):
        print(f"  {name:<17} P(Fail) = {p['Fail']:.3f}  [{bar(p['Fail'])}]   P(Pass) = {p['Pass']:.3f}")

    print("\n=== Step-by-step Bayesian update (Naive Bayes) ===")
    for f, v, post in nb.sequential_update(observed):
        label = "start from the prior" if v is None else f"observe {f} = {v}"
        print(f"  {label:<36} -> P(Fail) = {post['Fail']:.3f}")

    print("\n=== Which evidence mattered (log-likelihood ratio, + means towards Fail) ===")
    for f, v, p_fail, p_pass, w in sorted(nb.evidence_weights(observed), key=lambda t: -abs(t[4])):
        direction = "towards FAIL" if w > 0 else "towards PASS"
        print(f"  {f + ' = ' + v:<28} P(v|Fail)={p_fail:.3f} P(v|Pass)={p_pass:.3f}  "
              f"weight {w:+.2f}  {direction}")

    if unknown:
        print("\n=== Inferred values for unknown inputs (Bayesian network) ===")
        for f in unknown:
            dist = bn.query(f, observed)
            print("  " + f"{f:<14}" + "  ".join(f"{s}={dist[s]:.2f}" for s in STATES[f]))

    action, costs = decide(p_bn)
    print("\n=== Decision (minimum expected cost, using the Bayesian network) ===")
    for a, c in costs.items():
        marker = "  <== recommended" if a == action else ""
        print(f"  {a:<24} expected cost {c:.2f}{marker}")
    print(f"\n  RECOMMENDATION: {action}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    for f, arg in ARG_NAMES.items():
        parser.add_argument("--" + arg.replace("_", "-"), dest=arg, help=f"{f}: {UNITS[f]}".replace("%", "%%"))
    args = parser.parse_args()

    if not DATA_PATH.exists():
        write_csv(generate())
    records = load_dataset()
    models = build_models()
    bn = models["Bayesian Network"].fit(records)
    nb = models["Naive Bayes"].fit(records)

    given = {f: getattr(args, arg) for f, arg in ARG_NAMES.items()}
    if all(v is None for v in given.values()):
        evidence = ask_interactively()
    else:
        try:
            evidence = {f: parse_user_value(f, v) for f, v in given.items()}
        except ValueError as err:
            parser.error(str(err))
    report(evidence, bn, nb)


if __name__ == "__main__":
    main()
